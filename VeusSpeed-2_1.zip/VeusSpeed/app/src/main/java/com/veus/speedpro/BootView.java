package com.veus.speedpro;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.MotionEvent;

/** Cinematic "system online" boot sequence shown once when the app starts. */
public class BootView extends NeonView {
    private static final String[] LINES = {
            "GNSS RECEIVER", "MOTION SENSORS", "OBSTACLE GUARD", "G-FORCE ENGINE", "HUD RENDERER"};
    private final Paint bg = new Paint(), ring = new Paint(Paint.ANTI_ALIAS_FLAG), txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();
    private ValueAnimator anim;
    private float progress;
    private Runnable onEnd;

    public BootView(Context c) { super(c); init(); }
    public BootView(Context c, AttributeSet a) { super(c, a); init(); }
    public BootView(Context c, AttributeSet a, int s) { super(c, a, s); init(); }

    private void init() {
        bg.setColor(0xFF03050A);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeCap(Paint.Cap.ROUND);
        txt.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        txt.setTextAlign(Paint.Align.CENTER);
        setClickable(true);
    }

    public void start(Runnable end) {
        onEnd = end;
        setVisibility(VISIBLE);
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(2600);
        anim.addUpdateListener(a -> {
            progress = (float) a.getAnimatedValue();
            invalidate();
            if (progress >= 1f) finish();
        });
        anim.start();
    }

    private void finish() {
        if (anim != null) { anim.cancel(); anim = null; }
        setVisibility(GONE);
        if (onEnd != null) { Runnable r = onEnd; onEnd = null; r.run(); }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_UP) finish();
        return true;
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) anim.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float fade = progress > 0.85f ? Math.max(0f, 1f - (progress - 0.85f) / 0.15f) : 1f;
        bg.setAlpha((int) (255 * fade));
        c.drawRect(0, 0, w, h, bg);
        float cx = w / 2f, cy = h * 0.36f, r = Math.min(w, h) * 0.18f;

        ring.setStrokeWidth(dp(3));
        ring.setColor(accent);
        ring.setAlpha((int) (70 * fade));
        c.drawCircle(cx, cy, r, ring);
        oval.set(cx - r, cy - r, cx + r, cy + r);
        float sweep = 360f * Math.min(1f, progress * 1.25f);
        ring.setAlpha((int) (255 * fade));
        c.drawArc(oval, -90f + progress * 720f, Math.max(20f, sweep * 0.45f), false, ring);
        ring.setStrokeWidth(dp(1.5f));
        ring.setAlpha((int) (140 * fade));
        c.drawCircle(cx, cy, r * 1.25f, ring);

        txt.setColor(text);
        txt.setAlpha((int) (255 * fade));
        txt.setTextSize(r * 0.42f);
        txt.setLetterSpacing(0.25f);
        txt.setShadowLayer(dp(10), 0, 0, accent);
        c.drawText("VEUS//SPEED", cx, cy + r * 0.15f, txt);
        txt.clearShadowLayer();

        txt.setTextSize(dp(12));
        txt.setLetterSpacing(0.12f);
        float y = cy + r * 1.9f;
        for (int i = 0; i < LINES.length; i++) {
            float t0 = 0.12f + i * 0.13f;
            if (progress < t0) break;
            boolean ok = progress > t0 + 0.09f;
            txt.setColor(ok ? accent : sub);
            txt.setAlpha((int) (230 * fade));
            c.drawText((ok ? "[ OK ]  " : "[ .. ]  ") + LINES[i], cx, y, txt);
            y += dp(22);
        }
        if (progress > 0.78f) {
            txt.setColor(text);
            txt.setAlpha((int) (255 * fade));
            txt.setTextSize(dp(15));
            txt.setLetterSpacing(0.3f);
            c.drawText("SYSTEM ONLINE", cx, y + dp(14), txt);
        }
    }
}
