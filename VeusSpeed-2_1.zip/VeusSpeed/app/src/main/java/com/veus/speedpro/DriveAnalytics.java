package com.veus.speedpro;

import android.location.Location;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Derives everything that can be computed from the GPS stream alone (no extra sensors):
 * longitudinal/lateral g-force, harsh-event counters, eco score, altitude statistics,
 * stop counting, over-limit time, the 2-minute speed history and the breadcrumb route.
 */
public class DriveAnalytics {

    public static final class Pt {
        public final double lat, lon;
        public final float spd, alt;
        public final long t;

        public Pt(double lat, double lon, float spd, float alt, long t) {
            this.lat = lat; this.lon = lon; this.spd = spd; this.alt = alt; this.t = t;
        }
    }

    private static final int HIST = 150;
    private static final int MAX_PTS = 20000;
    private static final float G = 9.80665f;

    private final ArrayList<Pt> route = new ArrayList<>();
    private final float[] hist = new float[HIST];
    private int histCount, histHead;
    private long lastHistMs;

    // live physics
    public float gLong, gLat, accel;
    public float peakAccelG, peakBrakeG, peakLatG;
    public int harshAccel, harshBrake, harshCorner, stops;
    public long overLimitMs, stoppedMs;
    public double ascent, descent;
    public double minAlt = Double.NaN, maxAlt = Double.NaN, altitude = Double.NaN;
    public float vSpeed;

    private long prevFixMs = -1;
    private double prevV;
    private float prevBearing = Float.NaN;
    private float accelEma, latEma;
    private long lastHarshA, lastHarshB, lastHarshC;
    private boolean wasMoving, stopCounted;
    private long stopStartMs = -1;
    private double refAlt = Double.NaN, altEma = Double.NaN, prevAlt = Double.NaN;
    private Pt lastPt;

    public void reset() {
        route.clear();
        histCount = histHead = 0;
        lastHistMs = 0;
        gLong = gLat = accel = 0;
        peakAccelG = peakBrakeG = peakLatG = 0;
        harshAccel = harshBrake = harshCorner = stops = 0;
        overLimitMs = stoppedMs = 0;
        ascent = descent = 0;
        minAlt = maxAlt = altitude = Double.NaN;
        vSpeed = 0;
        prevFixMs = -1;
        prevV = 0;
        prevBearing = Float.NaN;
        accelEma = latEma = 0;
        lastHarshA = lastHarshB = lastHarshC = 0;
        wasMoving = stopCounted = false;
        stopStartMs = -1;
        refAlt = altEma = prevAlt = Double.NaN;
        lastPt = null;
    }

    /** Called by SpeedTracker for every GPS fix. fixMs is on the elapsed-realtime clock. */
    public void onFix(Location loc, double v, long fixMs, long dtMs, int limitKmh, boolean good) {
        // ---- kinematics ------------------------------------------------------------------
        if (prevFixMs >= 0 && fixMs > prevFixMs && fixMs - prevFixMs < 3000) {
            double dt = (fixMs - prevFixMs) / 1000.0;
            double a = (v - prevV) / dt;
            accelEma = (float) (accelEma * 0.6 + a * 0.4);
            accel = accelEma;
            gLong = clamp(accelEma / G);
            if (v > 4 && loc.hasBearing() && !Float.isNaN(prevBearing)) {
                double db = loc.getBearing() - prevBearing;
                while (db > 180) db -= 360;
                while (db < -180) db += 360;
                double lat = v * Math.toRadians(db) / dt;
                latEma = (float) (latEma * 0.6 + lat * 0.4);
            } else {
                latEma *= 0.5f;
            }
            gLat = clamp(latEma / G);
            if (gLong > peakAccelG) peakAccelG = gLong;
            if (-gLong > peakBrakeG) peakBrakeG = -gLong;
            if (Math.abs(gLat) > peakLatG) peakLatG = Math.abs(gLat);
            if (v > 2) {
                if (gLong > 0.30f && fixMs - lastHarshA > 4000) { harshAccel++; lastHarshA = fixMs; }
                if (gLong < -0.35f && fixMs - lastHarshB > 4000) { harshBrake++; lastHarshB = fixMs; }
                if (Math.abs(gLat) > 0.38f && fixMs - lastHarshC > 4000) { harshCorner++; lastHarshC = fixMs; }
            }
        }
        prevFixMs = fixMs;
        prevV = v;
        prevBearing = (v > 4 && loc.hasBearing()) ? loc.getBearing() : Float.NaN;

        // ---- stops / over-limit ------------------------------------------------------------
        if (v > 0) {
            wasMoving = true;
            stopStartMs = -1;
            stopCounted = false;
        } else {
            if (stopStartMs < 0) stopStartMs = fixMs;
            if (wasMoving) {
                stoppedMs += dtMs;
                if (!stopCounted && fixMs - stopStartMs >= 4000) { stops++; stopCounted = true; }
            }
        }
        if (limitKmh > 0 && v * 3.6 > limitKmh) overLimitMs += dtMs;

        // ---- altitude ------------------------------------------------------------------------
        if (loc.hasAltitude() && good) {
            double alt = loc.getAltitude();
            altEma = Double.isNaN(altEma) ? alt : altEma * 0.7 + alt * 0.3;
            altitude = altEma;
            if (Double.isNaN(refAlt)) { refAlt = altEma; minAlt = maxAlt = altEma; }
            if (altEma - refAlt >= 3) { ascent += altEma - refAlt; refAlt = altEma; }
            else if (refAlt - altEma >= 3) { descent += refAlt - altEma; refAlt = altEma; }
            minAlt = Math.min(minAlt, altEma);
            maxAlt = Math.max(maxAlt, altEma);
            if (!Double.isNaN(prevAlt) && dtMs > 0) {
                double vs = (altEma - prevAlt) / (dtMs / 1000.0);
                vSpeed = (float) (vSpeed * 0.7 + vs * 0.3);
            }
            prevAlt = altEma;
        }

        // ---- 1 Hz speed history ---------------------------------------------------------------
        if (fixMs - lastHistMs >= 1000) {
            lastHistMs = fixMs;
            hist[histHead] = (float) v;
            histHead = (histHead + 1) % HIST;
            if (histCount < HIST) histCount++;
        }

        // ---- breadcrumb route -----------------------------------------------------------------
        if (good && route.size() < MAX_PTS && (v > 0 || route.isEmpty())) {
            boolean add = lastPt == null;
            if (!add) {
                float[] r = new float[1];
                Location.distanceBetween(lastPt.lat, lastPt.lon, loc.getLatitude(), loc.getLongitude(), r);
                add = r[0] >= 8f || fixMs - lastPt.t >= 5000;
            }
            if (add) {
                lastPt = new Pt(loc.getLatitude(), loc.getLongitude(), (float) v,
                        loc.hasAltitude() ? (float) altitudeOrRaw(loc) : 0f, fixMs);
                route.add(lastPt);
            }
        }
    }

    private double altitudeOrRaw(Location loc) {
        return Double.isNaN(altitude) ? loc.getAltitude() : altitude;
    }

    private static float clamp(float v) {
        return Math.max(-1.5f, Math.min(1.5f, v));
    }

    /** 0..100 smoothness score, or -1 while the trip is too short to judge. */
    public int ecoScore(double distanceM, long movingMs) {
        if (distanceM < 300) return -1;
        double km = Math.max(1.0, distanceM / 1000.0);
        double penalty = (harshAccel * 3.0 + harshBrake * 4.0 + harshCorner * 2.5) / km * 6.0;
        double over = overLimitMs / (double) Math.max(1, movingMs) * 25.0;
        return (int) Math.round(Math.max(0, Math.min(100, 100 - penalty - over)));
    }

    /** Oldest-to-newest speed samples in m/s. */
    public float[] historySnapshot() {
        float[] out = new float[histCount];
        int start = (histHead - histCount + HIST) % HIST;
        for (int i = 0; i < histCount; i++) out[i] = hist[(start + i) % HIST];
        return out;
    }

    public List<Pt> route() {
        return Collections.unmodifiableList(route);
    }
}
