package com.veus.speedpro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;

/** Pace-keeper bar: centre = on target, left = too slow, right = too fast (+/-15 km/h full scale). */
public class DeltaBarView extends NeonView {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private float deltaKmh;

    public DeltaBarView(Context c) { super(c); }
    public DeltaBarView(Context c, AttributeSet a) { super(c, a); }
    public DeltaBarView(Context c, AttributeSet a, int s) { super(c, a, s); }

    public void setDelta(float kmh) {
        deltaKmh = kmh;
        invalidate();
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), Math.round(dp(26)));
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), cx = w / 2f;
        float barH = dp(10), top = (h - barH) / 2f;
        r.set(0, top, w, top + barH);
        p.setColor(alpha(track, 255));
        c.drawRoundRect(r, barH / 2f, barH / 2f, p);
        float f = Math.max(-1f, Math.min(1f, deltaKmh / 15f));
        float abs = Math.abs(deltaKmh);
        int col = abs < 3 ? accent : (abs < 8 ? ThemeHelper.AMBER : danger);
        p.setColor(col);
        if (f >= 0) r.set(cx, top, cx + f * cx, top + barH);
        else r.set(cx + f * cx, top, cx, top + barH);
        c.drawRoundRect(r, barH / 2f, barH / 2f, p);
        p.setColor(text);
        p.setStrokeWidth(dp(2));
        c.drawLine(cx, top - dp(3), cx, top + barH + dp(3), p);
    }
}
