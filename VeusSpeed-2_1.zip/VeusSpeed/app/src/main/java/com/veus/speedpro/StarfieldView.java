package com.veus.speedpro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;

import java.util.Random;

/** Deep-space background: a warp-speed starfield and a synthwave floor grid that accelerate with the vehicle. */
public class StarfieldView extends NeonView {
    private static final int N = 70;
    private final float[] sx = new float[N], sy = new float[N], sz = new float[N];
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rnd = new Random(7);
    private float speedFrac, shown, phase;
    private boolean enabled = true, dark = true;
    private long last;

    public StarfieldView(Context c) { super(c); init(); }
    public StarfieldView(Context c, AttributeSet a) { super(c, a); init(); }
    public StarfieldView(Context c, AttributeSet a, int s) { super(c, a, s); init(); }

    private void init() {
        p.setStrokeCap(Paint.Cap.ROUND);
        for (int i = 0; i < N; i++) respawn(i, true);
    }

    private void respawn(int i, boolean anyDepth) {
        sx[i] = rnd.nextFloat() * 2f - 1f;
        sy[i] = rnd.nextFloat() * 2f - 1f;
        sz[i] = anyDepth ? 0.05f + rnd.nextFloat() * 0.95f : 1f;
    }

    public void setSpeedFrac(float f) { speedFrac = Math.max(0f, Math.min(1f, f)); }

    public void setEffectsEnabled(boolean on) {
        enabled = on;
        invalidate();
    }

    public void setDarkTheme(boolean d) { dark = d; }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        last = 0;
    }

    @Override
    protected void onDraw(Canvas c) {
        if (!enabled) return;
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        shown += (speedFrac - shown) * Math.min(1f, dt * 3f);
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h * 0.42f;
        float scale = Math.max(w, h) * 0.55f;
        float tail = 0.015f + shown * 0.10f;
        int starColor = dark ? 0xFFFFFFFF : accent;

        // floor grid
        float horizon = h * 0.58f;
        float gridAlpha = dark ? 38 : 26;
        p.setColor(accent);
        p.setStrokeWidth(dp(1));
        phase = (phase + dt * (0.12f + shown * 2.2f)) % 1f;
        for (int k = 0; k < 9; k++) {
            float f = (k + phase) / 9f;
            float y = horizon + (h - horizon) * f * f;
            p.setAlpha((int) (gridAlpha * (0.25f + f)));
            c.drawLine(0, y, w, y, p);
        }
        for (int i = -7; i <= 7; i++) {
            p.setAlpha((int) (gridAlpha * 0.8f));
            c.drawLine(cx, horizon, cx + i * w * 0.30f, h, p);
        }

        // stars
        for (int i = 0; i < N; i++) {
            sz[i] -= dt * (0.015f + shown * 0.85f);
            if (sz[i] <= 0.03f) respawn(i, false);
            float z = sz[i];
            float px = cx + sx[i] / z * scale * 0.25f;
            float py = cy + sy[i] / z * scale * 0.25f;
            if (px < -20 || px > w + 20 || py < -20 || py > h + 20) { respawn(i, false); continue; }
            float zt = z + tail;
            float qx = cx + sx[i] / zt * scale * 0.25f;
            float qy = cy + sy[i] / zt * scale * 0.25f;
            int a = (int) (255 * Math.min(1f, (1.05f - z) * (dark ? 1f : 0.45f)));
            p.setColor(starColor);
            p.setAlpha(Math.max(0, Math.min(255, a)));
            p.setStrokeWidth(dp(0.8f) + (1f - z) * dp(1.6f));
            c.drawLine(qx, qy, px, py, p);
        }
        postInvalidateOnAnimation();
    }
}
