package com.veus.speedpro;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

/** Base class for the custom instrument views: shares one palette and a few helpers. */
public abstract class NeonView extends View {
    protected int accent = 0xFF00E5FF;
    protected int track = 0xFF1B2636;
    protected int text = 0xFFEAF4FF;
    protected int sub = 0xFF7F93AB;
    protected int danger = 0xFFFF3B47;

    public NeonView(Context c) { super(c); }
    public NeonView(Context c, AttributeSet a) { super(c, a); }
    public NeonView(Context c, AttributeSet a, int s) { super(c, a, s); }

    public void setPalette(int accent, int track, int text, int sub, int danger) {
        this.accent = accent;
        this.track = track;
        this.text = text;
        this.sub = sub;
        this.danger = danger;
        invalidate();
    }

    protected float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    protected static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, a)) << 24);
    }
}
