package com.veus.speedpro;

import android.app.Application;

import java.util.ArrayList;

/** Holds the trip tracker and data stores so trip stats survive activity recreation (rotation, theme change). */
public class SpeedApp extends Application {
    /** The boot animation only plays once per process. */
    public static boolean booted;
    /** True while MainActivity is started (on screen). Used by the Pit Crew service. */
    public static volatile boolean uiVisible;

    private SpeedTracker tracker;
    private TripStore trips;
    private WaypointStore waypoints;

    @Override
    public void onCreate() {
        super.onCreate();
        ThemeHelper.applyNightMode(new Prefs(this).getThemeMode());
        tracker = new SpeedTracker(this);
        trips = new TripStore(this);
        waypoints = new WaypointStore(this);
    }

    /** Saves the running trip (if >= 100 m), updates lifetime stats and resets the tracker. Returns the saved trip or null. */
    public TripStore.Trip finishTrip() {
        TripStore.Trip t = null;
        if (tracker.getDistanceM() >= 100) {
            t = tracker.buildTrip();
            trips.insert(t, new ArrayList<>(tracker.analytics.route()));
            Prefs p = new Prefs(this);
            p.addLifetimeM(t.distM);
            if (t.maxMs > p.getTopMs()) p.setTopMs(t.maxMs);
        }
        tracker.reset();
        return t;
    }

    public SpeedTracker getTracker() { return tracker; }
    public TripStore getTrips() { return trips; }
    public WaypointStore getWaypoints() { return waypoints; }
}
