package com.veus.speedpro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.AttributeSet;

/** G-ball: shows longitudinal (up = acceleration) and lateral (right = right turn) g with a fading trail. */
public class GForceView extends NeonView {
    private static final float RANGE_G = 0.8f;
    private static final int TRAIL = 22;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float[] tx = new float[TRAIL], ty = new float[TRAIL];
    private int head, count;
    private float gx, gy;

    public GForceView(Context c) { super(c); init(); }
    public GForceView(Context c, AttributeSet a) { super(c, a); init(); }
    public GForceView(Context c, AttributeSet a, int s) { super(c, a, s); init(); }

    private void init() {
        p.setStrokeCap(Paint.Cap.ROUND);
    }

    /** lat: +right, long: +accelerating (both in g). */
    public void setG(float lat, float lon) {
        gx = lat;
        gy = lon;
        tx[head] = gx;
        ty[head] = gy;
        head = (head + 1) % TRAIL;
        if (count < TRAIL) count++;
        invalidate();
    }

    public void clear() { count = 0; gx = gy = 0; invalidate(); }

    @Override
    protected void onMeasure(int w, int h) {
        int size = Math.min(MeasureSpec.getSize(w), Math.round(dp(190)));
        setMeasuredDimension(size, size);
    }

    @Override
    protected void onDraw(Canvas c) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float r = Math.min(cx, cy) - dp(6);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(1));
        for (int i = 1; i <= 3; i++) {
            p.setColor(i == 3 ? accent : sub);
            p.setAlpha(i == 3 ? 150 : 70);
            c.drawCircle(cx, cy, r * i / 3f, p);
        }
        p.setColor(sub);
        p.setAlpha(80);
        c.drawLine(cx - r, cy, cx + r, cy, p);
        c.drawLine(cx, cy - r, cx, cy + r, p);
        p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.NORMAL));
        p.setStyle(Paint.Style.FILL);
        p.setTextSize(dp(9));
        p.setTextAlign(Paint.Align.CENTER);
        p.setColor(sub);
        c.drawText("ACC", cx, cy - r - dp(1) + dp(10), p);
        c.drawText("BRK", cx, cy + r - dp(2), p);

        // trail
        for (int i = 0; i < count; i++) {
            int idx = (head - 1 - i + TRAIL) % TRAIL;
            float px = cx + clampG(tx[idx]) / RANGE_G * r;
            float py = cy - clampG(ty[idx]) / RANGE_G * r;
            p.setColor(accent);
            p.setAlpha((int) (140 * (1f - i / (float) TRAIL)));
            c.drawCircle(px, py, dp(5) * (1f - i / (float) TRAIL) + dp(1), p);
        }
        float px = cx + clampG(gx) / RANGE_G * r;
        float py = cy - clampG(gy) / RANGE_G * r;
        boolean hard = Math.hypot(gx, gy) > 0.45f;
        int col = hard ? danger : accent;
        p.setColor(col);
        p.setAlpha(60);
        c.drawCircle(px, py, dp(13), p);
        p.setAlpha(255);
        c.drawCircle(px, py, dp(7), p);
        p.setColor(0xFFFFFFFF);
        c.drawCircle(px, py, dp(2.5f), p);
    }

    private static float clampG(float g) {
        return Math.max(-RANGE_G, Math.min(RANGE_G, g));
    }
}
