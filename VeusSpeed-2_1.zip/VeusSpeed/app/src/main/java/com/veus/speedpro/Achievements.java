package com.veus.speedpro;

import java.util.ArrayList;
import java.util.List;

/** Offline gamification: badges unlocked from lifetime trip statistics. */
public final class Achievements {

    public static final class Badge {
        public final String id, name, desc;
        public final boolean unlocked;

        Badge(String id, String name, String desc, boolean unlocked) {
            this.id = id; this.name = name; this.desc = desc; this.unlocked = unlocked;
        }
    }

    private Achievements() {}

    public static List<Badge> evaluate(Prefs p, TripStore.Aggregate a, WaypointStore w) {
        ArrayList<Badge> out = new ArrayList<>();
        double topKmh = Math.max(a.maxSpeed, p.getTopMs()) * 3.6;
        double totalKm = Math.max(a.totalDist, 0) / 1000.0;
        int pbs = 0;
        for (int i = 0; i < 6; i++) if (p.flt("best_" + i, 0f) > 0) pbs++;
        float b100 = p.flt("best_1", 0f);
        out.add(new Badge("first", "First Light", "Save your first trip", a.count >= 1));
        out.add(new Badge("century", "Century", "Reach 100 km/h", topKmh >= 100));
        out.add(new Badge("velocity", "Velocity", "Reach 120 km/h", topKmh >= 120));
        out.add(new Badge("marathon", "Marathoner", "42.2 km lifetime distance", totalKm >= 42.195));
        out.add(new Badge("warrior", "Road Warrior", "500 km lifetime distance", totalKm >= 500));
        out.add(new Badge("nomad", "Nomad", "2,000 km lifetime distance", totalKm >= 2000));
        out.add(new Badge("smooth", "Smooth Operator", "Eco score 90+ on a 5 km trip", a.bestEcoLong >= 90));
        out.add(new Badge("owl", "Night Owl", "Start a trip between 22:00 and 05:00", a.nightTrips >= 1));
        out.add(new Badge("sprinter", "Sprinter", "0-100 km/h in under 10 s", b100 > 0 && b100 < 10f));
        out.add(new Badge("labrat", "Lab Rat", "Set 3 performance bests", pbs >= 3));
        out.add(new Badge("pathfinder", "Pathfinder", "Drop 3 waypoints", w.count(0) >= 3));
        return out;
    }

    /** Returns the names of badges unlocked since the last call and remembers the new state. */
    public static List<String> newlyUnlocked(Prefs p, List<Badge> badges) {
        String known = "," + p.str("badges", "") + ",";
        ArrayList<String> fresh = new ArrayList<>();
        StringBuilder all = new StringBuilder();
        for (Badge b : badges) {
            if (!b.unlocked) continue;
            if (all.length() > 0) all.append(',');
            all.append(b.id);
            if (!known.contains("," + b.id + ",")) fresh.add(b.name);
        }
        p.setStr("badges", all.toString());
        return fresh;
    }
}
