package com.veus.speedpro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

import androidx.core.graphics.ColorUtils;

import java.util.Locale;

/**
 * Neon speedometer. Two looks: ANALOG (glowing sweep arc + tapered needle) and REACTOR (segmented LED ring).
 * Needle uses spring physics (slight overshoot), shows a ghost marker at the trip peak and a tick at the limit.
 * Value is expressed in the currently selected unit.
 */
public class GaugeView extends NeonView {

    public static final int STYLE_ANALOG = 1, STYLE_REACTOR = 3;

    private static final float START = 150f;
    private static final float SWEEP = 240f;
    private static final int SEGMENTS = 48;

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arcPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tickPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint valuePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint unitPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint needlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hubPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();
    private final Matrix rot = new Matrix();

    private Units unit = Units.KMH;
    private int style = STYLE_REACTOR;
    private boolean over, warn, heat = true;
    private float peakFrac = -1f, limitFrac = -1f;

    // spring state (all in 0..1 gauge fraction)
    private float target, pos, vel;
    private boolean animating;
    private long lastNs;

    public GaugeView(Context c) { super(c); init(); }
    public GaugeView(Context c, AttributeSet a) { super(c, a); init(); }
    public GaugeView(Context c, AttributeSet a, int s) { super(c, a, s); init(); }

    private void init() {
        trackPaint.setStyle(Paint.Style.STROKE);
        trackPaint.setStrokeCap(Paint.Cap.ROUND);
        arcPaint.setStyle(Paint.Style.STROKE);
        arcPaint.setStrokeCap(Paint.Cap.ROUND);
        tickPaint.setStyle(Paint.Style.STROKE);
        tickPaint.setStrokeCap(Paint.Cap.ROUND);
        labelPaint.setTextAlign(Paint.Align.CENTER);
        labelPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.NORMAL));
        valuePaint.setTextAlign(Paint.Align.CENTER);
        valuePaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        valuePaint.setLetterSpacing(0.03f);
        unitPaint.setTextAlign(Paint.Align.CENTER);
        unitPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        unitPaint.setLetterSpacing(0.25f);
        needlePaint.setStyle(Paint.Style.STROKE);
        needlePaint.setStrokeCap(Paint.Cap.ROUND);
        hubPaint.setStyle(Paint.Style.FILL);
    }

    public void setStyle(int s) {
        style = (s == STYLE_ANALOG) ? STYLE_ANALOG : STYLE_REACTOR;
        invalidate();
    }

    public void setUnit(Units u) {
        this.unit = u;
        invalidate();
    }

    public void setOver(boolean over) {
        if (this.over != over) { this.over = over; invalidate(); }
    }

    public void setWarn(boolean warn) {
        if (this.warn != warn) { this.warn = warn; invalidate(); }
    }

    public void setHeat(boolean heat) {
        this.heat = heat;
        invalidate();
    }

    /** Ghost marker for the trip's peak speed (value in the current unit; <= 0 hides it). */
    public void setPeak(float value) {
        peakFrac = value > 0 ? (float) Math.min(1.0, value / unit.gaugeMax) : -1f;
        invalidate();
    }

    /** Limit tick (value in the current unit; <= 0 hides it). */
    public void setLimit(float value) {
        limitFrac = value > 0 ? (float) Math.min(1.0, value / unit.gaugeMax) : -1f;
        invalidate();
    }

    /** Spring the needle to a new value (already in the current unit). */
    public void setSpeed(float value) {
        target = (float) (value / unit.gaugeMax);
        if (!animating) {
            animating = true;
            lastNs = 0;
            postOnAnimation(stepper);
        }
    }

    private final Runnable stepper = new Runnable() {
        @Override public void run() {
            long now = System.nanoTime();
            float dt = lastNs == 0 ? 0.016f : Math.min(0.05f, (now - lastNs) / 1e9f);
            lastNs = now;
            float k = 85f, c = 2f * (float) Math.sqrt(k) * 0.72f;
            float a = -k * (pos - target) - c * vel;
            vel += a * dt;
            pos += vel * dt;
            if (Math.abs(pos - target) < 0.0004f && Math.abs(vel) < 0.004f) {
                pos = target;
                vel = 0;
                animating = false;
            } else {
                postOnAnimation(this);
            }
            invalidate();
        }
    };

    @Override
    protected void onDetachedFromWindow() {
        removeCallbacks(stepper);
        animating = false;
        super.onDetachedFromWindow();
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int w = View.MeasureSpec.getSize(widthSpec);
        int cap = Math.round(380 * getResources().getDisplayMetrics().density);
        int h = Math.min(Math.round(w * 0.95f), cap);
        setMeasuredDimension(w, h);
    }

    private int activeColor(float frac) {
        if (over) return danger;
        if (warn) return ThemeHelper.AMBER;
        return heat ? ThemeHelper.heat(accent, frac) : accent;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h * 0.5f;
        float r = Math.min(w * 0.45f, h * 0.42f);
        float stroke = r * 0.09f;
        float frac = Math.max(0f, Math.min(1f, pos));
        float drawFrac = Math.max(0f, Math.min(1.02f, pos));
        int active = activeColor(frac);

        if (style == STYLE_REACTOR) drawReactor(canvas, cx, cy, r, frac, active);
        else drawAnalog(canvas, cx, cy, r, stroke, frac, drawFrac, active);

        // value + unit with a soft glow
        valuePaint.setColor(over ? danger : text);
        valuePaint.setShadowLayer(r * 0.14f, 0, 0, alpha(active, 200));
        String value = String.format(Locale.US, "%." + unit.decimals + "f", pos * unit.gaugeMax);
        unitPaint.setColor(sub);
        if (style == STYLE_REACTOR) {
            valuePaint.setTextSize(r * 0.46f);
            canvas.drawText(value, cx, cy + r * 0.16f, valuePaint);
            unitPaint.setTextSize(r * 0.12f);
            canvas.drawText(unit.label.toUpperCase(Locale.US), cx, cy + r * 0.42f, unitPaint);
        } else {
            valuePaint.setTextSize(r * 0.32f);
            canvas.drawText(value, cx, cy + r * 0.74f, valuePaint);
            unitPaint.setTextSize(r * 0.12f);
            canvas.drawText(unit.label.toUpperCase(Locale.US), cx, cy + r * 0.95f, unitPaint);
        }
        valuePaint.clearShadowLayer();
    }

    private void drawAnalog(Canvas canvas, float cx, float cy, float r, float stroke, float frac, float drawFrac, int active) {
        trackPaint.setColor(alpha(track, 255));
        trackPaint.setStrokeWidth(stroke);
        float arcR = r - stroke / 2f;
        oval.set(cx - arcR, cy - arcR, cx + arcR, cy + arcR);

        // faint outer HUD ring
        tickPaint.setColor(alpha(accent, 60));
        tickPaint.setStrokeWidth(r * 0.01f);
        canvas.drawArc(oval.left - stroke * 0.9f, oval.top - stroke * 0.9f,
                oval.right + stroke * 0.9f, oval.bottom + stroke * 0.9f, START, SWEEP, false, tickPaint);

        canvas.drawArc(oval, START, SWEEP, false, trackPaint);

        if (drawFrac > 0.002f) {
            // soft glow: three widening, fading passes
            arcPaint.setShader(null);
            arcPaint.setColor(alpha(active, 26));
            arcPaint.setStrokeWidth(stroke * 2.7f);
            canvas.drawArc(oval, START, SWEEP * drawFrac, false, arcPaint);
            arcPaint.setColor(alpha(active, 48));
            arcPaint.setStrokeWidth(stroke * 1.9f);
            canvas.drawArc(oval, START, SWEEP * drawFrac, false, arcPaint);
            arcPaint.setColor(alpha(active, 90));
            arcPaint.setStrokeWidth(stroke * 1.3f);
            canvas.drawArc(oval, START, SWEEP * drawFrac, false, arcPaint);

            // gradient core: dim at the start, full colour at the needle
            float endPos = Math.max(0.01f, drawFrac * (SWEEP / 360f));
            int c0 = ColorUtils.setAlphaComponent(accent, 90);
            SweepGradient sg = new SweepGradient(cx, cy, new int[]{c0, active, active},
                    new float[]{0f, endPos, 1f});
            rot.setRotate(START, cx, cy);
            sg.setLocalMatrix(rot);
            arcPaint.setShader(sg);
            arcPaint.setStrokeWidth(stroke);
            canvas.drawArc(oval, START, SWEEP * drawFrac, false, arcPaint);
            arcPaint.setShader(null);
        }

        // ticks and labels
        int n = (int) Math.round(unit.gaugeMax / unit.majorStep);
        if (n < 1) n = 1;
        int labelEvery = n > 9 ? 2 : 1;
        int decimals = unit.majorStep < 1 ? 2 : 0;
        float tickOuter = r - stroke * 1.4f;
        tickPaint.setColor(sub);
        labelPaint.setColor(sub);
        labelPaint.setTextSize(r * 0.095f);
        for (int i = 0; i <= n; i++) {
            float angle = START + SWEEP * ((float) i / n);
            double rad = Math.toRadians(angle);
            float cos = (float) Math.cos(rad), sin = (float) Math.sin(rad);
            boolean lit = ((float) i / n) <= frac;
            tickPaint.setColor(lit ? active : sub);
            tickPaint.setStrokeWidth(r * 0.022f);
            canvas.drawLine(cx + cos * tickOuter, cy + sin * tickOuter,
                    cx + cos * (tickOuter - r * 0.09f), cy + sin * (tickOuter - r * 0.09f), tickPaint);
            if (i % labelEvery == 0) {
                String t = String.format(Locale.US, "%." + decimals + "f", i * unit.majorStep);
                float lr = tickOuter - r * 0.22f;
                labelPaint.setColor(lit ? text : sub);
                canvas.drawText(t, cx + cos * lr, cy + sin * lr + labelPaint.getTextSize() * 0.35f, labelPaint);
            }
            if (i < n) {
                tickPaint.setColor(sub);
                tickPaint.setStrokeWidth(r * 0.012f);
                for (int j = 1; j < 5; j++) {
                    float a2 = START + SWEEP * ((i + j / 5f) / n);
                    double r2 = Math.toRadians(a2);
                    float c2 = (float) Math.cos(r2), s2 = (float) Math.sin(r2);
                    canvas.drawLine(cx + c2 * tickOuter, cy + s2 * tickOuter,
                            cx + c2 * (tickOuter - r * 0.045f), cy + s2 * (tickOuter - r * 0.045f), tickPaint);
                }
            }
        }

        // limit tick + peak ghost, drawn across the arc
        if (limitFrac > 0) radialMark(canvas, cx, cy, arcR, stroke * 1.25f, limitFrac, danger, stroke * 0.28f);
        if (peakFrac > 0) radialMark(canvas, cx, cy, arcR, stroke * 0.95f, peakFrac, 0xFFFFFFFF, stroke * 0.22f);

        // tapered needle with glow + hub
        float needleAngle = START + SWEEP * drawFrac;
        double nr = Math.toRadians(needleAngle);
        float cos = (float) Math.cos(nr), sin = (float) Math.sin(nr);
        float nl = tickOuter - r * 0.12f;
        needlePaint.setColor(alpha(active, 50));
        needlePaint.setStrokeWidth(r * 0.09f);
        canvas.drawLine(cx, cy, cx + cos * nl, cy + sin * nl, needlePaint);
        needlePaint.setColor(active);
        needlePaint.setStrokeWidth(r * 0.035f);
        canvas.drawLine(cx - cos * r * 0.08f, cy - sin * r * 0.08f, cx + cos * nl, cy + sin * nl, needlePaint);
        hubPaint.setColor(alpha(active, 70));
        canvas.drawCircle(cx, cy, r * 0.13f, hubPaint);
        hubPaint.setColor(active);
        canvas.drawCircle(cx, cy, r * 0.075f, hubPaint);
        hubPaint.setColor(track);
        canvas.drawCircle(cx, cy, r * 0.03f, hubPaint);
    }

    private void radialMark(Canvas canvas, float cx, float cy, float arcR, float halfLen, float frac, int color, float width) {
        double rad = Math.toRadians(START + SWEEP * frac);
        float cos = (float) Math.cos(rad), sin = (float) Math.sin(rad);
        tickPaint.setColor(color);
        tickPaint.setStrokeWidth(width);
        canvas.drawLine(cx + cos * (arcR - halfLen), cy + sin * (arcR - halfLen),
                cx + cos * (arcR + halfLen), cy + sin * (arcR + halfLen), tickPaint);
    }

    private void drawReactor(Canvas canvas, float cx, float cy, float r, float frac, int active) {
        float outer = r * 0.98f, inner = r * 0.74f;
        float segW = (float) (Math.PI * 2 * outer * (SWEEP / 360f) / SEGMENTS) * 0.55f;
        arcPaint.setShader(null);
        arcPaint.setStrokeCap(Paint.Cap.BUTT);
        arcPaint.setStrokeWidth(segW);
        int lit = Math.round(frac * SEGMENTS);
        int peakIdx = peakFrac > 0 ? Math.min(SEGMENTS - 1, Math.round(peakFrac * SEGMENTS)) : -1;
        int limitIdx = limitFrac > 0 ? Math.min(SEGMENTS - 1, Math.round(limitFrac * SEGMENTS)) : -1;
        for (int i = 0; i < SEGMENTS; i++) {
            float f = (float) i / SEGMENTS;
            double rad = Math.toRadians(START + SWEEP * ((i + 0.5f) / SEGMENTS));
            float cos = (float) Math.cos(rad), sin = (float) Math.sin(rad);
            boolean on = i < lit;
            int col;
            if (i == limitIdx) col = danger;
            else if (i == peakIdx && !on) col = 0xFFFFFFFF;
            else if (on) col = over ? danger : (warn ? ThemeHelper.AMBER : (heat ? ThemeHelper.heat(accent, f) : accent));
            else col = alpha(track, 255);
            float in = (i == limitIdx || i == peakIdx) ? inner - r * 0.05f : inner;
            // glow underlay for lit segments
            if (on) {
                arcPaint.setColor(alpha(col, 40));
                arcPaint.setStrokeWidth(segW * 2.2f);
                canvas.drawLine(cx + cos * in, cy + sin * in, cx + cos * outer, cy + sin * outer, arcPaint);
                arcPaint.setStrokeWidth(segW);
            }
            arcPaint.setColor(col);
            canvas.drawLine(cx + cos * in, cy + sin * in, cx + cos * outer, cy + sin * outer, arcPaint);
        }
        arcPaint.setStrokeCap(Paint.Cap.ROUND);

        // inner hairline rings
        float ringR = inner - r * 0.08f;
        oval.set(cx - ringR, cy - ringR, cx + ringR, cy + ringR);
        tickPaint.setStrokeWidth(r * 0.012f);
        tickPaint.setColor(alpha(active, 120));
        canvas.drawArc(oval, START, SWEEP * frac, false, tickPaint);
        tickPaint.setColor(alpha(sub, 90));
        if (frac < 1f) canvas.drawArc(oval, START + SWEEP * frac, SWEEP * (1f - frac), false, tickPaint);

        // scale labels at 0 / half / max
        labelPaint.setColor(sub);
        labelPaint.setTextSize(r * 0.09f);
        int decimals = unit.majorStep < 1 ? 2 : 0;
        float lr = r * 0.62f;
        String[] marks = {"0", String.format(Locale.US, "%." + decimals + "f", unit.gaugeMax / 2),
                String.format(Locale.US, "%." + decimals + "f", unit.gaugeMax)};
        float[] fr = {0f, 0.5f, 1f};
        for (int i = 0; i < 3; i++) {
            double rad = Math.toRadians(START + SWEEP * fr[i]);
            canvas.drawText(marks[i], cx + (float) Math.cos(rad) * lr,
                    cy + (float) Math.sin(rad) * lr + labelPaint.getTextSize() * 0.35f, labelPaint);
        }
    }
}
