package com.veus.speedpro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;

import java.util.List;

/** Offline breadcrumb map: the route drawn on a blank canvas, coloured by speed (cyan = slow, red = fast). */
public class RouteView extends NeonView {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float[] hsv = new float[3];
    private List<DriveAnalytics.Pt> pts;
    private List<WaypointStore.Wp> marks;
    private boolean live;
    private int heightDp = 240;

    public RouteView(Context c) { super(c); init(); }
    public RouteView(Context c, AttributeSet a) { super(c, a); init(); }
    public RouteView(Context c, AttributeSet a, int s) { super(c, a, s); init(); }

    private void init() {
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
    }

    public void setRoute(List<DriveAnalytics.Pt> points, List<WaypointStore.Wp> waypoints, boolean live) {
        this.pts = points;
        this.marks = waypoints;
        this.live = live;
        invalidate();
    }

    public void setHeightDp(int dp) { heightDp = dp; requestLayout(); }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), Math.round(dp(heightDp)));
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), pad = dp(18);

        // faint dotted grid backdrop
        p.setStyle(Paint.Style.FILL);
        p.setColor(alpha(sub, 40));
        for (float x = pad; x < w; x += dp(24)) for (float y = pad; y < h; y += dp(24)) c.drawCircle(x, y, dp(1), p);

        if (pts == null || pts.size() < 1) {
            p.setColor(sub);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(dp(12));
            c.drawText("No route yet - start moving", w / 2f, h / 2f, p);
            return;
        }
        int total = pts.size();
        int from = live ? Math.max(0, total - 400) : 0;
        int n = total - from;
        int stride = Math.max(1, n / 1200);

        double minLat = 1e9, maxLat = -1e9, minLon = 1e9, maxLon = -1e9;
        float minV = Float.MAX_VALUE, maxV = 0;
        for (int i = from; i < total; i += stride) {
            DriveAnalytics.Pt q = pts.get(i);
            minLat = Math.min(minLat, q.lat); maxLat = Math.max(maxLat, q.lat);
            minLon = Math.min(minLon, q.lon); maxLon = Math.max(maxLon, q.lon);
            minV = Math.min(minV, q.spd); maxV = Math.max(maxV, q.spd);
        }
        DriveAnalytics.Pt endPt = pts.get(total - 1);
        minLat = Math.min(minLat, endPt.lat); maxLat = Math.max(maxLat, endPt.lat);
        minLon = Math.min(minLon, endPt.lon); maxLon = Math.max(maxLon, endPt.lon);
        if (marks != null) {
            for (WaypointStore.Wp m : marks) {
                if (m.lat < minLat - 0.02 || m.lat > maxLat + 0.02 || m.lon < minLon - 0.02 || m.lon > maxLon + 0.02) continue;
                minLat = Math.min(minLat, m.lat); maxLat = Math.max(maxLat, m.lat);
                minLon = Math.min(minLon, m.lon); maxLon = Math.max(maxLon, m.lon);
            }
        }
        double cosLat = Math.cos(Math.toRadians((minLat + maxLat) / 2.0));
        double dx = Math.max((maxLon - minLon) * cosLat, 1e-6);
        double dy = Math.max(maxLat - minLat, 1e-6);
        double scale = Math.min((w - 2 * pad) / dx, (h - 2 * pad) / dy);
        double offX = (w - dx * scale) / 2.0, offY = (h - dy * scale) / 2.0;

        // glow underlay
        path.reset();
        boolean first = true;
        for (int i = from; i < total; i += stride) {
            DriveAnalytics.Pt q = pts.get(i);
            float x = (float) (offX + (q.lon - minLon) * cosLat * scale);
            float y = (float) (h - offY - (q.lat - minLat) * scale);
            if (first) { path.moveTo(x, y); first = false; } else path.lineTo(x, y);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setColor(alpha(accent, 40));
        p.setStrokeWidth(dp(9));
        c.drawPath(path, p);

        // speed-coloured segments
        p.setStrokeWidth(dp(3));
        float px = 0, py = 0;
        boolean have = false;
        float range = Math.max(0.5f, maxV - minV);
        for (int i = from; i < total; i += stride) {
            DriveAnalytics.Pt q = pts.get(i);
            float x = (float) (offX + (q.lon - minLon) * cosLat * scale);
            float y = (float) (h - offY - (q.lat - minLat) * scale);
            if (have) {
                float f = Math.max(0f, Math.min(1f, (q.spd - minV) / range));
                hsv[0] = 190f * (1f - f);
                hsv[1] = 0.85f;
                hsv[2] = 1f;
                p.setColor(Color.HSVToColor(hsv));
                c.drawLine(px, py, x, y, p);
            }
            px = x; py = y; have = true;
        }

        p.setStyle(Paint.Style.FILL);
        // waypoint / hazard markers
        if (marks != null) {
            for (WaypointStore.Wp m : marks) {
                if (m.lat < minLat || m.lat > maxLat || m.lon < minLon || m.lon > maxLon) continue;
                float x = (float) (offX + (m.lon - minLon) * cosLat * scale);
                float y = (float) (h - offY - (m.lat - minLat) * scale);
                p.setColor(m.type == 1 ? danger : ThemeHelper.AMBER);
                float s = dp(6);
                path.reset();
                path.moveTo(x, y - s); path.lineTo(x + s, y); path.lineTo(x, y + s); path.lineTo(x - s, y); path.close();
                c.drawPath(path, p);
            }
        }
        // start (green) / end (accent) dots
        DriveAnalytics.Pt s0 = pts.get(from);
        float sx = (float) (offX + (s0.lon - minLon) * cosLat * scale);
        float sy = (float) (h - offY - (s0.lat - minLat) * scale);
        p.setColor(0xFF00E676);
        c.drawCircle(sx, sy, dp(5), p);
        p.setColor(alpha(accent, 70));
        c.drawCircle(px, py, dp(11), p);
        p.setColor(live ? accent : danger);
        c.drawCircle(px, py, dp(5.5f), p);
        p.setColor(0xFFFFFFFF);
        c.drawCircle(px, py, dp(2), p);
    }
}
