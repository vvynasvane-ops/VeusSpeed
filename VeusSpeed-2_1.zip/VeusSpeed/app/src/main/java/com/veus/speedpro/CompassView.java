package com.veus.speedpro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.util.AttributeSet;

/** Scrolling heading ribbon (+/-60 degrees) with cardinal letters and an optional waypoint bearing marker. */
public class CompassView extends NeonView {
    private static final String[] CARD = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private float heading = Float.NaN, target = Float.NaN;

    public CompassView(Context c) { super(c); init(); }
    public CompassView(Context c, AttributeSet a) { super(c, a); init(); }
    public CompassView(Context c, AttributeSet a, int s) { super(c, a, s); init(); }

    private void init() {
        p.setStrokeCap(Paint.Cap.ROUND);
        t.setTextAlign(Paint.Align.CENTER);
        t.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
    }

    public static String cardinal(float deg) {
        int i = Math.round(((deg % 360f) + 360f) % 360f / 45f) % 8;
        return CARD[i];
    }

    public void setHeading(float deg) { heading = deg; invalidate(); }

    /** Bearing to the active waypoint in degrees, or NaN to hide the marker. */
    public void setTarget(float deg) { target = deg; invalidate(); }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), Math.round(dp(64)));
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), cx = w / 2f;
        float hd = Float.isNaN(heading) ? 0f : heading;
        float pxPerDeg = w / 120f;
        float baseY = h * 0.72f;
        boolean live = !Float.isNaN(heading);
        for (int d = (int) Math.floor(hd) - 62; d <= (int) Math.ceil(hd) + 62; d++) {
            if (d % 5 != 0) continue;
            float x = cx + (d - hd) * pxPerDeg;
            int ang = ((d % 360) + 360) % 360;
            float edge = 1f - Math.min(1f, Math.abs(x - cx) / (w / 2f));
            int a = (int) (255 * Math.min(1f, edge * 1.6f));
            boolean card = ang % 45 == 0;
            boolean mid = ang % 15 == 0;
            p.setColor(card ? accent : sub);
            p.setAlpha(live ? a : a / 3);
            p.setStrokeWidth(card ? dp(2.2f) : dp(1.2f));
            float len = card ? h * 0.26f : (mid ? h * 0.18f : h * 0.10f);
            c.drawLine(x, baseY, x, baseY - len, p);
            if (card) {
                t.setColor(ang % 90 == 0 ? text : sub);
                t.setAlpha(live ? a : a / 3);
                t.setTextSize(ang % 90 == 0 ? dp(17) : dp(13));
                c.drawText(CARD[ang / 45], x, baseY - len - dp(4), t);
            }
        }
        // centre pointer
        path.reset();
        path.moveTo(cx - dp(6), h);
        path.lineTo(cx + dp(6), h);
        path.lineTo(cx, h - dp(9));
        path.close();
        p.setStyle(Paint.Style.FILL);
        p.setColor(live ? accent : sub);
        p.setAlpha(255);
        c.drawPath(path, p);
        p.setStyle(Paint.Style.STROKE);

        // waypoint bearing marker (diamond; clamps to the ribbon edge when out of range)
        if (!Float.isNaN(target) && live) {
            float delta = ((target - hd + 540f) % 360f) - 180f;
            float clamped = Math.max(-58f, Math.min(58f, delta));
            float x = cx + clamped * pxPerDeg;
            float s = dp(7);
            path.reset();
            path.moveTo(x, baseY - dp(26) - s);
            path.lineTo(x + s, baseY - dp(26));
            path.lineTo(x, baseY - dp(26) + s);
            path.lineTo(x - s, baseY - dp(26));
            path.close();
            p.setStyle(Paint.Style.FILL);
            p.setColor(ThemeHelper.AMBER);
            p.setAlpha(delta == clamped ? 255 : 150);
            c.drawPath(path, p);
            p.setStyle(Paint.Style.STROKE);
        }
    }
}
