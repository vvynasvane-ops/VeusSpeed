package com.veus.speedpro;

import android.annotation.SuppressLint;
import android.content.Context;
import android.location.GnssStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import java.util.Arrays;

/**
 * Pure-GPS speed + trip stats via the framework LocationManager.
 * No Google Play Services needed, so it is 100% offline and works on any device.
 */
public class SpeedTracker implements LocationListener {

    public interface Listener {
        void onSpeedUpdate(SpeedTracker t);
        void onGpsState(SpeedTracker t);
    }

    private static final double NOISE_GATE_MS = 0.5;   // below this = stopped
    private static final long STALE_MS = 5000;         // no fix for this long = lost
    private static final float GOOD_ACCURACY_M = 40f;

    private final LocationManager lm;
    private final Prefs prefs;
    public final DriveAnalytics analytics = new DriveAnalytics();
    public final PerfLab perf;
    private Listener listener;

    private boolean started;
    private boolean gpsEnabled = true;
    private boolean hasFix;
    private float accuracy = -1f;

    private double speedMs, maxMs, distanceM, smoothV;
    private long movingMs, totalMs, tripStartWall;
    private long lastFixMs = -1, lastRecvElapsed = -1;
    private Location lastLoc;
    private float bearing = Float.NaN;
    private float alpha = 0.6f;
    private double calib = 1.0;

    // last ~30 samples, used by crash detection
    private final long[] rt = new long[30];
    private final float[] rv = new float[30];
    private int rn, rh;

    // GNSS status
    public volatile int satsVisible, satsUsed, cn0Count;
    public final float[] cn0 = new float[12];
    private GnssStatus.Callback gnssCb;

    public SpeedTracker(Context ctx) {
        lm = (LocationManager) ctx.getApplicationContext().getSystemService(Context.LOCATION_SERVICE);
        prefs = new Prefs(ctx);
        perf = new PerfLab(prefs);
    }

    public void setListener(Listener l) { this.listener = l; }

    @SuppressLint("MissingPermission")
    public void start() {
        if (started || lm == null) return;
        int rate = prefs.getGpsRate();
        long minTime = rate == 0 ? 250L : (rate == 2 ? 1000L : 500L);
        if (prefs.getBatterySaver()) minTime = 1000L;
        int sm = prefs.getSmoothing();
        alpha = sm == 0 ? 1.0f : (sm == 2 ? 0.35f : 0.6f);
        calib = 1.0 + prefs.getCalibPct() / 100.0;
        try {
            gpsEnabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, minTime, 0f, this, Looper.getMainLooper());
            started = true;
            registerGnss();
        } catch (SecurityException | IllegalArgumentException e) {
            started = false;
        }
        notifyGps();
    }

    @SuppressLint("MissingPermission")
    @SuppressWarnings("deprecation")
    private void registerGnss() {
        if (gnssCb != null || lm == null) return;
        try {
            gnssCb = new GnssStatus.Callback() {
                @Override
                public void onSatelliteStatusChanged(GnssStatus s) {
                    int n = s.getSatelliteCount(), used = 0, tc = 0;
                    float[] tmp = new float[n];
                    for (int i = 0; i < n; i++) {
                        if (s.usedInFix(i)) used++;
                        float c = s.getCn0DbHz(i);
                        if (c > 0) tmp[tc++] = c;
                    }
                    Arrays.sort(tmp, 0, tc);
                    int out = Math.min(cn0.length, tc);
                    for (int i = 0; i < out; i++) cn0[i] = tmp[tc - 1 - i];
                    cn0Count = out;
                    satsVisible = n;
                    satsUsed = used;
                }
            };
            lm.registerGnssStatusCallback(gnssCb, new Handler(Looper.getMainLooper()));
        } catch (Exception | Error e) {
            gnssCb = null;
        }
    }

    public void stop() {
        if (lm != null) {
            try { lm.removeUpdates(this); } catch (Exception ignored) { }
            if (gnssCb != null) {
                try { lm.unregisterGnssStatusCallback(gnssCb); } catch (Exception ignored) { }
                gnssCb = null;
            }
        }
        started = false;
        hasFix = false;
        speedMs = 0;
        smoothV = 0;
        lastLoc = null;
        lastFixMs = -1;
        satsVisible = satsUsed = cn0Count = 0;
    }

    public void reset() {
        maxMs = 0;
        distanceM = 0;
        movingMs = 0;
        totalMs = 0;
        speedMs = 0;
        smoothV = 0;
        tripStartWall = 0;
        rn = rh = 0;
        analytics.reset();
        notifySpeed();
    }

    /** Call about once per second from the UI to detect a lost GPS fix. */
    public void tick() {
        if (!started) return;
        boolean enabledNow = true;
        try { enabledNow = lm.isProviderEnabled(LocationManager.GPS_PROVIDER); } catch (Exception ignored) { }
        boolean changed = enabledNow != gpsEnabled;
        gpsEnabled = enabledNow;
        if (hasFix && SystemClock.elapsedRealtime() - lastRecvElapsed > STALE_MS) {
            hasFix = false;
            speedMs = 0;
            smoothV = 0;
            changed = true;
            notifySpeed();
        }
        if (changed) notifyGps();
    }

    @Override
    public void onLocationChanged(Location loc) {
        long recv = SystemClock.elapsedRealtime();
        long fixMs = loc.getElapsedRealtimeNanos() / 1_000_000L;
        double raw;
        if (loc.hasSpeed()) {
            raw = loc.getSpeed();
        } else if (lastLoc != null) {
            double dt = (loc.getTime() - lastLoc.getTime()) / 1000.0;
            raw = dt > 0 ? loc.distanceTo(lastLoc) / dt : 0;
        } else {
            raw = 0;
        }
        raw *= calib;
        if (raw < NOISE_GATE_MS) raw = 0;
        double v = raw == 0 ? 0 : (smoothV <= 0 ? raw : smoothV + alpha * (raw - smoothV));
        smoothV = v;

        boolean good = !loc.hasAccuracy() || loc.getAccuracy() <= GOOD_ACCURACY_M;
        accuracy = loc.hasAccuracy() ? loc.getAccuracy() : -1f;

        long dtMs = (lastFixMs < 0) ? 0 : Math.max(0L, Math.min(fixMs - lastFixMs, 10000L));
        lastFixMs = fixMs;
        lastRecvElapsed = recv;
        if (tripStartWall == 0) tripStartWall = System.currentTimeMillis();
        totalMs += dtMs;
        if (v > 0 && good) {
            movingMs += dtMs;
            distanceM += v * (dtMs / 1000.0);
            if (v > maxMs) maxMs = v;
        }
        if (loc.hasBearing() && v > 1.0) bearing = loc.getBearing();

        analytics.onFix(loc, v, fixMs, dtMs, prefs.getSpeedLimitKmh(), good);
        if (good) perf.onSample(raw, fixMs, raw * dtMs / 1000.0);

        rt[rh] = fixMs;
        rv[rh] = (float) v;
        rh = (rh + 1) % rt.length;
        if (rn < rt.length) rn++;

        boolean fixChanged = !hasFix;
        hasFix = true;
        speedMs = v;
        lastLoc = loc;
        notifySpeed();
        if (fixChanged) notifyGps();
    }

    @Override public void onProviderEnabled(String provider) {
        if (LocationManager.GPS_PROVIDER.equals(provider)) { gpsEnabled = true; notifyGps(); }
    }

    @Override public void onProviderDisabled(String provider) {
        if (LocationManager.GPS_PROVIDER.equals(provider)) {
            gpsEnabled = false;
            hasFix = false;
            speedMs = 0;
            notifySpeed();
            notifyGps();
        }
    }

    @SuppressWarnings("deprecation")
    @Override public void onStatusChanged(String provider, int status, Bundle extras) { /* required on API < 30 */ }

    private void notifySpeed() { if (listener != null) listener.onSpeedUpdate(this); }
    private void notifyGps() { if (listener != null) listener.onGpsState(this); }

    /** Highest speed (m/s) seen in the last windowMs milliseconds. */
    public double getRecentMaxSpeedMs(long windowMs) {
        long now = SystemClock.elapsedRealtime();
        double m = 0;
        for (int i = 0; i < rn; i++) {
            if (now - rt[i] <= windowMs && rv[i] > m) m = rv[i];
        }
        return m;
    }

    /** Snapshot of the running trip for the trip log. */
    public TripStore.Trip buildTrip() {
        TripStore.Trip t = new TripStore.Trip();
        t.startMs = tripStartWall > 0 ? tripStartWall : System.currentTimeMillis() - totalMs;
        t.durMs = totalMs;
        t.movMs = movingMs;
        t.distM = distanceM;
        t.maxMs = (float) maxMs;
        t.avgMs = (float) getAvgMs();
        t.eco = analytics.ecoScore(distanceM, movingMs);
        t.hAccel = analytics.harshAccel;
        t.hBrake = analytics.harshBrake;
        t.hCorner = analytics.harshCorner;
        t.overMs = analytics.overLimitMs;
        t.ascent = analytics.ascent;
        t.descent = analytics.descent;
        java.util.Calendar c = java.util.Calendar.getInstance();
        c.setTimeInMillis(t.startMs);
        t.hour = c.get(java.util.Calendar.HOUR_OF_DAY);
        return t;
    }

    public boolean isStarted() { return started; }
    public boolean isGpsEnabled() { return gpsEnabled; }
    public boolean hasFix() { return hasFix; }
    public float getAccuracy() { return accuracy; }
    public double getSpeedMs() { return speedMs; }
    public double getMaxMs() { return maxMs; }
    public double getAvgMs() { return movingMs > 0 ? distanceM / (movingMs / 1000.0) : 0; }
    public double getDistanceM() { return distanceM; }
    public long getTotalMs() { return totalMs; }
    public long getMovingMs() { return movingMs; }
    public float getBearing() { return bearing; }
    public Location getLastLocation() { return lastLoc; }
}
