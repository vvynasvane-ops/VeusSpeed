package com.veus.speedpro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;

/** GNSS signal strength bars (C/N0 per satellite in the fix, strongest first). */
public class SatView extends NeonView {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private float[] cn0 = new float[0];

    public SatView(Context c) { super(c); }
    public SatView(Context c, AttributeSet a) { super(c, a); }
    public SatView(Context c, AttributeSet a, int s) { super(c, a, s); }

    public void setData(float[] values, int count) {
        cn0 = new float[count];
        System.arraycopy(values, 0, cn0, 0, count);
        invalidate();
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), Math.round(dp(56)));
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        int slots = 12;
        float slot = w / slots;
        float bw = slot * 0.6f;
        for (int i = 0; i < slots; i++) {
            float cx = slot * (i + 0.5f);
            r.set(cx - bw / 2f, 2, cx + bw / 2f, h);
            p.setColor(alpha(track, 255));
            c.drawRoundRect(r, dp(3), dp(3), p);
            if (i < cn0.length) {
                float f = Math.max(0.05f, Math.min(1f, cn0[i] / 50f));
                int col = cn0[i] >= 30 ? accent : (cn0[i] >= 20 ? ThemeHelper.AMBER : danger);
                p.setColor(col);
                r.set(cx - bw / 2f, h - (h - 2) * f, cx + bw / 2f, h);
                c.drawRoundRect(r, dp(3), dp(3), p);
            }
        }
    }
}
