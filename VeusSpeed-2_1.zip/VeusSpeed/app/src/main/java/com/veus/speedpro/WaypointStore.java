package com.veus.speedpro;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Offline waypoints (type 0) and hazard / speed-trap pins (type 1), kept in SharedPreferences. */
public class WaypointStore {

    public static final class Wp {
        public long id;
        public String name;
        public double lat, lon;
        public int type;
    }

    public static final int MAX = 40;

    private final Prefs prefs;
    private final ArrayList<Wp> list = new ArrayList<>();

    public WaypointStore(Context c) {
        prefs = new Prefs(c);
        load();
    }

    private void load() {
        list.clear();
        try {
            JSONArray a = new JSONArray(prefs.str("waypoints", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Wp w = new Wp();
                w.id = o.getLong("id");
                w.name = o.getString("n");
                w.lat = o.getDouble("la");
                w.lon = o.getDouble("lo");
                w.type = o.optInt("t", 0);
                list.add(w);
            }
        } catch (JSONException ignored) { }
    }

    private void save() {
        JSONArray a = new JSONArray();
        for (Wp w : list) {
            JSONObject o = new JSONObject();
            try {
                o.put("id", w.id);
                o.put("n", w.name);
                o.put("la", w.lat);
                o.put("lo", w.lon);
                o.put("t", w.type);
                a.put(o);
            } catch (JSONException ignored) { }
        }
        prefs.setStr("waypoints", a.toString());
    }

    public List<Wp> all() { return Collections.unmodifiableList(list); }

    public int count(int type) {
        int n = 0;
        for (Wp w : list) if (w.type == type) n++;
        return n;
    }

    public Wp add(String name, double lat, double lon, int type) {
        if (list.size() >= MAX) return null;
        Wp w = new Wp();
        w.id = System.currentTimeMillis();
        w.name = name;
        w.lat = lat;
        w.lon = lon;
        w.type = type;
        list.add(w);
        if (type == 0) setActive(w.id);
        save();
        return w;
    }

    public void remove(long id) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id == id) { list.remove(i); break; }
        }
        if (activeId() == id) prefs.setStr("active_wp", "");
        save();
    }

    private long activeId() {
        try { return Long.parseLong(prefs.str("active_wp", "")); } catch (NumberFormatException e) { return -1; }
    }

    public Wp active() {
        long id = activeId();
        for (Wp w : list) if (w.id == id && w.type == 0) return w;
        return null;
    }

    public void setActive(long id) { prefs.setStr("active_wp", String.valueOf(id)); }

    public void clearActive() { prefs.setStr("active_wp", ""); }
}
