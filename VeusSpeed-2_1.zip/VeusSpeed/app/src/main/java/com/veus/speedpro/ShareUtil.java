package com.veus.speedpro;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/** GPX / CSV export and text sharing. Everything is written to the app cache and shared through FileProvider. */
public final class ShareUtil {
    private ShareUtil() {}

    private static File exportDir(Context c) {
        File d = new File(c.getCacheDir(), "exports");
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        return d;
    }

    public static File writeCsv(Context c, String name, String content) throws IOException {
        File f = new File(exportDir(c), name);
        try (FileWriter w = new FileWriter(f)) { w.write(content); }
        return f;
    }

    public static File writeGpx(Context c, TripStore.Trip t, List<DriveAnalytics.Pt> pts) throws IOException {
        SimpleDateFormat iso = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        iso.setTimeZone(TimeZone.getTimeZone("UTC"));
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        sb.append("<gpx version=\"1.1\" creator=\"VeusSpeed\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n");
        sb.append("<metadata><name>VeusSpeed trip ").append(t.id).append("</name></metadata>\n<trk><name>Trip ")
                .append(t.id).append("</name><trkseg>\n");
        for (DriveAnalytics.Pt p : pts) {
            sb.append(String.format(Locale.US, "<trkpt lat=\"%.6f\" lon=\"%.6f\"><ele>%.1f</ele><time>%s</time>"
                            + "<extensions><speed>%.2f</speed></extensions></trkpt>\n",
                    p.lat, p.lon, p.alt, iso.format(new Date(t.startMs + p.t)), p.spd));
        }
        sb.append("</trkseg></trk></gpx>\n");
        return writeCsv(c, "veusspeed_trip_" + t.id + ".gpx", sb.toString());
    }

    public static void shareFile(Context c, File f, String mime, String subject) {
        try {
            Uri uri = FileProvider.getUriForFile(c, c.getPackageName() + ".files", f);
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(mime);
            i.putExtra(Intent.EXTRA_STREAM, uri);
            i.putExtra(Intent.EXTRA_SUBJECT, subject);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            c.startActivity(Intent.createChooser(i, subject));
        } catch (Exception e) {
            Toast.makeText(c, "Could not share file", Toast.LENGTH_SHORT).show();
        }
    }

    public static void shareText(Context c, String subject, String text) {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT, subject);
            i.putExtra(Intent.EXTRA_TEXT, text);
            c.startActivity(Intent.createChooser(i, subject));
        } catch (Exception e) {
            Toast.makeText(c, "Nothing to share with", Toast.LENGTH_SHORT).show();
        }
    }

    public static String tripSummary(TripStore.Trip t, Units u) {
        SimpleDateFormat f = new SimpleDateFormat("EEE d MMM yyyy, HH:mm", Locale.getDefault());
        long s = t.durMs / 1000;
        StringBuilder sb = new StringBuilder("VeusSpeed trip - ").append(f.format(new Date(t.startMs))).append('\n');
        sb.append("Distance: ").append(u.formatDistance(t.distM)).append('\n');
        sb.append(String.format(Locale.US, "Time: %d:%02d:%02d%n", s / 3600, (s % 3600) / 60, s % 60));
        sb.append("Top speed: ").append(u.format(t.maxMs)).append(' ').append(u.label).append('\n');
        sb.append("Average speed: ").append(u.format(t.avgMs)).append(' ').append(u.label).append('\n');
        if (t.eco >= 0) sb.append("Smooth-driving score: ").append(t.eco).append("/100\n");
        return sb.toString();
    }
}
