package com.veus.speedpro;

import java.util.Locale;

/** Speed units. Internal speed is ALWAYS stored in m/s. */
public enum Units {
    MS("m/s", 1.0, 70, 10, 1),
    KMH("km/h", 3.6, 240, 20, 0),
    MPH("mph", 2.2369362921, 160, 20, 0),
    KNOTS("kn", 1.9438444924, 130, 10, 0),
    MI_S("mi/s", 1.0 / 1609.344, 0.10, 0.02, 3);

    public final String label;
    public final double factor;
    public final double gaugeMax;
    public final double majorStep;
    public final int decimals;

    Units(String label, double factor, double gaugeMax, double majorStep, int decimals) {
        this.label = label;
        this.factor = factor;
        this.gaugeMax = gaugeMax;
        this.majorStep = majorStep;
        this.decimals = decimals;
    }

    public double fromMs(double ms) {
        return ms * factor;
    }

    public String format(double ms) {
        return String.format(Locale.US, "%." + decimals + "f", fromMs(ms));
    }

    public boolean imperial() {
        return this == MPH || this == MI_S;
    }

    public String formatDistance(double meters) {
        switch (this) {
            case MS:
                if (meters < 1000) return String.format(Locale.US, "%.0f m", meters);
                return String.format(Locale.US, "%.2f km", meters / 1000.0);
            case KMH:
                return String.format(Locale.US, "%.2f km", meters / 1000.0);
            case KNOTS:
                return String.format(Locale.US, "%.2f nmi", meters / 1852.0);
            case MPH:
            case MI_S:
            default:
                return String.format(Locale.US, "%.2f mi", meters / 1609.344);
        }
    }

    /** Short-range distance (waypoints, hazards): m/km or ft/mi. */
    public String formatNear(double meters) {
        if (imperial()) {
            if (meters < 300) return String.format(Locale.US, "%.0f ft", meters * 3.28084);
            return String.format(Locale.US, "%.2f mi", meters / 1609.344);
        }
        if (meters < 1000) return String.format(Locale.US, "%.0f m", meters);
        return String.format(Locale.US, "%.2f km", meters / 1000.0);
    }

    public String formatAlt(double meters) {
        if (imperial()) return String.format(Locale.US, "%.0f ft", meters * 3.28084);
        return String.format(Locale.US, "%.0f m", meters);
    }

    public static Units fromName(String name, Units fallback) {
        try {
            return Units.valueOf(name);
        } catch (Exception e) {
            return fallback;
        }
    }
}
