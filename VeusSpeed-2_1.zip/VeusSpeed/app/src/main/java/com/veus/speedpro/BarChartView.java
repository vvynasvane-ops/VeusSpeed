package com.veus.speedpro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;

import java.util.Locale;

/** Seven-day distance bar chart. */
public class BarChartView extends NeonView {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private double[] values = new double[0];
    private String[] labels = new String[0];
    private String unitLabel = "km";

    public BarChartView(Context c) { super(c); init(); }
    public BarChartView(Context c, AttributeSet a) { super(c, a); init(); }
    public BarChartView(Context c, AttributeSet a, int s) { super(c, a, s); init(); }

    private void init() {
        p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        p.setTextAlign(Paint.Align.CENTER);
    }

    public void setData(double[] values, String[] labels, String unitLabel) {
        this.values = values;
        this.labels = labels;
        this.unitLabel = unitLabel;
        invalidate();
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), Math.round(dp(140)));
    }

    @Override
    protected void onDraw(Canvas c) {
        int n = values.length;
        if (n == 0) return;
        float w = getWidth(), h = getHeight();
        float top = dp(18), bottom = dp(20);
        double max = 0.1;
        for (double v : values) max = Math.max(max, v);
        float slot = w / n;
        float bw = slot * 0.52f;
        for (int i = 0; i < n; i++) {
            float cx = slot * (i + 0.5f);
            float bh = (float) ((h - top - bottom) * (values[i] / max));
            r.set(cx - bw / 2f, h - bottom - Math.max(bh, dp(3)), cx + bw / 2f, h - bottom);
            p.setStyle(Paint.Style.FILL);
            p.setColor(alpha(track, 255));
            RectF back = new RectF(cx - bw / 2f, top, cx + bw / 2f, h - bottom);
            c.drawRoundRect(back, dp(5), dp(5), p);
            boolean today = i == n - 1;
            p.setColor(today ? accent : alpha(accent, 140));
            c.drawRoundRect(r, dp(5), dp(5), p);
            p.setTextSize(dp(10));
            p.setColor(sub);
            c.drawText(labels[i], cx, h - dp(5), p);
            if (values[i] > 0) {
                p.setColor(today ? text : sub);
                p.setTextSize(dp(9));
                c.drawText(String.format(Locale.US, values[i] >= 100 ? "%.0f" : "%.1f", values[i]), cx,
                        r.top - dp(3), p);
            }
        }
        p.setTextAlign(Paint.Align.LEFT);
        p.setColor(sub);
        p.setTextSize(dp(10));
        c.drawText(unitLabel, 0, dp(10), p);
        p.setTextAlign(Paint.Align.CENTER);
    }
}
