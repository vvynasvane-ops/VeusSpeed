package com.veus.speedpro;

import java.util.Calendar;
import java.util.TimeZone;

/** Offline sunrise / sunset (NOAA "Almanac for Computers" algorithm, official zenith 90.833 deg). */
public final class SunCalc {
    private SunCalc() {}

    /** Returns {sunriseMs, sunsetMs} for the local calendar day of nowMs, or null in polar day/night. */
    public static long[] sunTimes(double lat, double lon, long nowMs) {
        Calendar local = Calendar.getInstance();
        local.setTimeInMillis(nowMs);
        int y = local.get(Calendar.YEAR), m = local.get(Calendar.MONTH), d = local.get(Calendar.DAY_OF_MONTH);
        int dayOfYear = local.get(Calendar.DAY_OF_YEAR);
        Calendar utc = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        utc.clear();
        utc.set(y, m, d, 0, 0, 0);
        long utcMidnight = utc.getTimeInMillis();
        Calendar noon = (Calendar) local.clone();
        noon.set(Calendar.HOUR_OF_DAY, 12);
        noon.set(Calendar.MINUTE, 0);
        noon.set(Calendar.SECOND, 0);
        noon.set(Calendar.MILLISECOND, 0);
        long localNoon = noon.getTimeInMillis();

        double rise = event(lat, lon, dayOfYear, true);
        double set = event(lat, lon, dayOfYear, false);
        if (Double.isNaN(rise) || Double.isNaN(set)) return null;
        return new long[]{place(utcMidnight, rise, localNoon), place(utcMidnight, set, localNoon)};
    }

    private static long place(long utcMidnight, double utHours, long localNoon) {
        long base = utcMidnight + (long) (utHours * 3600000.0);
        long best = base;
        long bestDiff = Math.abs(base - localNoon);
        for (int k = -1; k <= 1; k += 2) {
            long cand = base + k * 86400000L;
            long diff = Math.abs(cand - localNoon);
            if (diff < bestDiff) { best = cand; bestDiff = diff; }
        }
        return best;
    }

    private static double event(double lat, double lon, int n, boolean rising) {
        double lngHour = lon / 15.0;
        double t = n + ((rising ? 6.0 : 18.0) - lngHour) / 24.0;
        double mean = 0.9856 * t - 3.289;
        double trueLon = mean + 1.916 * Math.sin(Math.toRadians(mean)) + 0.020 * Math.sin(Math.toRadians(2 * mean)) + 282.634;
        trueLon = norm360(trueLon);
        double ra = Math.toDegrees(Math.atan(0.91764 * Math.tan(Math.toRadians(trueLon))));
        ra = norm360(ra);
        ra += (Math.floor(trueLon / 90.0) * 90.0) - (Math.floor(ra / 90.0) * 90.0);
        ra /= 15.0;
        double sinDec = 0.39782 * Math.sin(Math.toRadians(trueLon));
        double cosDec = Math.cos(Math.asin(sinDec));
        double cosH = (Math.cos(Math.toRadians(90.833)) - sinDec * Math.sin(Math.toRadians(lat)))
                / (cosDec * Math.cos(Math.toRadians(lat)));
        if (cosH > 1 || cosH < -1) return Double.NaN;
        double h = rising ? 360.0 - Math.toDegrees(Math.acos(cosH)) : Math.toDegrees(Math.acos(cosH));
        h /= 15.0;
        double localT = h + ra - 0.06571 * t - 6.622;
        double ut = localT - lngHour;
        ut %= 24.0;
        if (ut < 0) ut += 24.0;
        return ut;
    }

    private static double norm360(double v) {
        v %= 360.0;
        return v < 0 ? v + 360.0 : v;
    }
}
