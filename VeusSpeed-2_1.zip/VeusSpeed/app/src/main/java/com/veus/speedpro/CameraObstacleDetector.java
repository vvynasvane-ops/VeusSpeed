package com.veus.speedpro;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import androidx.annotation.NonNull;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.LifecycleOwner;

import com.google.common.util.concurrent.ListenableFuture;

import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Level 2 obstacle sensing: fully offline, model-free "looming" heuristic.
 * It measures edge density in the centre of the frame; a sudden, sustained jump versus a slow
 * baseline means something large is rapidly filling the view. It is a warning aid only -
 * it does not classify objects or measure real distance.
 */
public class CameraObstacleDetector {

    public interface Listener {
        /** density 0..1 of the central region; warning=true when looming is detected. */
        void onCameraFrame(float density, boolean warning);
        void onCameraError(String message);
    }

    private static final int STEP = 4;
    private static final int EDGE_THRESHOLD = 18;
    private static final long MIN_FRAME_GAP_MS = 200;
    private static final long WARN_COOLDOWN_MS = 3000;

    private final Context ctx;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private Listener listener;
    private ProcessCameraProvider provider;
    private volatile boolean running;
    private boolean stopRequested;

    private long lastFrame;
    private long lastWarn;
    private float baseline = -1f;
    private int strikes;

    public CameraObstacleDetector(Context ctx) {
        this.ctx = ctx.getApplicationContext();
    }

    public void setListener(Listener l) { listener = l; }

    public void start(final LifecycleOwner owner, final PreviewView previewView) {
        if (running) return;
        stopRequested = false;
        baseline = -1f;
        strikes = 0;
        final ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(ctx);
        future.addListener(() -> {
            if (stopRequested) return;
            try {
                provider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                ImageAnalysis analysis = new ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build();
                analysis.setAnalyzer(executor, this::analyze);
                provider.unbindAll();
                provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis);
                running = true;
            } catch (Exception e) {
                running = false;
                if (listener != null) listener.onCameraError("Camera unavailable: " + e.getMessage());
            }
        }, ContextCompat.getMainExecutor(ctx));
    }

    public void stop() {
        stopRequested = true;
        running = false;
        try {
            if (provider != null) provider.unbindAll();
        } catch (Exception ignored) { }
    }

    public void release() {
        stop();
        executor.shutdown();
    }

    private void analyze(@NonNull ImageProxy image) {
        try {
            long now = SystemClock.elapsedRealtime();
            if (now - lastFrame < MIN_FRAME_GAP_MS) return;
            lastFrame = now;

            ImageProxy.PlaneProxy plane = image.getPlanes()[0];
            ByteBuffer buf = plane.getBuffer();
            int rowStride = plane.getRowStride();
            int w = image.getWidth(), h = image.getHeight();
            int limit = buf.limit();

            int x0 = w * 30 / 100, x1 = w * 70 / 100 - STEP;
            int y0 = h * 30 / 100, y1 = h * 70 / 100 - STEP;
            int edges = 0, total = 0;
            for (int y = y0; y < y1; y += STEP) {
                int row = y * rowStride;
                int rowBelow = (y + STEP) * rowStride;
                for (int x = x0; x < x1; x += STEP) {
                    int iA = row + x, iB = row + x + STEP, iC = rowBelow + x;
                    if (iC >= limit || iB >= limit) continue;
                    int a = buf.get(iA) & 0xFF;
                    int d = Math.abs(a - (buf.get(iB) & 0xFF)) + Math.abs(a - (buf.get(iC) & 0xFF));
                    if (d > EDGE_THRESHOLD) edges++;
                    total++;
                }
            }
            if (total == 0) return;
            final float density = edges / (float) total;

            boolean warn = false;
            if (baseline < 0) {
                baseline = density;
            } else {
                float ratio = density / Math.max(baseline, 0.03f);
                if (density > 0.22f && ratio > 1.9f) {
                    strikes++;
                } else {
                    strikes = Math.max(0, strikes - 1);
                    baseline += (density - baseline) * 0.04f;
                }
                if (strikes >= 3 && now - lastWarn > WARN_COOLDOWN_MS) {
                    warn = true;
                    lastWarn = now;
                    strikes = 0;
                }
            }
            final boolean fWarn = warn;
            main.post(() -> {
                if (listener != null && running) listener.onCameraFrame(density, fWarn);
            });
        } finally {
            image.close();
        }
    }
}
