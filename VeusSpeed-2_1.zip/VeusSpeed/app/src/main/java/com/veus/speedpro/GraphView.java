package com.veus.speedpro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.util.AttributeSet;

/** Compact filled line graph (live speed history, trip speed and elevation profiles). */
public class GraphView extends NeonView {
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private float[] data = new float[0];
    private float minHint = 0f, maxHint = 0f;
    private String caption = "";
    private int lineColor = 0;
    private int heightDp = 110;

    public GraphView(Context c) { super(c); init(); }
    public GraphView(Context c, AttributeSet a) { super(c, a); init(); }
    public GraphView(Context c, AttributeSet a, int s) { super(c, a, s); init(); }

    private void init() {
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeJoin(Paint.Join.ROUND);
        line.setStrokeCap(Paint.Cap.ROUND);
        grid.setStyle(Paint.Style.STROKE);
        txt.setTypeface(Typeface.create("sans-serif-condensed", Typeface.NORMAL));
    }

    /** values are in display units. minHint/maxHint set the minimum visible range (use 0,0 for auto). */
    public void setData(float[] values, float minHint, float maxHint, String caption) {
        this.data = values == null ? new float[0] : values;
        this.minHint = minHint;
        this.maxHint = maxHint;
        this.caption = caption == null ? "" : caption;
        invalidate();
    }

    /** Overrides the palette accent for this graph only (0 = use the theme accent). */
    public void setLineColor(int color) { lineColor = color; invalidate(); }

    public void setHeightDp(int dp) { heightDp = dp; requestLayout(); }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), Math.round(dp(heightDp)));
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float padT = dp(16), padB = dp(4);
        int col = lineColor != 0 ? lineColor : accent;

        grid.setColor(alpha(sub, 60));
        grid.setStrokeWidth(dp(1));
        for (int i = 0; i < 3; i++) {
            float y = padT + (h - padT - padB) * i / 2f;
            c.drawLine(0, y, w, y, grid);
        }
        txt.setColor(sub);
        txt.setTextSize(dp(10));
        txt.setTextAlign(Paint.Align.LEFT);
        c.drawText(caption, 0, dp(10), txt);

        int n = data.length;
        if (n < 2) {
            txt.setTextAlign(Paint.Align.CENTER);
            c.drawText("collecting data...", w / 2f, h / 2f + dp(8), txt);
            return;
        }
        int stride = Math.max(1, n / 400);
        float lo = Float.MAX_VALUE, hi = -Float.MAX_VALUE;
        for (int i = 0; i < n; i++) { lo = Math.min(lo, data[i]); hi = Math.max(hi, data[i]); }
        if (minHint != maxHint) { lo = Math.min(lo, minHint); hi = Math.max(hi, maxHint); }
        if (hi - lo < 1e-3f) hi = lo + 1f;

        path.reset();
        float lastX = 0, lastY = 0;
        boolean first = true;
        for (int i = 0; i < n; i += stride) {
            float x = w * i / (float) (n - 1);
            float y = padT + (h - padT - padB) * (1f - (data[i] - lo) / (hi - lo));
            if (first) { path.moveTo(x, y); first = false; } else path.lineTo(x, y);
            lastX = x;
            lastY = y;
        }
        // filled area
        Path area = new Path(path);
        area.lineTo(lastX, h);
        area.lineTo(0, h);
        area.close();
        fill.setStyle(Paint.Style.FILL);
        fill.setShader(new LinearGradient(0, padT, 0, h, alpha(col, 110), alpha(col, 0), Shader.TileMode.CLAMP));
        c.drawPath(area, fill);
        line.setColor(alpha(col, 60));
        line.setStrokeWidth(dp(5));
        c.drawPath(path, line);
        line.setColor(col);
        line.setStrokeWidth(dp(2));
        c.drawPath(path, line);
        fill.setColor(col);
        fill.setShader(null);
        c.drawCircle(lastX, lastY, dp(3.5f), fill);

        txt.setTextAlign(Paint.Align.RIGHT);
        c.drawText(String.format(java.util.Locale.US, "%.0f", hi), w, dp(10), txt);
    }
}
