package com.veus.speedpro;

import java.util.Arrays;
import java.util.Locale;

/**
 * GPS performance lab: standing-start timers (0-60 km/h, 0-100 km/h, 0-60 mph),
 * sprint timers (100 m, 1/4 mile) and a 100-0 km/h braking test. Personal bests persist.
 * Times are linearly interpolated between GPS fixes; expect roughly +/-0.1-0.2 s accuracy.
 */
public class PerfLab {
    public static final String[] NAMES = {"0-60 km/h", "0-100 km/h", "0-60 mph", "100 m", "1/4 mile", "100-0 km/h"};
    private static final double[] SPEED_T = {60 / 3.6, 100 / 3.6, 26.8224};
    private static final double[] DIST_T = {100.0, 402.336};
    private static final double BRAKE_T = 100 / 3.6;

    private final Prefs prefs;
    private final float[] last = new float[6];
    private float lastBrakeDist = -1;
    private String event;

    // launch state
    private boolean ready, running;
    private long stillSince = -1, t0, prevT = -1, liveT;
    private double prevV, dist, prevDist, vMaxRun;
    private final boolean[] done = new boolean[5];

    // braking state
    private boolean brakeSeen, braking;
    private long bt0;
    private double bdist;

    public PerfLab(Prefs p) {
        prefs = p;
        Arrays.fill(last, -1f);
    }

    public void reset() {
        Arrays.fill(last, -1f);
        lastBrakeDist = -1;
        ready = running = brakeSeen = braking = false;
        stillSince = prevT = -1;
        event = null;
    }

    public boolean isReady() { return ready; }
    public boolean isRunning() { return running; }
    public boolean isBraking() { return braking; }
    public float last(int i) { return last[i]; }
    public float best(int i) { return prefs.flt("best_" + i, 0f); }
    public float lastBrakeDist() { return lastBrakeDist; }
    public float bestBrakeDist() { return prefs.flt("best_5d", 0f); }
    public float liveSeconds() { return running ? (liveT - t0) / 1000f : (braking ? (liveT - bt0) / 1000f : 0f); }

    public String consumeEvent() {
        String e = event;
        event = null;
        return e;
    }

    public void clearBests() {
        for (int i = 0; i < 6; i++) prefs.remove("best_" + i);
        prefs.remove("best_5d");
    }

    /** v in m/s (unsmoothed), t = fix time in ms (elapsed realtime), dDist = metres since the previous fix. */
    public void onSample(double v, long t, double dDist) {
        liveT = t;
        if (prevT >= 0 && t > prevT) {
            launch(v, t, dDist);
            brake(v, t, dDist);
        } else if (v < 0.4 && stillSince < 0) {
            stillSince = t;
        }
        prevT = t;
        prevV = v;
    }

    private void launch(double v, long t, double dDist) {
        if (!running) {
            if (v < 0.4) {
                if (stillSince < 0) stillSince = t;
                if (!ready && t - stillSince >= 1500) ready = true;
            } else {
                stillSince = -1;
                if (ready && v >= 0.8) {
                    running = true;
                    ready = false;
                    t0 = prevT + (t - prevT) / 2;
                    dist = dDist * 0.5;
                    prevDist = 0;
                    vMaxRun = v;
                    Arrays.fill(done, false);
                    for (int i = 0; i < 5; i++) last[i] = -1f;
                }
            }
            return;
        }
        prevDist = dist;
        dist += dDist;
        vMaxRun = Math.max(vMaxRun, v);
        for (int i = 0; i < 3; i++) {
            if (!done[i] && v >= SPEED_T[i] && prevV < SPEED_T[i]) {
                double f = (SPEED_T[i] - prevV) / (v - prevV);
                long tc = prevT + (long) (f * (t - prevT));
                finish(i, (tc - t0) / 1000f);
            }
        }
        for (int j = 0; j < 2; j++) {
            int idx = 3 + j;
            if (!done[idx] && dist >= DIST_T[j] && dist > prevDist) {
                double f = (DIST_T[j] - prevDist) / (dist - prevDist);
                long tc = prevT + (long) (f * (t - prevT));
                finish(idx, (tc - t0) / 1000f);
            }
        }
        boolean all = true;
        for (boolean d : done) all &= d;
        if (all || (v < 0.5 && vMaxRun > 3) || t - t0 > 90000) running = false;
    }

    private void brake(double v, long t, double dDist) {
        if (!braking) {
            if (v >= BRAKE_T) {
                brakeSeen = true;
            } else if (brakeSeen && prevV >= BRAKE_T && v < prevV) {
                double f = (prevV - BRAKE_T) / (prevV - v);
                bt0 = prevT + (long) (f * (t - prevT));
                bdist = dDist * (1 - f);
                braking = true;
                brakeSeen = false;
            }
            if (v < 20 / 3.6) brakeSeen = false;
            return;
        }
        bdist += dDist;
        if (v > BRAKE_T) {
            braking = false;
        } else if (v < 0.5) {
            braking = false;
            float secs = (t - bt0) / 1000f;
            if (secs >= 1.5f && secs <= 25f) {
                last[5] = secs;
                lastBrakeDist = (float) bdist;
                float b = best(5);
                boolean pb = b <= 0 || secs < b;
                if (pb) {
                    prefs.setFlt("best_5", secs);
                    prefs.setFlt("best_5d", lastBrakeDist);
                }
                event = String.format(Locale.US, "%s %.2f s / %.0f m%s", NAMES[5], secs, bdist, pb ? "  NEW BEST" : "");
            }
        } else if (t - bt0 > 30000) {
            braking = false;
        }
    }

    private void finish(int i, float secs) {
        if (secs <= 0.05f) return;
        last[i] = secs;
        done[i] = true;
        float b = best(i);
        boolean pb = b <= 0 || secs < b;
        if (pb) prefs.setFlt("best_" + i, secs);
        event = String.format(Locale.US, "%s %.2f s%s", NAMES[i], secs, pb ? "  NEW BEST" : "");
    }
}
