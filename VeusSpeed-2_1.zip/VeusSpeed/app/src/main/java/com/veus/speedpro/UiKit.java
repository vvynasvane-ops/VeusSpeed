package com.veus.speedpro;

import android.content.Context;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.widget.SwitchCompat;

import java.util.Locale;

/** Small helpers that build themed (tag-driven) views in code, so screens stay compact. */
public final class UiKit {
    private UiKit() {}

    public interface BoolSetter { void set(boolean v); }
    public interface IntSetter { void set(int v); }
    public interface TextSetter { void set(String s); }

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    private static LinearLayout.LayoutParams lp(Context c, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(c, topDp);
        return p;
    }

    public static LinearLayout card(Context c, LinearLayout parent, String title) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setTag("card");
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        parent.addView(l, lp(c, 12));
        if (title != null) {
            TextView t = label(c, l, title.toUpperCase(Locale.US), "accent", 13);
            t.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            t.setLetterSpacing(0.15f);
            ((LinearLayout.LayoutParams) t.getLayoutParams()).topMargin = 0;
        }
        return l;
    }

    public static TextView label(Context c, LinearLayout parent, String text, String tag, float sp) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTag(tag);
        t.setTextSize(sp);
        parent.addView(t, lp(c, 6));
        return t;
    }

    /** One horizontal row of label/value columns; returns the value TextViews. */
    public static TextView[] statRow(Context c, LinearLayout parent, String... labels) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        parent.addView(row, lp(c, 12));
        TextView[] values = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            LinearLayout col = new LinearLayout(c);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER);
            row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView l = new TextView(c);
            l.setTag("sub");
            l.setTextSize(10.5f);
            l.setMaxLines(1);
            l.setText(labels[i]);
            l.setTypeface(Typeface.create("sans-serif-condensed", Typeface.NORMAL));
            l.setLetterSpacing(0.08f);
            col.addView(l);
            TextView v = new TextView(c);
            v.setTag("title");
            v.setTextSize(16f);
            v.setMaxLines(1);
            v.setText("--");
            v.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            col.addView(v);
            values[i] = v;
        }
        return values;
    }

    public static TextView labelOf(TextView value) {
        return (TextView) ((ViewGroup) value.getParent()).getChildAt(0);
    }

    public static SwitchCompat toggle(Context c, LinearLayout parent, String text, boolean initial, BoolSetter setter) {
        SwitchCompat s = new SwitchCompat(c);
        s.setText(text);
        s.setTag("title");
        s.setMinHeight(dp(c, 48));
        s.setChecked(initial);
        s.setOnCheckedChangeListener((b, v) -> setter.set(v));
        parent.addView(s, lp(c, 0));
        return s;
    }

    public static RadioGroup radios(Context c, LinearLayout parent, String[] labels, int selected, IntSetter setter) {
        RadioGroup g = new RadioGroup(c);
        g.setOrientation(RadioGroup.VERTICAL);
        for (String s : labels) {
            RadioButton b = new RadioButton(c);
            b.setId(View.generateViewId());
            b.setText(s);
            b.setTag("title");
            b.setMinHeight(dp(c, 48));
            g.addView(b);
        }
        if (selected >= 0 && selected < labels.length) g.check(g.getChildAt(selected).getId());
        g.setOnCheckedChangeListener((grp, id) -> {
            int idx = grp.indexOfChild(grp.findViewById(id));
            if (idx >= 0) setter.set(idx);
        });
        parent.addView(g, lp(c, 0));
        return g;
    }

    public static EditText input(Context c, LinearLayout parent, String hint, String initial, int inputType,
                                 int maxLen, TextSetter setter) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setText(initial);
        e.setInputType(inputType);
        e.setTag("input");
        e.setMinHeight(dp(c, 48));
        int p = dp(c, 12);
        e.setPadding(p, p, p, p);
        e.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        if (maxLen > 0) e.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(maxLen)});
        e.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int d) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int d) { }
            @Override public void afterTextChanged(Editable ed) { setter.set(ed.toString().trim()); }
        });
        parent.addView(e, lp(c, 4));
        return e;
    }

    public static TextView button(Context c, LinearLayout parent, String text, String tag, Runnable action) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTag(tag);
        t.setGravity(Gravity.CENTER);
        t.setMinHeight(dp(c, 48));
        int p = dp(c, 12);
        t.setPadding(p, p, p, p);
        t.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        t.setLetterSpacing(0.1f);
        t.setClickable(true);
        t.setFocusable(true);
        t.setOnClickListener(v -> action.run());
        parent.addView(t, lp(c, 10));
        return t;
    }

    public static SeekBar seek(Context c, LinearLayout parent, int max, int progress, IntSetter setter) {
        SeekBar s = new SeekBar(c);
        s.setMax(max);
        s.setProgress(progress);
        s.setMinimumHeight(dp(c, 48));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) { if (fromUser) setter.set(p); }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { }
        });
        parent.addView(s, lp(c, 0));
        return s;
    }
}
