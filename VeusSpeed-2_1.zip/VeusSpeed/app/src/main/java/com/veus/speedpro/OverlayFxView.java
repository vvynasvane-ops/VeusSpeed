package com.veus.speedpro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.util.AttributeSet;

/** Top-most cosmetic layer: holographic scanlines and a pulsing red vignette while over the speed limit. */
public class OverlayFxView extends NeonView {
    private final Paint line = new Paint();
    private final Paint vignette = new Paint();
    private boolean scan = true, alert;
    private int alertColor = 0xFFFF1744;
    private float stepPx;

    public OverlayFxView(Context c) { super(c); init(); }
    public OverlayFxView(Context c, AttributeSet a) { super(c, a); init(); }
    public OverlayFxView(Context c, AttributeSet a, int s) { super(c, a, s); init(); }

    private void init() {
        setWillNotDraw(false);
        line.setColor(0xFFFFFFFF);
        line.setAlpha(10);
        line.setStrokeWidth(1f);
    }

    public void setScanlines(boolean on) {
        scan = on;
        invalidate();
    }

    public void setAlert(boolean on) {
        if (alert != on) {
            alert = on;
            invalidate();
        }
    }

    public void setAlertColor(int color) {
        alertColor = color;
        vignette.setShader(null);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        if (scan) {
            if (stepPx == 0) stepPx = Math.max(3f, dp(3.5f));
            line.setColor(accent);
            line.setAlpha(14);
            for (float y = 0; y < h; y += stepPx) c.drawLine(0, y, w, y, line);
        }
        if (alert) {
            if (vignette.getShader() == null) {
                int clear = alertColor & 0x00FFFFFF;
                vignette.setShader(new RadialGradient(w / 2f, h / 2f, (float) Math.hypot(w, h) / 2f,
                        new int[]{clear, clear, alertColor}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            }
            float pulse = (float) (Math.sin(System.nanoTime() / 1e9 * 6.0) + 1.0) / 2f;
            vignette.setAlpha((int) (70 + pulse * 150));
            c.drawRect(0, 0, w, h, vignette);
            postInvalidateOnAnimation();
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        vignette.setShader(null);
    }
}
