package com.veus.speedpro;

import android.content.Context;
import android.speech.tts.TextToSpeech;

import java.util.HashMap;
import java.util.Locale;

/** Offline voice announcements through the system text-to-speech engine. Failure-safe. */
public final class Voice {
    private TextToSpeech tts;
    private volatile boolean ready;
    private String pending;
    private final HashMap<String, Long> lastSpoken = new HashMap<>();

    public Voice(Context ctx) {
        try {
            tts = new TextToSpeech(ctx.getApplicationContext(), status -> {
                if (status != TextToSpeech.SUCCESS || tts == null) return;
                int r = tts.setLanguage(Locale.getDefault());
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.US);
                }
                ready = true;
                if (pending != null) {
                    String p = pending;
                    pending = null;
                    tts.speak(p, TextToSpeech.QUEUE_FLUSH, null, "veus");
                }
            });
        } catch (Exception e) {
            tts = null;
        }
    }

    /** Speaks text unless the same key was spoken less than gapMs ago. */
    public void speak(String key, String text, long gapMs) {
        if (tts == null) return;
        long now = System.currentTimeMillis();
        Long last = lastSpoken.get(key);
        if (last != null && now - last < gapMs) return;
        lastSpoken.put(key, now);
        if (!ready) {
            pending = text;
            return;
        }
        try {
            tts.speak(text, TextToSpeech.QUEUE_ADD, null, "veus");
        } catch (Exception ignored) { }
    }

    public void shutdown() {
        if (tts != null) {
            try {
                tts.stop();
                tts.shutdown();
            } catch (Exception ignored) { }
            tts = null;
        }
        ready = false;
    }
}
