package com.veus.speedpro;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/** Offline trip log: summary rows in SQLite, breadcrumb routes in small CSV files. */
public class TripStore extends SQLiteOpenHelper {

    public static final class Trip {
        public long id, startMs, durMs, movMs, overMs;
        public double distM, ascent, descent;
        public float maxMs, avgMs;
        public int eco = -1, hAccel, hBrake, hCorner, hour;
    }

    public static final class Aggregate {
        public int count, bestEcoLong, nightTrips;
        public double totalDist;
        public float maxSpeed;
        public final double[] week = new double[7];
        public final long[] weekDayStart = new long[7];
    }

    private final Context ctx;

    public TripStore(Context c) {
        super(c.getApplicationContext(), "veusspeed.db", null, 1);
        ctx = c.getApplicationContext();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE trips (_id INTEGER PRIMARY KEY AUTOINCREMENT, start INTEGER, dur INTEGER, mov INTEGER,"
                + " dist REAL, maxv REAL, avgv REAL, eco INTEGER, ha INTEGER, hb INTEGER, hc INTEGER, over INTEGER,"
                + " asc_m REAL, dsc_m REAL, hour INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }

    // ---- write ---------------------------------------------------------------------------------

    public long insert(Trip t, List<DriveAnalytics.Pt> route) {
        ContentValues cv = new ContentValues();
        cv.put("start", t.startMs);
        cv.put("dur", t.durMs);
        cv.put("mov", t.movMs);
        cv.put("dist", t.distM);
        cv.put("maxv", t.maxMs);
        cv.put("avgv", t.avgMs);
        cv.put("eco", t.eco);
        cv.put("ha", t.hAccel);
        cv.put("hb", t.hBrake);
        cv.put("hc", t.hCorner);
        cv.put("over", t.overMs);
        cv.put("asc_m", t.ascent);
        cv.put("dsc_m", t.descent);
        cv.put("hour", t.hour);
        long id = getWritableDatabase().insert("trips", null, cv);
        if (id > 0 && route != null && !route.isEmpty()) writeRoute(id, route);
        return id;
    }

    public void delete(long id) {
        getWritableDatabase().delete("trips", "_id=?", new String[]{String.valueOf(id)});
        //noinspection ResultOfMethodCallIgnored
        routeFile(id).delete();
    }

    public void deleteAll() {
        List<Trip> all = list(100000);
        for (Trip t : all) //noinspection ResultOfMethodCallIgnored
            routeFile(t.id).delete();
        getWritableDatabase().delete("trips", null, null);
    }

    // ---- read ----------------------------------------------------------------------------------

    public List<Trip> list(int limit) {
        ArrayList<Trip> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().query("trips", null, null, null, null, null,
                "start DESC", String.valueOf(limit))) {
            while (c.moveToNext()) out.add(fromCursor(c));
        }
        return out;
    }

    public Trip get(long id) {
        try (Cursor c = getReadableDatabase().query("trips", null, "_id=?", new String[]{String.valueOf(id)},
                null, null, null)) {
            return c.moveToFirst() ? fromCursor(c) : null;
        }
    }

    private Trip fromCursor(Cursor c) {
        Trip t = new Trip();
        t.id = c.getLong(c.getColumnIndexOrThrow("_id"));
        t.startMs = c.getLong(c.getColumnIndexOrThrow("start"));
        t.durMs = c.getLong(c.getColumnIndexOrThrow("dur"));
        t.movMs = c.getLong(c.getColumnIndexOrThrow("mov"));
        t.distM = c.getDouble(c.getColumnIndexOrThrow("dist"));
        t.maxMs = c.getFloat(c.getColumnIndexOrThrow("maxv"));
        t.avgMs = c.getFloat(c.getColumnIndexOrThrow("avgv"));
        t.eco = c.getInt(c.getColumnIndexOrThrow("eco"));
        t.hAccel = c.getInt(c.getColumnIndexOrThrow("ha"));
        t.hBrake = c.getInt(c.getColumnIndexOrThrow("hb"));
        t.hCorner = c.getInt(c.getColumnIndexOrThrow("hc"));
        t.overMs = c.getLong(c.getColumnIndexOrThrow("over"));
        t.ascent = c.getDouble(c.getColumnIndexOrThrow("asc_m"));
        t.descent = c.getDouble(c.getColumnIndexOrThrow("dsc_m"));
        t.hour = c.getInt(c.getColumnIndexOrThrow("hour"));
        return t;
    }

    public Aggregate aggregate() {
        Aggregate a = new Aggregate();
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT COUNT(*), IFNULL(SUM(dist),0), IFNULL(MAX(maxv),0) FROM trips", null)) {
            if (c.moveToFirst()) {
                a.count = c.getInt(0);
                a.totalDist = c.getDouble(1);
                a.maxSpeed = c.getFloat(2);
            }
        }
        try (Cursor c = db.rawQuery("SELECT IFNULL(MAX(eco),-1) FROM trips WHERE dist>=5000", null)) {
            if (c.moveToFirst()) a.bestEcoLong = c.getInt(0);
        }
        try (Cursor c = db.rawQuery("SELECT COUNT(*) FROM trips WHERE hour>=22 OR hour<5", null)) {
            if (c.moveToFirst()) a.nightTrips = c.getInt(0);
        }
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.add(Calendar.DAY_OF_YEAR, -6);
        for (int i = 0; i < 7; i++) {
            long ds = cal.getTimeInMillis();
            cal.add(Calendar.DAY_OF_YEAR, 1);
            long de = cal.getTimeInMillis();
            a.weekDayStart[i] = ds;
            try (Cursor c = db.rawQuery("SELECT IFNULL(SUM(dist),0) FROM trips WHERE start>=? AND start<?",
                    new String[]{String.valueOf(ds), String.valueOf(de)})) {
                if (c.moveToFirst()) a.week[i] = c.getDouble(0);
            }
        }
        return a;
    }

    public String csvAll() {
        StringBuilder sb = new StringBuilder("id,start_iso,duration_s,moving_s,distance_km,max_kmh,avg_kmh,eco,"
                + "harsh_accel,harsh_brake,harsh_corner,over_limit_s,ascent_m,descent_m\n");
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
        for (Trip t : list(100000)) {
            sb.append(String.format(Locale.US, "%d,%s,%d,%d,%.3f,%.1f,%.1f,%d,%d,%d,%d,%d,%.0f,%.0f\n",
                    t.id, f.format(new java.util.Date(t.startMs)), t.durMs / 1000, t.movMs / 1000,
                    t.distM / 1000.0, t.maxMs * 3.6, t.avgMs * 3.6, t.eco, t.hAccel, t.hBrake, t.hCorner,
                    t.overMs / 1000, t.ascent, t.descent));
        }
        return sb.toString();
    }

    // ---- routes --------------------------------------------------------------------------------

    private File routeFile(long id) {
        File d = new File(ctx.getFilesDir(), "routes");
        //noinspection ResultOfMethodCallIgnored
        d.mkdirs();
        return new File(d, "trip_" + id + ".csv");
    }

    private void writeRoute(long id, List<DriveAnalytics.Pt> r) {
        try (BufferedWriter w = new BufferedWriter(new FileWriter(routeFile(id)))) {
            long t0 = r.get(0).t;
            for (DriveAnalytics.Pt p : r) {
                w.write(String.format(Locale.US, "%d,%.6f,%.6f,%.2f,%.1f\n", p.t - t0, p.lat, p.lon, p.spd, p.alt));
            }
        } catch (IOException ignored) { }
    }

    /** Route points with t = milliseconds since the first point. */
    public List<DriveAnalytics.Pt> loadRoute(long id) {
        ArrayList<DriveAnalytics.Pt> out = new ArrayList<>();
        File f = routeFile(id);
        if (!f.exists()) return out;
        try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] s = line.split(",");
                if (s.length < 5) continue;
                try {
                    out.add(new DriveAnalytics.Pt(Double.parseDouble(s[1]), Double.parseDouble(s[2]),
                            Float.parseFloat(s[3]), Float.parseFloat(s[4]), Long.parseLong(s[0])));
                } catch (NumberFormatException ignored) { }
            }
        } catch (IOException ignored) { }
        return out;
    }
}
