@echo off
rem ---- One-time setup: wrapper jar + local.properties ----
cd /d "%~dp0"
if not exist gradle\wrapper mkdir gradle\wrapper

set NEED_JAR=1
if exist gradle\wrapper\gradle-wrapper.jar (
  for %%F in (gradle\wrapper\gradle-wrapper.jar) do if %%~zF GTR 20000 set NEED_JAR=0
)
if "%NEED_JAR%"=="1" (
  echo Downloading gradle-wrapper.jar ^(v8.10.2^)...
  curl -fL -o gradle\wrapper\gradle-wrapper.jar https://github.com/gradle/gradle/raw/v8.10.2/gradle/wrapper/gradle-wrapper.jar
  if errorlevel 1 (
    echo v8.10.2 failed, trying v8.9.0...
    curl -fL -o gradle\wrapper\gradle-wrapper.jar https://github.com/gradle/gradle/raw/v8.9.0/gradle/wrapper/gradle-wrapper.jar
  )
)

if not exist local.properties (
  echo sdk.dir=C\:\\Users\\Lenovo\\AppData\\Local\\Android\\Sdk> local.properties
  echo Created local.properties
)
exit /b 0
