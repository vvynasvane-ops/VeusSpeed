@echo off
cd /d "%~dp0"
call setup.bat
call gradlew.bat clean
if errorlevel 1 goto :fail
call gradlew.bat assembleDebug
if errorlevel 1 goto :fail
echo.
echo BUILD OK  ->  app\build\outputs\apk\debug\app-debug.apk
pause
exit /b 0
:fail
echo.
echo BUILD FAILED - see messages above.
pause
exit /b 1
