# VeusSpeed - offline GPS speedometer (Java + XML)

Package `com.veus.speedpro` - minSdk 24, targetSdk/compileSdk 34, Java 17 source level.
Gradle 8.10.2 + AGP 8.7.3 (works with JDK 17-23).

## Build on Windows (CMD)
    setup.bat            (downloads gradle-wrapper.jar if missing, writes local.properties)
    clean_build.bat      (gradlew.bat clean + assembleDebug)
or manually:
    gradlew.bat clean assembleDebug
    gradlew.bat assembleDebug

APK: app\build\outputs\apk\debug\app-debug.apk

## Features
- GPS speed via framework LocationManager (no Play Services, fully offline)
- Units: m/s, km/h, mph, knots, mi/s (internal value always m/s)
- Max / average / trip distance / time, reset button
- Display styles: digital, analog gauge, mirrored HUD
- Themes: system/light/dark, 8 accent palettes + custom hue, live preview
- Speed-limit alert (vibration + beep)
- Obstacle guard: proximity sensor, accelerometer impact detection (3 sensitivities),
  optional offline camera "looming" warning (CameraX, no ML model needed)
