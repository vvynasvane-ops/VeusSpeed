package com.veus.speedpro;

import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.SeekBar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

public class SettingsActivity extends AppCompatActivity {

    private Prefs prefs;
    private View root;
    private GaugeView preview;
    private LinearLayout swatches;
    private ThemeHelper.Colors colors;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        prefs = new Prefs(this);
        root = findViewById(R.id.root);
        preview = findViewById(R.id.previewGauge);
        swatches = findViewById(R.id.swatches);

        findViewById(R.id.btnDone).setOnClickListener(v -> finish());

        // Theme mode
        RadioGroup gTheme = findViewById(R.id.groupTheme);
        int tm = prefs.getThemeMode();
        gTheme.check(tm == 1 ? R.id.rbThemeLight : (tm == 2 ? R.id.rbThemeDark : R.id.rbThemeSystem));
        gTheme.setOnCheckedChangeListener((g, id) -> {
            int m = id == R.id.rbThemeLight ? 1 : (id == R.id.rbThemeDark ? 2 : 0);
            prefs.setThemeMode(m);
            ThemeHelper.applyNightMode(m);   // recreates the activity when the mode changes
        });

        // Gauge style
        RadioGroup gStyle = findViewById(R.id.groupStyle);
        int gs = prefs.getGaugeStyle();
        gStyle.check(gs == 0 ? R.id.rbStyleDigital : (gs == 2 ? R.id.rbStyleHud : R.id.rbStyleAnalog));
        gStyle.setOnCheckedChangeListener((g, id) ->
                prefs.setGaugeStyle(id == R.id.rbStyleDigital ? 0 : (id == R.id.rbStyleHud ? 2 : 1)));

        // Custom hue
        SeekBar hue = findViewById(R.id.seekHue);
        hue.setMax(359);
        hue.setProgress(prefs.getCustomHue());
        hue.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (!fromUser) return;
                prefs.setCustomHue(p);
                prefs.setPalette(ThemeHelper.PALETTES.length);
                applyTheme();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });

        // Default unit
        RadioGroup gUnit = findViewById(R.id.groupUnit);
        gUnit.check(unitToId(prefs.getUnit()));
        gUnit.setOnCheckedChangeListener((g, id) -> {
            Units u = idToUnit(id);
            prefs.setUnit(u);
            updatePreview();
        });

        bindSwitch(R.id.swKeepOn, prefs.getKeepScreenOn(), prefs::setKeepScreenOn);
        bindSwitch(R.id.swVibrate, prefs.getVibrate(), prefs::setVibrate);
        bindSwitch(R.id.swSound, prefs.getSound(), prefs::setSound);
        bindSwitch(R.id.swProximity, prefs.getProximity(), prefs::setProximity);
        bindSwitch(R.id.swImpact, prefs.getImpact(), prefs::setImpact);

        // Speed limit
        EditText limit = findViewById(R.id.editLimit);
        if (prefs.getSpeedLimitKmh() > 0) limit.setText(String.valueOf(prefs.getSpeedLimitKmh()));
        limit.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) {
                int v = 0;
                try { v = Integer.parseInt(e.toString().trim()); } catch (NumberFormatException ignored) { }
                prefs.setSpeedLimitKmh(Math.max(0, Math.min(400, v)));
            }
        });

        // Impact sensitivity
        RadioGroup gSens = findViewById(R.id.groupSens);
        int sens = prefs.getImpactSens();
        gSens.check(sens == 0 ? R.id.rbSensLow : (sens == 2 ? R.id.rbSensHigh : R.id.rbSensMed));
        gSens.setOnCheckedChangeListener((g, id) ->
                prefs.setImpactSens(id == R.id.rbSensLow ? 0 : (id == R.id.rbSensHigh ? 2 : 1)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        applyTheme();
    }

    private interface BoolSetter { void set(boolean v); }

    private void bindSwitch(int id, boolean initial, BoolSetter setter) {
        SwitchCompat s = findViewById(id);
        s.setChecked(initial);
        s.setOnCheckedChangeListener((b, v) -> setter.set(v));
    }

    private void applyTheme() {
        colors = ThemeHelper.resolve(this, prefs);
        ThemeHelper.apply(root, colors);
        getWindow().setStatusBarColor(colors.bg);
        getWindow().setNavigationBarColor(colors.bg);
        androidx.core.view.WindowInsetsControllerCompat wic =
                androidx.core.view.WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        wic.setAppearanceLightStatusBars(!colors.dark);
        wic.setAppearanceLightNavigationBars(!colors.dark);
        preview.setPalette(colors.accent, colors.track, colors.text, colors.sub, colors.danger);
        updatePreview();
        buildSwatches();
    }

    private void updatePreview() {
        Units u = prefs.getUnit();
        preview.setUnit(u);
        preview.setSpeed((float) u.fromMs(20.0));   // demo value: 72 km/h
    }

    private void buildSwatches() {
        swatches.removeAllViews();
        int size = ThemeHelper.dp(root, 44);
        int margin = ThemeHelper.dp(root, 6);
        int count = ThemeHelper.PALETTES.length + 1;
        for (int i = 0; i < count; i++) {
            final int index = i;
            boolean custom = i == ThemeHelper.PALETTES.length;
            int color = custom ? ThemeHelper.customColor(prefs.getCustomHue()) : ThemeHelper.PALETTES[i].color;
            GradientDrawable d = new GradientDrawable();
            d.setShape(GradientDrawable.OVAL);
            d.setColor(color);
            if (i == prefs.getPalette()) d.setStroke(ThemeHelper.dp(root, 3), colors.text);
            View dot = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
            lp.setMargins(margin, margin, margin, margin);
            dot.setLayoutParams(lp);
            dot.setBackground(d);
            dot.setContentDescription(custom ? "Custom colour" : ThemeHelper.PALETTES[i].name);
            dot.setOnClickListener(v -> {
                prefs.setPalette(index);
                applyTheme();
            });
            swatches.addView(dot);
        }
    }

    private int unitToId(Units u) {
        switch (u) {
            case MS: return R.id.rbUnitMs;
            case MPH: return R.id.rbUnitMph;
            case KNOTS: return R.id.rbUnitKn;
            case MI_S: return R.id.rbUnitMis;
            case KMH:
            default: return R.id.rbUnitKmh;
        }
    }

    private Units idToUnit(int id) {
        if (id == R.id.rbUnitMs) return Units.MS;
        if (id == R.id.rbUnitMph) return Units.MPH;
        if (id == R.id.rbUnitKn) return Units.KNOTS;
        if (id == R.id.rbUnitMis) return Units.MI_S;
        return Units.KMH;
    }
}
