package com.veus.speedpro;

import android.app.Application;

/** Holds the trip tracker so trip stats survive activity recreation (rotation, theme change). */
public class SpeedApp extends Application {
    private SpeedTracker tracker;

    @Override
    public void onCreate() {
        super.onCreate();
        ThemeHelper.applyNightMode(new Prefs(this).getThemeMode());
        tracker = new SpeedTracker(this);
    }

    public SpeedTracker getTracker() {
        return tracker;
    }
}
