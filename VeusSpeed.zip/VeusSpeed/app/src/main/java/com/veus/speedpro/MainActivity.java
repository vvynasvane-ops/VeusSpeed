package com.veus.speedpro;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import java.util.Locale;

public class MainActivity extends AppCompatActivity implements SpeedTracker.Listener {

    private Prefs prefs;
    private SpeedTracker tracker;
    private ObstacleSensors sensors;
    private CameraObstacleDetector camera;
    private Haptics haptics;
    private ThemeHelper.Colors colors;
    private Units unit = Units.KMH;

    private View root, digitalBlock;
    private GaugeView gauge;
    private TextView speedText, unitText, gpsStatus, limitBanner, obstacleBanner;
    private TextView statMax, statAvg, statTrip, statTime, lblMax, lblAvg, sensorStatus;
    private SwitchCompat switchCamera;
    private PreviewView previewView;
    private TextView[] chips;
    private final Units[] chipUnits = {Units.MS, Units.KMH, Units.MPH, Units.KNOTS, Units.MI_S};

    private final Handler ui = new Handler(Looper.getMainLooper());
    private boolean askedLocation, suppressCameraSwitch, proxNear;
    private long lastLimitAlert, lastObstacleAlert;
    private float camDensity = -1f;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            tracker.tick();
            updateStats();
            ui.postDelayed(this, 1000);
        }
    };
    private final Runnable hideBanner = () -> obstacleBanner.setVisibility(View.GONE);

    private final ActivityResultLauncher<String[]> locationLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                if (hasLocationPermission()) {
                    tracker.start();
                } else {
                    gpsStatus.setText("No location permission");
                }
            });

    private final ActivityResultLauncher<String> cameraLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) {
                    startCamera();
                } else {
                    prefs.setCameraMode(false);
                    setCameraSwitch(false);
                    Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = new Prefs(this);
        tracker = ((SpeedApp) getApplication()).getTracker();
        sensors = new ObstacleSensors(this);
        camera = new CameraObstacleDetector(this);
        haptics = new Haptics(this);

        root = findViewById(R.id.root);
        gauge = findViewById(R.id.gauge);
        digitalBlock = findViewById(R.id.digitalBlock);
        speedText = findViewById(R.id.speedText);
        unitText = findViewById(R.id.unitText);
        gpsStatus = findViewById(R.id.gpsStatus);
        limitBanner = findViewById(R.id.limitBanner);
        obstacleBanner = findViewById(R.id.obstacleBanner);
        statMax = findViewById(R.id.statMax);
        statAvg = findViewById(R.id.statAvg);
        statTrip = findViewById(R.id.statTrip);
        statTime = findViewById(R.id.statTime);
        lblMax = findViewById(R.id.lblMax);
        lblAvg = findViewById(R.id.lblAvg);
        sensorStatus = findViewById(R.id.sensorStatus);
        switchCamera = findViewById(R.id.switchCamera);
        previewView = findViewById(R.id.previewView);

        chips = new TextView[]{
                findViewById(R.id.chipMs), findViewById(R.id.chipKmh), findViewById(R.id.chipMph),
                findViewById(R.id.chipKn), findViewById(R.id.chipMis)};
        for (int i = 0; i < chips.length; i++) {
            final Units u = chipUnits[i];
            chips[i].setOnClickListener(v -> {
                prefs.setUnit(u);
                unit = u;
                gauge.setUnit(u);
                styleChips();
                renderSpeed();
                updateStats();
            });
        }

        findViewById(R.id.btnSettings).setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));
        findViewById(R.id.btnReset).setOnClickListener(v -> {
            tracker.reset();
            updateStats();
        });
        gpsStatus.setOnClickListener(v -> {
            if (hasLocationPermission() && !tracker.isGpsEnabled()) {
                try {
                    startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                } catch (Exception ignored) { }
            } else if (!hasLocationPermission()) {
                locationLauncher.launch(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION});
            }
        });

        switchCamera.setChecked(prefs.getCameraMode());
        switchCamera.setOnCheckedChangeListener((b, checked) -> {
            if (suppressCameraSwitch) return;
            prefs.setCameraMode(checked);
            if (checked) ensureCamera(); else stopCamera();
            updateSensorStatus();
        });

        sensors.setListener(new ObstacleSensors.Listener() {
            @Override public void onProximity(boolean near) {
                proxNear = near;
                updateSensorStatus();
                if (near) showObstacle("Object very close to the phone", false);
            }

            @Override public void onImpact(float g) {
                showObstacle(String.format(Locale.US, "Impact / hard jolt detected (%.1f g)", g), true);
            }
        });

        camera.setListener(new CameraObstacleDetector.Listener() {
            @Override public void onCameraFrame(float density, boolean warning) {
                camDensity = density;
                updateSensorStatus();
                if (warning && tracker.getSpeedMs() >= 2.0) {
                    showObstacle("Obstacle ahead - slow down (camera)", true);
                }
            }

            @Override public void onCameraError(String message) {
                prefs.setCameraMode(false);
                setCameraSwitch(false);
                previewView.setVisibility(View.GONE);
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        unit = prefs.getUnit();
        applyTheme();
        applyGaugeStyle();

        tracker.setListener(this);
        if (hasLocationPermission()) {
            tracker.start();
        } else if (!askedLocation) {
            askedLocation = true;
            locationLauncher.launch(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION});
        }

        sensors.start(prefs.getProximity(), prefs.getImpact(), prefs.getImpactSens());
        setCameraSwitch(prefs.getCameraMode());
        if (prefs.getCameraMode()) ensureCamera(); else previewView.setVisibility(View.GONE);

        renderSpeed();
        onGpsState(tracker);
        updateStats();
        updateSensorStatus();
        ui.removeCallbacks(ticker);
        ui.postDelayed(ticker, 1000);
    }

    @Override
    protected void onPause() {
        ui.removeCallbacks(ticker);
        ui.removeCallbacks(hideBanner);
        tracker.setListener(null);
        tracker.stop();          // save battery: GPS only runs while the screen is visible
        sensors.stop();
        stopCamera();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        camera.release();
        haptics.release();
        super.onDestroy();
    }

    // ---- permissions / camera -------------------------------------------------------------

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasCameraPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void ensureCamera() {
        if (hasCameraPermission()) startCamera(); else cameraLauncher.launch(Manifest.permission.CAMERA);
    }

    private void startCamera() {
        previewView.setVisibility(View.VISIBLE);
        camera.start(this, previewView);
    }

    private void stopCamera() {
        camera.stop();
        camDensity = -1f;
        previewView.setVisibility(View.GONE);
    }

    private void setCameraSwitch(boolean on) {
        suppressCameraSwitch = true;
        switchCamera.setChecked(on);
        suppressCameraSwitch = false;
    }

    // ---- SpeedTracker.Listener ------------------------------------------------------------

    @Override public void onSpeedUpdate(SpeedTracker t) {
        renderSpeed();
        updateStats();
    }

    @Override public void onGpsState(SpeedTracker t) {
        String s;
        if (!hasLocationPermission()) s = "Tap to allow location";
        else if (!t.isGpsEnabled()) s = "GPS off - tap to enable";
        else if (!t.hasFix()) s = "Searching GPS...";
        else if (t.getAccuracy() >= 0) s = String.format(Locale.US, "GPS locked \u00B1%.0f m", t.getAccuracy());
        else s = "GPS locked";
        gpsStatus.setText(s);
    }

    // ---- rendering ------------------------------------------------------------------------

    private void renderSpeed() {
        double ms = tracker.getSpeedMs();
        gauge.setSpeed((float) unit.fromMs(ms));
        speedText.setText(unit.format(ms));
        unitText.setText(unit.label);

        int limit = prefs.getSpeedLimitKmh();
        boolean over = limit > 0 && ms * 3.6 > limit;
        speedText.setTextColor(over ? colors.danger : colors.accentText);
        gauge.setOver(over);
        if (over) {
            limitBanner.setText(String.format(Locale.US, "Over the speed limit (%d km/h)", limit));
            limitBanner.setVisibility(View.VISIBLE);
            long now = SystemClock.elapsedRealtime();
            if (now - lastLimitAlert > 2500) {
                lastLimitAlert = now;
                haptics.alert(prefs.getVibrate(), prefs.getSound(), false);
            }
        } else {
            limitBanner.setVisibility(View.GONE);
        }
    }

    private void updateStats() {
        lblMax.setText("MAX \u00B7 " + unit.label);
        lblAvg.setText("AVG \u00B7 " + unit.label);
        statMax.setText(unit.format(tracker.getMaxMs()));
        statAvg.setText(unit.format(tracker.getAvgMs()));
        statTrip.setText(unit.formatDistance(tracker.getDistanceM()));
        long s = tracker.getTotalMs() / 1000;
        statTime.setText(String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60));
    }

    private void updateSensorStatus() {
        StringBuilder sb = new StringBuilder();
        if (!prefs.getProximity()) sb.append("Proximity: off");
        else if (!sensors.hasProximity()) sb.append("Proximity: not available");
        else sb.append("Proximity: ").append(proxNear ? "NEAR" : "clear");
        sb.append("  \u2022  Impact: ");
        if (!prefs.getImpact()) sb.append("off");
        else if (!sensors.hasAccelerometer()) sb.append("not available");
        else sb.append(new String[]{"low", "medium", "high"}[prefs.getImpactSens()]);
        sb.append("\nCamera: ");
        if (!prefs.getCameraMode()) sb.append("off");
        else if (camDensity < 0) sb.append("starting...");
        else sb.append(String.format(Locale.US, "scene activity %.0f%%", camDensity * 100f));
        sensorStatus.setText(sb.toString());
    }

    private void showObstacle(String msg, boolean strong) {
        obstacleBanner.setText(msg);
        obstacleBanner.setVisibility(View.VISIBLE);
        ui.removeCallbacks(hideBanner);
        ui.postDelayed(hideBanner, 5000);
        long now = SystemClock.elapsedRealtime();
        if (strong && now - lastObstacleAlert > 2000) {
            lastObstacleAlert = now;
            haptics.alert(prefs.getVibrate(), prefs.getSound(), true);
        }
    }

    // ---- theme ----------------------------------------------------------------------------

    private void applyGaugeStyle() {
        int style = prefs.getGaugeStyle();
        gauge.setVisibility(style == 1 ? View.VISIBLE : View.GONE);
        digitalBlock.setVisibility(style == 1 ? View.GONE : View.VISIBLE);
        digitalBlock.setScaleX(style == 2 ? -1f : 1f);   // HUD: mirrored for windshield reflection
    }

    private void applyTheme() {
        colors = ThemeHelper.resolve(this, prefs);
        ThemeHelper.apply(root, colors);
        gauge.setPalette(colors.accent, colors.track, colors.text, colors.sub, colors.danger);
        gauge.setUnit(unit);

        float r = ThemeHelper.dp(root, 12);
        limitBanner.setBackground(ThemeHelper.rounded(colors.danger, r));
        limitBanner.setTextColor(0xFFFFFFFF);
        obstacleBanner.setBackground(ThemeHelper.rounded(colors.danger, r));
        obstacleBanner.setTextColor(0xFFFFFFFF);
        styleChips();

        getWindow().setStatusBarColor(colors.bg);
        getWindow().setNavigationBarColor(colors.bg);
        WindowInsetsControllerCompat wic =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        wic.setAppearanceLightStatusBars(!colors.dark);
        wic.setAppearanceLightNavigationBars(!colors.dark);

        if (prefs.getKeepScreenOn()) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    private void styleChips() {
        float r = ThemeHelper.dp(root, 12);
        for (int i = 0; i < chips.length; i++) {
            boolean sel = chipUnits[i] == unit;
            chips[i].setBackground(sel
                    ? ThemeHelper.rounded(colors.accent, r)
                    : ThemeHelper.rounded(colors.card, r, colors.track, ThemeHelper.dp(root, 1)));
            chips[i].setTextColor(sel ? colors.onAccent : colors.text);
        }
    }
}
