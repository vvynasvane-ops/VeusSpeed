package com.veus.speedpro;

import android.annotation.SuppressLint;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.os.SystemClock;

/**
 * Pure-GPS speed + trip stats via the framework LocationManager.
 * No Google Play Services needed, so it is 100% offline and works on any device.
 */
public class SpeedTracker implements LocationListener {

    public interface Listener {
        void onSpeedUpdate(SpeedTracker t);
        void onGpsState(SpeedTracker t);
    }

    private static final double NOISE_GATE_MS = 0.5;   // below this = stopped
    private static final long STALE_MS = 5000;         // no fix for this long = lost
    private static final float GOOD_ACCURACY_M = 40f;

    private final LocationManager lm;
    private Listener listener;

    private boolean started;
    private boolean gpsEnabled = true;
    private boolean hasFix;
    private float accuracy = -1f;

    private double speedMs, maxMs, distanceM;
    private long movingMs, totalMs;
    private long lastFixElapsed = -1;
    private Location lastLoc;

    public SpeedTracker(Context ctx) {
        lm = (LocationManager) ctx.getApplicationContext().getSystemService(Context.LOCATION_SERVICE);
    }

    public void setListener(Listener l) { this.listener = l; }

    @SuppressLint("MissingPermission")
    public void start() {
        if (started || lm == null) return;
        try {
            gpsEnabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500L, 0f, this, Looper.getMainLooper());
            started = true;
        } catch (SecurityException | IllegalArgumentException e) {
            started = false;
        }
        notifyGps();
    }

    public void stop() {
        if (lm != null) {
            try { lm.removeUpdates(this); } catch (Exception ignored) { }
        }
        started = false;
        hasFix = false;
        speedMs = 0;
        lastLoc = null;
        lastFixElapsed = -1;
    }

    public void reset() {
        maxMs = 0;
        distanceM = 0;
        movingMs = 0;
        totalMs = 0;
        speedMs = 0;
        notifySpeed();
    }

    /** Call about once per second from the UI to detect a lost GPS fix. */
    public void tick() {
        if (!started) return;
        boolean enabledNow = true;
        try { enabledNow = lm.isProviderEnabled(LocationManager.GPS_PROVIDER); } catch (Exception ignored) { }
        boolean changed = enabledNow != gpsEnabled;
        gpsEnabled = enabledNow;
        if (hasFix && SystemClock.elapsedRealtime() - lastFixElapsed > STALE_MS) {
            hasFix = false;
            speedMs = 0;
            changed = true;
            notifySpeed();
        }
        if (changed) notifyGps();
    }

    @Override
    public void onLocationChanged(Location loc) {
        long now = SystemClock.elapsedRealtime();
        double v;
        if (loc.hasSpeed()) {
            v = loc.getSpeed();
        } else if (lastLoc != null) {
            double dt = (loc.getTime() - lastLoc.getTime()) / 1000.0;
            v = dt > 0 ? loc.distanceTo(lastLoc) / dt : 0;
        } else {
            v = 0;
        }
        if (v < NOISE_GATE_MS) v = 0;

        boolean good = !loc.hasAccuracy() || loc.getAccuracy() <= GOOD_ACCURACY_M;
        accuracy = loc.hasAccuracy() ? loc.getAccuracy() : -1f;

        long dtMs = (lastFixElapsed < 0) ? 0 : Math.min(now - lastFixElapsed, 10000L);
        lastFixElapsed = now;
        totalMs += dtMs;
        if (v > 0 && good) {
            movingMs += dtMs;
            distanceM += v * (dtMs / 1000.0);
            if (v > maxMs) maxMs = v;
        }

        boolean fixChanged = !hasFix;
        hasFix = true;
        speedMs = v;
        lastLoc = loc;
        notifySpeed();
        if (fixChanged) notifyGps();
    }

    @Override public void onProviderEnabled(String provider) {
        if (LocationManager.GPS_PROVIDER.equals(provider)) { gpsEnabled = true; notifyGps(); }
    }

    @Override public void onProviderDisabled(String provider) {
        if (LocationManager.GPS_PROVIDER.equals(provider)) {
            gpsEnabled = false;
            hasFix = false;
            speedMs = 0;
            notifySpeed();
            notifyGps();
        }
    }

    @SuppressWarnings("deprecation")
    @Override public void onStatusChanged(String provider, int status, Bundle extras) { /* required on API < 30 */ }

    private void notifySpeed() { if (listener != null) listener.onSpeedUpdate(this); }
    private void notifyGps() { if (listener != null) listener.onGpsState(this); }

    public boolean isStarted() { return started; }
    public boolean isGpsEnabled() { return gpsEnabled; }
    public boolean hasFix() { return hasFix; }
    public float getAccuracy() { return accuracy; }
    public double getSpeedMs() { return speedMs; }
    public double getMaxMs() { return maxMs; }
    public double getAvgMs() { return movingMs > 0 ? distanceM / (movingMs / 1000.0) : 0; }
    public double getDistanceM() { return distanceM; }
    public long getTotalMs() { return totalMs; }
}
