package com.veus.speedpro;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.SwitchCompat;

/**
 * Central theme engine. Views opt in through android:tag:
 * bg, card, title, sub, accent, btn, icon, input.
 */
public final class ThemeHelper {

    public static final class Palette {
        public final String name;
        public final int color;
        Palette(String name, int color) { this.name = name; this.color = color; }
    }

    public static final Palette[] PALETTES = new Palette[]{
            new Palette("Neon Cyan", 0xFF00E5FF),
            new Palette("Sport Red", 0xFFFF3D3D),
            new Palette("Classic Amber", 0xFFFFB300),
            new Palette("Matrix Green", 0xFF00E676),
            new Palette("Royal Violet", 0xFFB388FF),
            new Palette("Sunset Orange", 0xFFFF7A1A),
            new Palette("Hot Pink", 0xFFFF4081),
            new Palette("Ocean Blue", 0xFF4D8DFF)
    };

    public static final class Colors {
        public int bg, card, text, sub, track, accent, accentText, onAccent, danger;
        public boolean dark;
    }

    private ThemeHelper() {}

    public static void applyNightMode(int mode) {
        switch (mode) {
            case 1: AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO); break;
            case 2: AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES); break;
            default: AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
        }
    }

    public static int customColor(int hue) {
        return Color.HSVToColor(new float[]{hue % 360, 0.85f, 1f});
    }

    public static Colors resolve(Context ctx, Prefs prefs) {
        Colors c = new Colors();
        int ui = ctx.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        c.dark = ui == Configuration.UI_MODE_NIGHT_YES;
        if (c.dark) {
            c.bg = 0xFF0B0F14; c.card = 0xFF141B24; c.text = 0xFFF2F6FA;
            c.sub = 0xFF8FA0B3; c.track = 0xFF26323F;
        } else {
            c.bg = 0xFFF4F7FA; c.card = 0xFFFFFFFF; c.text = 0xFF10161D;
            c.sub = 0xFF5B6B7B; c.track = 0xFFD5DEE7;
        }
        int idx = prefs.getPalette();
        c.accent = (idx >= 0 && idx < PALETTES.length) ? PALETTES[idx].color : customColor(prefs.getCustomHue());
        if (c.dark) {
            c.accentText = c.accent;
        } else {
            float[] hsv = new float[3];
            Color.colorToHSV(c.accent, hsv);
            hsv[2] = hsv[2] * 0.70f;
            c.accentText = Color.HSVToColor(hsv);
        }
        double lum = (0.299 * Color.red(c.accent) + 0.587 * Color.green(c.accent) + 0.114 * Color.blue(c.accent)) / 255.0;
        c.onAccent = lum > 0.55 ? 0xFF000000 : 0xFFFFFFFF;
        c.danger = 0xFFE53935;
        return c;
    }

    public static int dp(View v, float dp) {
        return Math.round(dp * v.getResources().getDisplayMetrics().density);
    }

    public static GradientDrawable rounded(int fill, float radiusPx) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.RECTANGLE);
        d.setColor(fill);
        d.setCornerRadius(radiusPx);
        return d;
    }

    public static GradientDrawable rounded(int fill, float radiusPx, int strokeColor, int strokePx) {
        GradientDrawable d = rounded(fill, radiusPx);
        d.setStroke(strokePx, strokeColor);
        return d;
    }

    private static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | (a << 24);
    }

    /** Recursively paint a view tree according to android:tag markers. */
    public static void apply(View v, Colors c) {
        Object tag = v.getTag();
        if (tag instanceof String) {
            String t = (String) tag;
            switch (t) {
                case "bg":
                    v.setBackgroundColor(c.bg);
                    break;
                case "card":
                    v.setBackground(rounded(c.card, dp(v, 18)));
                    break;
                case "title":
                    if (v instanceof TextView) ((TextView) v).setTextColor(c.text);
                    break;
                case "sub":
                    if (v instanceof TextView) ((TextView) v).setTextColor(c.sub);
                    break;
                case "accent":
                    if (v instanceof TextView) ((TextView) v).setTextColor(c.accentText);
                    break;
                case "btn":
                    v.setBackground(rounded(c.accent, dp(v, 14)));
                    if (v instanceof TextView) ((TextView) v).setTextColor(c.onAccent);
                    break;
                case "icon":
                    if (v instanceof ImageView) ((ImageView) v).setColorFilter(c.text);
                    break;
                case "input":
                    v.setBackground(rounded(c.track, dp(v, 10)));
                    if (v instanceof EditText) {
                        ((EditText) v).setTextColor(c.text);
                        ((EditText) v).setHintTextColor(c.sub);
                    }
                    break;
                default:
                    break;
            }
        }

        ColorStateList checked = new ColorStateList(
                new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{c.accent, c.sub});
        if (v instanceof SwitchCompat) {
            SwitchCompat s = (SwitchCompat) v;
            s.setThumbTintList(checked);
            s.setTrackTintList(new ColorStateList(
                    new int[][]{{android.R.attr.state_checked}, {}},
                    new int[]{alpha(c.accent, 0x80), alpha(c.sub, 0x60)}));
        } else if (v instanceof RadioButton) {
            ((RadioButton) v).setButtonTintList(checked);
        } else if (v instanceof SeekBar) {
            SeekBar sb = (SeekBar) v;
            sb.setThumbTintList(ColorStateList.valueOf(c.accent));
            sb.setProgressTintList(ColorStateList.valueOf(c.accent));
            sb.setProgressBackgroundTintList(ColorStateList.valueOf(c.track));
        }

        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) apply(g.getChildAt(i), c);
        }
    }
}
