package com.veus.speedpro;

import android.content.Context;
import android.content.SharedPreferences;

/** Thin wrapper over SharedPreferences. All settings persist offline. */
public final class Prefs {
    private final SharedPreferences sp;

    public Prefs(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("veusspeed_prefs", Context.MODE_PRIVATE);
    }

    public Units getUnit() { return Units.fromName(sp.getString("unit", "KMH"), Units.KMH); }
    public void setUnit(Units u) { sp.edit().putString("unit", u.name()).apply(); }

    /** 0 = system, 1 = light, 2 = dark */
    public int getThemeMode() { return sp.getInt("theme_mode", 0); }
    public void setThemeMode(int v) { sp.edit().putInt("theme_mode", v).apply(); }

    /** index into ThemeHelper.PALETTES; index == PALETTES.length means custom hue */
    public int getPalette() { return sp.getInt("palette", 0); }
    public void setPalette(int v) { sp.edit().putInt("palette", v).apply(); }

    public int getCustomHue() { return sp.getInt("custom_hue", 200); }
    public void setCustomHue(int v) { sp.edit().putInt("custom_hue", v).apply(); }

    /** 0 = digital, 1 = analog gauge, 2 = HUD (mirrored digital) */
    public int getGaugeStyle() { return sp.getInt("gauge_style", 1); }
    public void setGaugeStyle(int v) { sp.edit().putInt("gauge_style", v).apply(); }

    public boolean getKeepScreenOn() { return sp.getBoolean("keep_on", true); }
    public void setKeepScreenOn(boolean v) { sp.edit().putBoolean("keep_on", v).apply(); }

    /** Speed limit in km/h; 0 = off */
    public int getSpeedLimitKmh() { return sp.getInt("limit_kmh", 0); }
    public void setSpeedLimitKmh(int v) { sp.edit().putInt("limit_kmh", v).apply(); }

    public boolean getVibrate() { return sp.getBoolean("vibrate", true); }
    public void setVibrate(boolean v) { sp.edit().putBoolean("vibrate", v).apply(); }

    public boolean getSound() { return sp.getBoolean("sound", true); }
    public void setSound(boolean v) { sp.edit().putBoolean("sound", v).apply(); }

    public boolean getProximity() { return sp.getBoolean("proximity", true); }
    public void setProximity(boolean v) { sp.edit().putBoolean("proximity", v).apply(); }

    public boolean getImpact() { return sp.getBoolean("impact", true); }
    public void setImpact(boolean v) { sp.edit().putBoolean("impact", v).apply(); }

    /** 0 = low, 1 = medium, 2 = high */
    public int getImpactSens() { return sp.getInt("impact_sens", 1); }
    public void setImpactSens(int v) { sp.edit().putInt("impact_sens", v).apply(); }

    public boolean getCameraMode() { return sp.getBoolean("camera_mode", false); }
    public void setCameraMode(boolean v) { sp.edit().putBoolean("camera_mode", v).apply(); }
}
