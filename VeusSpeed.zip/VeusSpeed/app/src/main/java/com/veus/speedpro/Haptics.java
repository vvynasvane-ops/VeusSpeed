package com.veus.speedpro;

import android.content.Context;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;

/** Vibration + beep alerts. Every call is failure-safe. */
public final class Haptics {
    private Vibrator vibrator;
    private ToneGenerator tone;

    @SuppressWarnings("deprecation")
    public Haptics(Context ctx) {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                VibratorManager vm = (VibratorManager) ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
                if (vm != null) vibrator = vm.getDefaultVibrator();
            } else {
                vibrator = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
            }
        } catch (Exception ignored) {
            vibrator = null;
        }
    }

    @SuppressWarnings("deprecation")
    public void alert(boolean vibrate, boolean sound, boolean strong) {
        if (vibrate && vibrator != null && vibrator.hasVibrator()) {
            try {
                long ms = strong ? 600 : 250;
                if (Build.VERSION.SDK_INT >= 26) {
                    vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vibrator.vibrate(ms);
                }
            } catch (Exception ignored) { }
        }
        if (sound) {
            try {
                if (tone == null) tone = new ToneGenerator(AudioManager.STREAM_ALARM, 80);
                tone.startTone(strong ? ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD : ToneGenerator.TONE_PROP_BEEP,
                        strong ? 400 : 150);
            } catch (RuntimeException ignored) { }
        }
    }

    public void release() {
        if (tone != null) {
            try { tone.release(); } catch (Exception ignored) { }
            tone = null;
        }
    }
}
