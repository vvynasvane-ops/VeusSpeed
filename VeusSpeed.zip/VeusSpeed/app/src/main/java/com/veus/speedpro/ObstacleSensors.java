package com.veus.speedpro;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.SystemClock;

/**
 * Level 1 obstacle sensing (always offline):
 *  - proximity sensor: object right at the phone
 *  - accelerometer: sudden jolt / impact (g-force spike)
 */
public class ObstacleSensors implements SensorEventListener {

    public interface Listener {
        void onProximity(boolean near);
        void onImpact(float g);
    }

    private static final long IMPACT_COOLDOWN_MS = 3000;

    private final SensorManager sm;
    private final Sensor proximitySensor;
    private final Sensor accelSensor;
    private Listener listener;
    private boolean proximityOn, impactOn;
    private float thresholdG = 2.5f;
    private long lastImpact;
    private boolean lastNear;
    private boolean registered;

    public ObstacleSensors(Context ctx) {
        sm = (SensorManager) ctx.getApplicationContext().getSystemService(Context.SENSOR_SERVICE);
        proximitySensor = sm != null ? sm.getDefaultSensor(Sensor.TYPE_PROXIMITY) : null;
        accelSensor = sm != null ? sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) : null;
    }

    public void setListener(Listener l) { listener = l; }
    public boolean hasProximity() { return proximitySensor != null; }
    public boolean hasAccelerometer() { return accelSensor != null; }

    /** sensitivity: 0 low (3.5 g), 1 medium (2.5 g), 2 high (1.8 g) */
    public void start(boolean proximity, boolean impact, int sensitivity) {
        stop();
        if (sm == null) return;
        proximityOn = proximity;
        impactOn = impact;
        thresholdG = sensitivity == 0 ? 3.5f : (sensitivity == 2 ? 1.8f : 2.5f);
        if (proximityOn && proximitySensor != null) {
            sm.registerListener(this, proximitySensor, SensorManager.SENSOR_DELAY_NORMAL);
            registered = true;
        }
        if (impactOn && accelSensor != null) {
            sm.registerListener(this, accelSensor, SensorManager.SENSOR_DELAY_GAME);
            registered = true;
        }
    }

    public void stop() {
        if (sm != null && registered) {
            try { sm.unregisterListener(this); } catch (Exception ignored) { }
        }
        registered = false;
        lastNear = false;
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        if (listener == null) return;
        if (e.sensor.getType() == Sensor.TYPE_PROXIMITY) {
            float v = e.values[0];
            boolean near = v < Math.min(e.sensor.getMaximumRange(), 5f);
            if (near != lastNear) {
                lastNear = near;
                listener.onProximity(near);
            }
        } else if (e.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float x = e.values[0], y = e.values[1], z = e.values[2];
            float g = (float) Math.sqrt(x * x + y * y + z * z) / SensorManager.GRAVITY_EARTH;
            long now = SystemClock.elapsedRealtime();
            if (g > thresholdG && now - lastImpact > IMPACT_COOLDOWN_MS) {
                lastImpact = now;
                listener.onImpact(g);
            }
        }
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }
}
