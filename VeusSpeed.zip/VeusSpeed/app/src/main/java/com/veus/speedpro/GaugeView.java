package com.veus.speedpro;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

import java.util.Locale;

/** Custom analog speedometer dial. Value is expressed in the currently selected unit. */
public class GaugeView extends View {

    private static final float START = 150f;
    private static final float SWEEP = 240f;

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arcPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tickPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint valuePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint unitPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint needlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hubPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();

    private Units unit = Units.KMH;
    private float shown;
    private boolean over;
    private int accent = 0xFF00E5FF;
    private int trackColor = 0xFF26323F;
    private int textColor = 0xFFF2F6FA;
    private int subColor = 0xFF8FA0B3;
    private int dangerColor = 0xFFE53935;
    private ValueAnimator animator;

    public GaugeView(Context c) { super(c); init(); }
    public GaugeView(Context c, AttributeSet a) { super(c, a); init(); }
    public GaugeView(Context c, AttributeSet a, int s) { super(c, a, s); init(); }

    private void init() {
        trackPaint.setStyle(Paint.Style.STROKE);
        trackPaint.setStrokeCap(Paint.Cap.ROUND);
        arcPaint.setStyle(Paint.Style.STROKE);
        arcPaint.setStrokeCap(Paint.Cap.ROUND);
        tickPaint.setStyle(Paint.Style.STROKE);
        tickPaint.setStrokeCap(Paint.Cap.ROUND);
        labelPaint.setTextAlign(Paint.Align.CENTER);
        valuePaint.setTextAlign(Paint.Align.CENTER);
        valuePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        unitPaint.setTextAlign(Paint.Align.CENTER);
        needlePaint.setStyle(Paint.Style.STROKE);
        needlePaint.setStrokeCap(Paint.Cap.ROUND);
        hubPaint.setStyle(Paint.Style.FILL);
    }

    public void setPalette(int accent, int track, int text, int sub, int danger) {
        this.accent = accent;
        this.trackColor = track;
        this.textColor = text;
        this.subColor = sub;
        this.dangerColor = danger;
        invalidate();
    }

    public void setUnit(Units u) {
        this.unit = u;
        invalidate();
    }

    public void setOver(boolean over) {
        if (this.over != over) {
            this.over = over;
            invalidate();
        }
    }

    /** Animate the needle to a new value (already in the current unit). */
    public void setSpeed(float value) {
        if (animator != null) animator.cancel();
        animator = ValueAnimator.ofFloat(shown, value);
        animator.setDuration(250);
        animator.addUpdateListener(a -> {
            shown = (float) a.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (animator != null) animator.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        int w = View.MeasureSpec.getSize(widthSpec);
        int cap = Math.round(380 * getResources().getDisplayMetrics().density);
        int h = Math.min(Math.round(w * 0.95f), cap);
        setMeasuredDimension(w, h);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h * 0.5f;
        float r = Math.min(w * 0.45f, h * 0.42f);
        float stroke = r * 0.09f;

        trackPaint.setColor(trackColor);
        trackPaint.setStrokeWidth(stroke);
        arcPaint.setStrokeWidth(stroke);

        float arcR = r - stroke / 2f;
        oval.set(cx - arcR, cy - arcR, cx + arcR, cy + arcR);
        canvas.drawArc(oval, START, SWEEP, false, trackPaint);

        float frac = (float) Math.max(0.0, Math.min(1.0, shown / unit.gaugeMax));
        int active = over ? dangerColor : accent;
        arcPaint.setColor(active);
        if (frac > 0.002f) canvas.drawArc(oval, START, SWEEP * frac, false, arcPaint);

        // ticks and labels
        int n = (int) Math.round(unit.gaugeMax / unit.majorStep);
        if (n < 1) n = 1;
        int labelEvery = n > 9 ? 2 : 1;
        int decimals = unit.majorStep < 1 ? 2 : 0;
        float tickOuter = r - stroke * 1.4f;
        tickPaint.setColor(subColor);
        labelPaint.setColor(subColor);
        labelPaint.setTextSize(r * 0.095f);
        for (int i = 0; i <= n; i++) {
            float angle = START + SWEEP * ((float) i / n);
            double rad = Math.toRadians(angle);
            float cos = (float) Math.cos(rad), sin = (float) Math.sin(rad);
            tickPaint.setStrokeWidth(r * 0.022f);
            canvas.drawLine(cx + cos * tickOuter, cy + sin * tickOuter,
                    cx + cos * (tickOuter - r * 0.09f), cy + sin * (tickOuter - r * 0.09f), tickPaint);
            if (i % labelEvery == 0) {
                String t = String.format(Locale.US, "%." + decimals + "f", i * unit.majorStep);
                float lr = tickOuter - r * 0.22f;
                canvas.drawText(t, cx + cos * lr, cy + sin * lr + labelPaint.getTextSize() * 0.35f, labelPaint);
            }
            if (i < n) {
                tickPaint.setStrokeWidth(r * 0.012f);
                for (int j = 1; j < 5; j++) {
                    float a2 = START + SWEEP * ((i + j / 5f) / n);
                    double r2 = Math.toRadians(a2);
                    float c2 = (float) Math.cos(r2), s2 = (float) Math.sin(r2);
                    canvas.drawLine(cx + c2 * tickOuter, cy + s2 * tickOuter,
                            cx + c2 * (tickOuter - r * 0.045f), cy + s2 * (tickOuter - r * 0.045f), tickPaint);
                }
            }
        }

        // needle
        float needleAngle = START + SWEEP * frac;
        double nr = Math.toRadians(needleAngle);
        float nl = tickOuter - r * 0.12f;
        needlePaint.setColor(active);
        needlePaint.setStrokeWidth(r * 0.04f);
        canvas.drawLine(cx, cy, cx + (float) Math.cos(nr) * nl, cy + (float) Math.sin(nr) * nl, needlePaint);
        hubPaint.setColor(active);
        canvas.drawCircle(cx, cy, r * 0.075f, hubPaint);

        // value + unit
        valuePaint.setColor(over ? dangerColor : textColor);
        valuePaint.setTextSize(r * 0.30f);
        canvas.drawText(String.format(Locale.US, "%." + unit.decimals + "f", shown), cx, cy + r * 0.74f, valuePaint);
        unitPaint.setColor(subColor);
        unitPaint.setTextSize(r * 0.13f);
        canvas.drawText(unit.label, cx, cy + r * 0.95f, unitPaint);
    }
}
