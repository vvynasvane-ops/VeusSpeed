package com.veus.speedpro;

import android.app.Application;

/** Holds the trip tracker and data stores so trip stats survive activity recreation (rotation, theme change). */
public class SpeedApp extends Application {
    /** The boot animation only plays once per process. */
    public static boolean booted;

    private SpeedTracker tracker;
    private TripStore trips;
    private WaypointStore waypoints;

    @Override
    public void onCreate() {
        super.onCreate();
        ThemeHelper.applyNightMode(new Prefs(this).getThemeMode());
        tracker = new SpeedTracker(this);
        trips = new TripStore(this);
        waypoints = new WaypointStore(this);
    }

    public SpeedTracker getTracker() { return tracker; }
    public TripStore getTrips() { return trips; }
    public WaypointStore getWaypoints() { return waypoints; }
}
