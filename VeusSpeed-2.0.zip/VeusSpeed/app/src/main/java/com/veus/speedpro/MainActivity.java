package com.veus.speedpro;

import android.Manifest;
import android.app.PictureInPictureParams;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Rational;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.content.pm.ActivityInfo;
import android.graphics.Typeface;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity
        implements SpeedTracker.Listener, ObstacleSensors.Listener {

    // ---- services ---------------------------------------------------------------------------
    private Prefs prefs;
    private SpeedTracker tracker;
    private TripStore trips;
    private WaypointStore waypoints;
    private ObstacleSensors sensors;
    private CameraObstacleDetector camera;
    private Haptics haptics;
    private Voice voice;
    private SensorManager sensorManager;
    private final Handler handler = new Handler(Looper.getMainLooper());

    // ---- state ------------------------------------------------------------------------------
    private ThemeHelper.Colors colors;
    private Units unit = Units.KMH;
    private int tab;
    private boolean inPip, cockpit, autoNight, pendingBoot, askedLocation, suppressCameraSwitch;
    private boolean prevOver, prevWarn, arrived, crashWatch, labTabVisible;
    private long lastOverAlert, lastPaceNudge, paceOffSince, crashWatchStart, tickCount;
    private double crashPreSpeed;
    private int announcedK, breakCount, battPct = -1;
    private boolean charging, lowBattWarned;
    private final HashMap<Long, Long> hazardAlerted = new HashMap<>();
    private CountDownTimer sosTimer;
    private AlertDialog sosDialog;

    // ---- views ------------------------------------------------------------------------------
    private View root, headerRow, chipsRow, tabsRoot, scrollTabs, display, digitalBlock, boot;
    private StarfieldView fxSpace;
    private OverlayFxView fxOverlay;
    private GaugeView gauge;
    private TextView speedText, unitText, gpsStatus, batteryText, limitBanner, obstacleBanner;
    private final TextView[] chips = new TextView[5];
    private final Units[] chipUnits = {Units.MS, Units.KMH, Units.MPH, Units.KNOTS, Units.MI_S};
    private final TextView[] tabs = new TextView[4];
    private final View[] pages = new View[4];
    private TextView[] tel1, tel2, ins1, ins2, ins3;
    private TextView txtLabStatus, txtCo2, txtNav, txtPace, txtGpeaks, txtMapInfo, txtSun, txtSats, txtLife, sensorStatus;
    private final TextView[][] labViews = new TextView[6][];
    private CompassView compass;
    private GForceView gforce;
    private GraphView graphSpeed;
    private RouteView routeLive;
    private SatView satView;
    private DeltaBarView paceBar;
    private View cardPace;
    private SwitchCompat switchCamera;
    private PreviewView previewView;

    private final ActivityResultLauncher<String[]> locationLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                if (hasLocationPermission()) tracker.start();
                updateGpsStatus();
            });

    private final ActivityResultLauncher<String> cameraLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) {
                    startCamera();
                } else {
                    prefs.setCameraMode(false);
                    setCameraSwitch(false);
                    Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show();
                }
            });

    // =========================================================================================
    // lifecycle
    // =========================================================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        SpeedApp app = (SpeedApp) getApplication();
        tracker = app.getTracker();
        trips = app.getTrips();
        waypoints = app.getWaypoints();
        haptics = new Haptics(this);
        sensors = new ObstacleSensors(this);
        sensors.setListener(this);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        camera = new CameraObstacleDetector(this);
        camera.setListener(new CameraObstacleDetector.Listener() {
            @Override public void onCameraFrame(float density, boolean warning) {
                if (warning) showSafety("Obstacle ahead - slow down (camera)", true);
            }
            @Override public void onCameraError(String message) {
                prefs.setCameraMode(false);
                setCameraSwitch(false);
                stopCamera();
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
            }
        });
        unit = prefs.getUnit();
        tab = Math.max(0, Math.min(3, prefs.getTab()));
        bindUi();
        if (!SpeedApp.booted) {
            SpeedApp.booted = true;
            pendingBoot = prefs.getBoot();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        unit = prefs.getUnit();
        tracker.setListener(this);
        ensureLocation();
        if (prefs.getVoice() && voice == null) voice = new Voice(this);
        startSensors();
        startLight();
        applyAll();
        if (pendingBoot) {
            pendingBoot = false;
            boot.setVisibility(View.VISIBLE);
            ((BootView) boot).start(null);
        }
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    @Override
    protected void onStop() {
        super.onStop();
        handler.removeCallbacks(ticker);
        tracker.stop();
        sensors.stop();
        stopCamera();
        if (sensorManager != null) sensorManager.unregisterListener(lightListener);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (sosTimer != null) sosTimer.cancel();
        if (voice != null) voice.shutdown();
        haptics.release();
        camera.release();
        handler.removeCallbacksAndMessages(null);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (inPip) return;
        bindUi();
        applyAll();
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (!prefs.getPip() || inPip || isFinishing() || !tracker.isStarted()) return;
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                enterPictureInPictureMode(new PictureInPictureParams.Builder()
                        .setAspectRatio(new Rational(1, 1)).build());
            } else {
                enterPictureInPictureMode();
            }
        } catch (Exception ignored) { }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isInPip, Configuration cfg) {
        super.onPictureInPictureModeChanged(isInPip, cfg);
        inPip = isInPip;
        applyPipUi();
    }

    // =========================================================================================
    // view binding
    // =========================================================================================

    private void bindUi() {
        setContentView(R.layout.activity_main);
        root = findViewById(R.id.root);
        fxSpace = findViewById(R.id.fxSpace);
        fxOverlay = findViewById(R.id.fxOverlay);
        boot = findViewById(R.id.boot);
        headerRow = findViewById(R.id.headerRow);
        chipsRow = findViewById(R.id.chipsRow);
        tabsRoot = findViewById(R.id.tabsRoot);
        scrollTabs = findViewById(R.id.scrollTabs);
        display = findViewById(R.id.display);
        digitalBlock = findViewById(R.id.digitalBlock);
        gauge = findViewById(R.id.gauge);
        speedText = findViewById(R.id.speedText);
        unitText = findViewById(R.id.unitText);
        gpsStatus = findViewById(R.id.gpsStatus);
        batteryText = findViewById(R.id.batteryText);
        limitBanner = findViewById(R.id.limitBanner);
        obstacleBanner = findViewById(R.id.obstacleBanner);
        compass = findViewById(R.id.compass);
        gforce = findViewById(R.id.gforce);
        graphSpeed = findViewById(R.id.graphSpeed);
        routeLive = findViewById(R.id.routeLive);
        satView = findViewById(R.id.satView);
        paceBar = findViewById(R.id.paceBar);
        cardPace = findViewById(R.id.cardPace);
        txtNav = findViewById(R.id.txtNav);
        txtPace = findViewById(R.id.txtPace);
        txtGpeaks = findViewById(R.id.txtGpeaks);
        txtMapInfo = findViewById(R.id.txtMapInfo);
        txtSun = findViewById(R.id.txtSun);
        txtSats = findViewById(R.id.txtSats);
        txtLife = findViewById(R.id.txtLife);
        sensorStatus = findViewById(R.id.sensorStatus);
        switchCamera = findViewById(R.id.switchCamera);
        previewView = findViewById(R.id.previewView);

        int[] chipIds = {R.id.chipMs, R.id.chipKmh, R.id.chipMph, R.id.chipKn, R.id.chipMis};
        for (int i = 0; i < 5; i++) {
            final int idx = i;
            chips[i] = findViewById(chipIds[i]);
            chips[i].setOnClickListener(v -> setUnit(chipUnits[idx]));
        }
        int[] tabIds = {R.id.tabDash, R.id.tabLab, R.id.tabMap, R.id.tabSys};
        int[] pageIds = {R.id.pageDash, R.id.pageLab, R.id.pageMap, R.id.pageSys};
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            tabs[i] = findViewById(tabIds[i]);
            pages[i] = findViewById(pageIds[i]);
            tabs[i].setOnClickListener(v -> showTab(idx));
        }

        findViewById(R.id.btnSettings).setOnClickListener(v -> open(SettingsActivity.class));
        findViewById(R.id.btnTrips).setOnClickListener(v -> open(TripsActivity.class));
        findViewById(R.id.btnReset).setOnClickListener(v -> endTrip());
        findViewById(R.id.btnSos).setOnClickListener(v -> confirmSos());
        findViewById(R.id.btnMark).setOnClickListener(v -> markHere(0));
        findViewById(R.id.btnHazard).setOnClickListener(v -> markHere(1));
        findViewById(R.id.btnPoints).setOnClickListener(v -> showPoints());
        display.setOnClickListener(v -> cycleStyle());
        display.setOnLongClickListener(v -> { setCockpit(!cockpit); return true; });
        gpsStatus.setOnClickListener(v -> {
            if (!hasLocationPermission()) { askedLocation = false; ensureLocation(); }
            else if (!tracker.isGpsEnabled()) startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
        });
        switchCamera.setChecked(prefs.getCameraMode());
        switchCamera.setOnCheckedChangeListener((b, checked) -> {
            if (suppressCameraSwitch) return;
            prefs.setCameraMode(checked);
            if (checked) ensureCamera(); else stopCamera();
        });

        buildGrids();
    }

    private void sectionTitle(LinearLayout parent, String text) {
        TextView t = UiKit.label(this, parent, text, "accent", 13);
        t.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        t.setLetterSpacing(0.15f);
        ((LinearLayout.LayoutParams) t.getLayoutParams()).topMargin = 0;
    }

    private TextView[] labRow(LinearLayout parent, String a, String b, String c, boolean header) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        parent.addView(row, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        row.setPadding(0, UiKit.dp(this, 6), 0, 0);
        String[] txt = {a, b, c};
        TextView[] out = new TextView[3];
        for (int i = 0; i < 3; i++) {
            TextView t = new TextView(this);
            t.setText(txt[i]);
            t.setTag(header ? "sub" : "title");
            t.setTextSize(header ? 11f : 14f);
            t.setTypeface(Typeface.create("sans-serif-condensed", header ? Typeface.NORMAL : Typeface.BOLD));
            if (i > 0) t.setGravity(Gravity.END);
            row.addView(t, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, i == 0 ? 1.6f : 1f));
            out[i] = t;
        }
        return out;
    }

    private void buildGrids() {
        LinearLayout tel = findViewById(R.id.cardTelemetry);
        tel1 = UiKit.statRow(this, tel, "MAX", "AVG", "TRIP", "TIME");
        ((LinearLayout.LayoutParams) ((View) tel1[0].getParent().getParent()).getLayoutParams()).topMargin = 0;
        tel2 = UiKit.statRow(this, tel, "ALT", "CLIMB", "ACCEL", "HEADING");

        LinearLayout perf = findViewById(R.id.cardPerf);
        sectionTitle(perf, "PERFORMANCE LAB");
        txtLabStatus = UiKit.label(this, perf, "", "title", 14);
        labRow(perf, "TEST", "LAST", "BEST", true);
        for (int i = 0; i < 6; i++) labViews[i] = labRow(perf, PerfLab.NAMES[i], "--", "--", false);
        UiKit.button(this, perf, "RESET LAB", "ghost", () -> { tracker.perf.reset(); refreshTab(true); });

        LinearLayout ins = findViewById(R.id.cardInsights);
        sectionTitle(ins, "DRIVE INSIGHTS");
        ins1 = UiKit.statRow(this, ins, "ECO SCORE", "HARSH ACC", "HARSH BRK", "HARSH TURN");
        ins2 = UiKit.statRow(this, ins, "MOVING", "STOPPED", "STOPS", "OVER LIMIT");
        ins3 = UiKit.statRow(this, ins, "ASCENT", "DESCENT", "FUEL", "COST");
        txtCo2 = UiKit.label(this, ins, "", "sub", 12);
    }

    // =========================================================================================
    // applying settings / theme
    // =========================================================================================

    private void applyAll() {
        applyOrientation();
        applyTheme();
        applyGaugeStyle();
        applyEffects();
        updateChips();
        showTab(tab);
        applyPipUi();
        setCockpit(cockpit);
        setCameraSwitch(prefs.getCameraMode());
        if (prefs.getCameraMode()) ensureCamera(); else previewView.setVisibility(View.GONE);
        updateGpsStatus();
        renderAll();
    }

    private void applyOrientation() {
        int o = prefs.getOrientation();
        setRequestedOrientation(o == 1 ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                : (o == 2 ? ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE : ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED));
    }

    private void applyTheme() {
        int nm = prefs.getNightMode();
        boolean night = nm == 2 || (nm == 1 && autoNight);
        colors = ThemeHelper.resolve(this, prefs, night);
        ThemeHelper.apply(root, colors);
        NeonView[] vs = {gauge, compass, gforce, graphSpeed, routeLive, satView, paceBar, fxSpace, fxOverlay,
                (NeonView) boot};
        for (NeonView v : vs) v.setPalette(colors.accent, colors.track, colors.text, colors.sub, colors.danger);
        fxSpace.setDarkTheme(colors.dark);
        fxOverlay.setAlertColor(night ? 0xFFFF0000 : 0xFFFF1744);
        getWindow().setStatusBarColor(colors.bg);
        getWindow().setNavigationBarColor(colors.bg);
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        c.setAppearanceLightStatusBars(!colors.dark);
        c.setAppearanceLightNavigationBars(!colors.dark);
        speedText.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        speedText.setLetterSpacing(0.04f);
        styleTabs();
        updateChips();
    }

    private void applyGaugeStyle() {
        int s = prefs.getGaugeStyle();
        boolean digital = s == 0 || s == 2;
        gauge.setVisibility(digital ? View.GONE : View.VISIBLE);
        digitalBlock.setVisibility(digital ? View.VISIBLE : View.GONE);
        digitalBlock.setScaleX(s == 2 ? -1f : 1f);
        if (!digital) gauge.setStyle(s == 1 ? GaugeView.STYLE_ANALOG : GaugeView.STYLE_REACTOR);
    }

    private void applyEffects() {
        fxSpace.setEffectsEnabled(prefs.getFxSpace());
        fxOverlay.setScanlines(prefs.getFxScan());
        gauge.setHeat(prefs.getHeat());
        if (prefs.getKeepScreenOn()) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private void cycleStyle() {
        int[] order = {3, 1, 0, 2};
        int cur = prefs.getGaugeStyle();
        int next = order[0];
        for (int i = 0; i < order.length; i++) if (order[i] == cur) next = order[(i + 1) % order.length];
        prefs.setGaugeStyle(next);
        applyGaugeStyle();
        renderHero();
    }

    private void setUnit(Units u) {
        unit = u;
        prefs.setUnit(u);
        updateChips();
        renderAll();
    }

    private void updateChips() {
        if (colors == null) return;
        for (int i = 0; i < 5; i++) {
            boolean sel = chipUnits[i] == unit;
            chips[i].setBackground(ThemeHelper.rounded(sel ? colors.accent : colors.track, UiKit.dp(this, 12)));
            chips[i].setTextColor(sel ? colors.onAccent : colors.sub);
        }
    }

    private void styleTabs() {
        if (colors == null) return;
        for (int i = 0; i < 4; i++) {
            boolean sel = i == tab;
            tabs[i].setBackground(sel
                    ? ThemeHelper.rounded(ThemeHelper.alpha(colors.accent, 0x28), UiKit.dp(this, 12), colors.accent, UiKit.dp(this, 1))
                    : ThemeHelper.rounded(ThemeHelper.alpha(colors.track, 0xAA), UiKit.dp(this, 12)));
            tabs[i].setTextColor(sel ? colors.accentText : colors.sub);
        }
    }

    private void showTab(int i) {
        tab = i;
        prefs.setTab(i);
        for (int k = 0; k < 4; k++) pages[k].setVisibility(k == i ? View.VISIBLE : View.GONE);
        styleTabs();
        refreshTab(true);
    }

    private void applyPipUi() {
        int vis = inPip ? View.GONE : View.VISIBLE;
        headerRow.setVisibility(vis);
        chipsRow.setVisibility(vis);
        tabsRoot.setVisibility(vis);
        if (scrollTabs != null) scrollTabs.setVisibility(vis);
    }

    private void setCockpit(boolean on) {
        cockpit = on;
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (on) {
            c.hide(WindowInsetsCompat.Type.systemBars());
            c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        } else {
            c.show(WindowInsetsCompat.Type.systemBars());
        }
    }

    private void open(Class<?> cls) {
        Intent i = new Intent(this, cls);
        i.addFlags(Intent.FLAG_ACTIVITY_NO_USER_ACTION);
        startActivity(i);
    }

    // =========================================================================================
    // permissions / sensors
    // =========================================================================================

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void ensureLocation() {
        if (hasLocationPermission()) {
            tracker.start();
        } else if (!askedLocation) {
            askedLocation = true;
            locationLauncher.launch(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION});
        }
    }

    private void startSensors() {
        sensors.start(prefs.getProximity(), prefs.getImpact(), prefs.getImpactSens(), prefs.getCrash());
        StringBuilder sb = new StringBuilder();
        sb.append("Proximity: ").append(sensors.hasProximity() ? (prefs.getProximity() ? "on" : "off") : "n/a");
        sb.append("  |  Impact: ").append(sensors.hasAccelerometer() ? (prefs.getImpact() ? "on" : "off") : "n/a");
        sb.append("  |  Crash SOS: ").append(prefs.getCrash() ? "on" : "off");
        sensorStatus.setText(sb.toString());
    }

    private final SensorEventListener lightListener = new SensorEventListener() {
        @Override public void onSensorChanged(SensorEvent e) {
            float lux = e.values[0];
            boolean n = autoNight;
            if (!n && lux < 5f) n = true;
            else if (n && lux > 25f) n = false;
            if (n != autoNight) {
                autoNight = n;
                applyTheme();
                renderAll();
            }
        }
        @Override public void onAccuracyChanged(Sensor s, int a) { }
    };

    private void startLight() {
        if (sensorManager == null) return;
        sensorManager.unregisterListener(lightListener);
        if (prefs.getNightMode() == 1) {
            Sensor light = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
            if (light != null) sensorManager.registerListener(lightListener, light, SensorManager.SENSOR_DELAY_NORMAL);
        } else {
            autoNight = false;
        }
    }

    private void ensureCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            cameraLauncher.launch(Manifest.permission.CAMERA);
        }
    }

    private void startCamera() {
        previewView.setVisibility(View.VISIBLE);
        camera.start(this, previewView);
    }

    private void stopCamera() {
        camera.stop();
        if (previewView != null) previewView.setVisibility(View.GONE);
    }

    private void setCameraSwitch(boolean on) {
        suppressCameraSwitch = true;
        switchCamera.setChecked(on);
        suppressCameraSwitch = false;
    }

    // =========================================================================================
    // tracker callbacks
    // =========================================================================================

    @Override
    public void onSpeedUpdate(SpeedTracker t) {
        renderHero();
        processEvents();
        refreshTab(false);
    }

    @Override
    public void onGpsState(SpeedTracker t) {
        updateGpsStatus();
    }

    private void updateGpsStatus() {
        String s;
        if (!hasLocationPermission()) s = "NO PERMISSION\ntap to allow";
        else if (!tracker.isGpsEnabled()) s = "GPS OFF\ntap to enable";
        else if (!tracker.hasFix()) s = "SEARCHING...";
        else if (tracker.getAccuracy() > 0) s = String.format(Locale.US, "GPS LOCK\n+/-%.0f m", tracker.getAccuracy());
        else s = "GPS LOCK";
        gpsStatus.setText(s);
        gpsStatus.setTextColor(tracker.hasFix() ? colors.accentText : colors.sub);
    }

    // =========================================================================================
    // rendering
    // =========================================================================================

    private void renderAll() {
        renderHero();
        refreshTab(true);
    }

    private void renderHero() {
        if (colors == null) return;
        double ms = tracker.getSpeedMs();
        float shown = (float) unit.fromMs(ms);
        int limit = prefs.getSpeedLimitKmh();
        boolean over = limit > 0 && ms * 3.6 > limit + 0.5;
        boolean warn = !over && limit > 0 && prefs.getWarn90() && ms * 3.6 > limit * 0.9;

        gauge.setUnit(unit);
        gauge.setSpeed(shown);
        gauge.setLimit(limit > 0 ? (float) unit.fromMs(limit / 3.6) : -1f);
        gauge.setPeak((float) unit.fromMs(tracker.getMaxMs()));
        gauge.setOver(over);
        gauge.setWarn(warn);

        speedText.setText(unit.format(ms));
        unitText.setText(unit.label);
        float frac = (float) (shown / unit.gaugeMax);
        int c = over ? colors.danger : (warn ? ThemeHelper.AMBER
                : (prefs.getHeat() && !colors.night ? ThemeHelper.heat(colors.accentText, frac) : colors.accentText));
        speedText.setTextColor(c);
        speedText.setShadowLayer(28f, 0, 0, ThemeHelper.alpha(c, colors.dark ? 190 : 0));

        fxSpace.setSpeedFrac((float) (ms / 50.0));
        fxOverlay.setAlert(over);

        long now = System.currentTimeMillis();
        if (over) {
            styleBanner(limitBanner, colors.danger, 0xFFFFFFFF);
            limitBanner.setText("SPEED LIMIT EXCEEDED  -  " + unit.format(limit / 3.6) + " " + unit.label);
            limitBanner.setVisibility(View.VISIBLE);
            if (!prevOver || now - lastOverAlert > 2500) {
                lastOverAlert = now;
                haptics.alert(prefs.getVibrate(), prefs.getSound(), false);
                if (!prevOver) say("over", "Speed limit exceeded", 20000);
            }
        } else if (warn) {
            styleBanner(limitBanner, ThemeHelper.AMBER, 0xFF000000);
            limitBanner.setText("APPROACHING LIMIT  -  " + unit.format(limit / 3.6) + " " + unit.label);
            limitBanner.setVisibility(View.VISIBLE);
            if (!prevWarn && prefs.getVibrate()) haptics.tick();
        } else {
            limitBanner.setVisibility(View.GONE);
        }
        prevOver = over;
        prevWarn = warn;
    }

    private void styleBanner(TextView t, int bg, int fg) {
        t.setBackground(ThemeHelper.rounded(bg, UiKit.dp(this, 14)));
        t.setTextColor(fg);
    }

    private final Runnable hideBanner = () -> obstacleBanner.setVisibility(View.GONE);

    private void showSafety(String msg, boolean strong) {
        styleBanner(obstacleBanner, strong ? colors.danger : ThemeHelper.AMBER, strong ? 0xFFFFFFFF : 0xFF000000);
        obstacleBanner.setText(msg);
        obstacleBanner.setVisibility(View.VISIBLE);
        handler.removeCallbacks(hideBanner);
        handler.postDelayed(hideBanner, 4500);
        if (strong) haptics.alert(prefs.getVibrate(), prefs.getSound(), true);
    }

    private void say(String key, String text, long gapMs) {
        if (prefs.getVoice() && voice != null) voice.speak(key, text, gapMs);
    }

    private static String spoken(Units u) {
        switch (u) {
            case KMH: return "kilometres per hour";
            case MPH: return "miles per hour";
            case KNOTS: return "knots";
            case MS: return "metres per second";
            default: return "miles per second";
        }
    }

    private static String fmtTime(long ms) {
        long s = ms / 1000;
        return s >= 3600 ? String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
                : String.format(Locale.US, "%02d:%02d", s / 60, s % 60);
    }

    /** full = also refresh slow tabs (map / system). */
    private void refreshTab(boolean full) {
        if (colors == null || tel1 == null) return;
        switch (tab) {
            case 0: refreshDash(full); break;
            case 1: refreshLab(); break;
            case 2: if (full) refreshMap(); break;
            default: if (full) refreshSys(); break;
        }
    }

    private void refreshDash(boolean full) {
        DriveAnalytics an = tracker.analytics;
        UiKit.labelOf(tel1[0]).setText("MAX \u00B7 " + unit.label);
        UiKit.labelOf(tel1[1]).setText("AVG \u00B7 " + unit.label);
        tel1[0].setText(unit.format(tracker.getMaxMs()));
        tel1[1].setText(unit.format(tracker.getAvgMs()));
        tel1[2].setText(unit.formatDistance(tracker.getDistanceM()));
        tel1[3].setText(fmtTime(tracker.getTotalMs()));
        UiKit.labelOf(tel2[1]).setText(unit.imperial() ? "CLIMB \u00B7 ft/s" : "CLIMB \u00B7 m/s");
        tel2[0].setText(Double.isNaN(an.altitude) ? "--" : unit.formatAlt(an.altitude));
        tel2[1].setText(String.format(Locale.US, "%+.1f", unit.imperial() ? an.vSpeed * 3.28084 : an.vSpeed));
        tel2[2].setText(String.format(Locale.US, "%+.1f", an.accel));
        float b = tracker.getBearing();
        tel2[3].setText(Float.isNaN(b) ? "--" : CompassView.cardinal(b) + " " + Math.round(b) + "\u00B0");
        compass.setHeading(b);

        // pathfinder
        WaypointStore.Wp wp = waypoints.active();
        Location l = tracker.getLastLocation();
        if (wp == null) {
            txtNav.setText("Pathfinder idle - drop a waypoint on the MAP tab");
            compass.setTarget(Float.NaN);
        } else if (l == null) {
            txtNav.setText("Pathfinder: waiting for GPS...");
            compass.setTarget(Float.NaN);
        } else {
            float[] r = new float[2];
            Location.distanceBetween(l.getLatitude(), l.getLongitude(), wp.lat, wp.lon, r);
            float brg = (r[1] + 360f) % 360f;
            compass.setTarget(brg);
            double spd = tracker.getSpeedMs() > 1.5 ? tracker.getSpeedMs() : tracker.getAvgMs();
            String eta = spd > 1.0 ? fmtTime((long) (r[0] / spd * 1000)) : "--";
            txtNav.setText("\u25B6 " + wp.name + "   " + unit.formatNear(r[0]) + "   " + Math.round(brg) + "\u00B0   ETA " + eta);
        }

        // pace keeper
        int target = prefs.getPaceKmh();
        cardPace.setVisibility(target > 0 ? View.VISIBLE : View.GONE);
        if (target > 0) {
            float delta = (float) (tracker.getSpeedMs() * 3.6 - target);
            paceBar.setDelta(delta);
            txtPace.setText(String.format(Locale.US, "PACE KEEPER  %s %s   \u0394 %+.1f",
                    unit.format(target / 3.6), unit.label, unit.fromMs(delta / 3.6)));
        }

        if (full) {
            float[] h = an.historySnapshot();
            float f = (float) unit.factor;
            for (int i = 0; i < h.length; i++) h[i] *= f;
            graphSpeed.setData(h, 0f, (float) unit.fromMs(5.5), "SPEED \u00B7 LAST 2 MIN \u00B7 " + unit.label);
        }
    }

    private void refreshLab() {
        PerfLab p = tracker.perf;
        DriveAnalytics an = tracker.analytics;
        String status;
        if (p.isRunning()) status = String.format(Locale.US, "RUN  %.2f s", p.liveSeconds());
        else if (p.isBraking()) status = String.format(Locale.US, "BRAKING  %.2f s", p.liveSeconds());
        else if (p.isReady()) status = "READY - launch when you are set";
        else status = "STANDBY - come to a full stop to arm";
        txtLabStatus.setText(status);
        for (int i = 0; i < 6; i++) {
            float last = p.last(i), best = p.best(i);
            labViews[i][1].setText(last > 0 ? String.format(Locale.US, "%.2f s", last) : "--");
            String bs = best > 0 ? String.format(Locale.US, "%.2f s", best) : "--";
            if (i == 5 && best > 0 && p.bestBrakeDist() > 0) bs += String.format(Locale.US, " / %.0f m", p.bestBrakeDist());
            labViews[i][2].setText(bs);
        }
        gforce.setG(an.gLat, an.gLong);
        txtGpeaks.setText(String.format(Locale.US,
                "LONG  %+.2f g\nLAT   %+.2f g\n\nPEAK ACC  %.2f g\nPEAK BRK  %.2f g\nPEAK LAT  %.2f g",
                an.gLong, an.gLat, an.peakAccelG, an.peakBrakeG, an.peakLatG));

        double dist = tracker.getDistanceM();
        int eco = an.ecoScore(dist, tracker.getMovingMs());
        ins1[0].setText(eco < 0 ? "--" : eco + "/100");
        ins1[0].setTextColor(eco < 0 ? colors.text : (eco >= 80 ? colors.accentText : (eco >= 60 ? ThemeHelper.AMBER : colors.danger)));
        ins1[1].setText(String.valueOf(an.harshAccel));
        ins1[2].setText(String.valueOf(an.harshBrake));
        ins1[3].setText(String.valueOf(an.harshCorner));
        ins2[0].setText(fmtTime(tracker.getMovingMs()));
        ins2[1].setText(fmtTime(an.stoppedMs));
        ins2[2].setText(String.valueOf(an.stops));
        ins2[3].setText(fmtTime(an.overLimitMs));
        ins3[0].setText(unit.formatAlt(an.ascent));
        ins3[1].setText(unit.formatAlt(an.descent));
        float l100 = prefs.getFuelL100();
        if (l100 > 0) {
            double fuel = dist / 1000.0 * l100 / 100.0;
            ins3[2].setText(unit.imperial() ? String.format(Locale.US, "%.2f gal", fuel * 0.264172)
                    : String.format(Locale.US, "%.2f L", fuel));
            ins3[3].setText(prefs.getFuelPrice() > 0
                    ? String.format(Locale.US, "%s%.2f", prefs.getCurrency(), fuel * prefs.getFuelPrice()) : "--");
            txtCo2.setText(String.format(Locale.US, "CO\u2082 \u2248 %.2f kg  (%.1f L/100 km assumed; set your car in Settings)",
                    fuel * 2.31, l100));
        } else {
            ins3[2].setText("--");
            ins3[3].setText("--");
            txtCo2.setText("Add your car's fuel use in Settings to see fuel, cost and CO\u2082.");
        }
    }

    private void refreshMap() {
        routeLive.setRoute(tracker.analytics.route(), waypoints.all(), true);
        txtMapInfo.setText(String.format(Locale.US, "%d route points  \u00B7  %d waypoints  \u00B7  %d hazards   (cyan = slow, red = fast)",
                tracker.analytics.route().size(), waypoints.count(0), waypoints.count(1)));
    }

    private void refreshSys() {
        DateFormat tf = android.text.format.DateFormat.getTimeFormat(this);
        Location l = tracker.getLastLocation();
        if (l == null) {
            txtSun.setText("SUN  waiting for GPS...");
        } else {
            long[] st = SunCalc.sunTimes(l.getLatitude(), l.getLongitude(), System.currentTimeMillis());
            if (st == null) {
                txtSun.setText("SUN  polar day / night at this latitude");
            } else {
                long now = System.currentTimeMillis();
                String next;
                if (now < st[0]) next = "sunrise in " + fmtTime(st[0] - now);
                else if (now < st[1]) next = "sunset in " + fmtTime(st[1] - now);
                else next = "night";
                txtSun.setText("SUN  rise " + tf.format(new Date(st[0])) + "  \u00B7  set "
                        + tf.format(new Date(st[1])) + "  \u00B7  " + next);
            }
        }
        txtSats.setText(String.format(Locale.US, "SATELLITES  %d in fix / %d visible", tracker.satsUsed, tracker.satsVisible));
        satView.setData(tracker.cn0, tracker.cn0Count);
        double life = prefs.getLifetimeM() + tracker.getDistanceM();
        double top = Math.max(prefs.getTopMs(), tracker.getMaxMs());
        txtLife.setText("ODOMETER " + unit.formatDistance(life) + "   \u00B7   ALL-TIME TOP " + unit.format(top) + " " + unit.label
                + (battPct >= 0 ? "   \u00B7   BATTERY " + battPct + "%" + (charging ? " (charging)" : "") : ""));
    }

    // =========================================================================================
    // 1 Hz ticker + events
    // =========================================================================================

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            tickCount++;
            tracker.tick();
            if (tickCount % 15 == 1) readBattery();
            breakCheck();
            checkCrashWatch();
            refreshTab(true);
            updateGpsStatus();
            handler.postDelayed(this, 1000);
        }
    };

    private void readBattery() {
        Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (b == null) return;
        int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int status = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        battPct = level < 0 ? -1 : Math.round(level * 100f / scale);
        charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL;
        batteryText.setText(battPct < 0 ? "" : "BAT " + battPct + "%" + (charging ? " \u26A1" : ""));
        batteryText.setTextColor(battPct >= 0 && battPct <= 15 && !charging ? colors.danger : colors.sub);
        if (battPct >= 0 && battPct <= 15 && !charging && !lowBattWarned) {
            lowBattWarned = true;
            showSafety("Battery low (" + battPct + "%) - plug in to keep tracking", false);
            say("batt", "Battery low", 600000);
        } else if (charging || battPct > 25) {
            lowBattWarned = false;
        }
    }

    private void breakCheck() {
        int h = prefs.getBreakHours();
        if (h <= 0) return;
        if (tracker.getMovingMs() >= (long) (breakCount + 1) * h * 3600000L) {
            breakCount++;
            showSafety("You have been driving for " + breakCount * h + " h - take a break", true);
            say("break", "You have been driving for " + breakCount * h + " hours. Please take a break.", 60000);
        }
    }

    private void processEvents() {
        // performance lab results
        String ev = tracker.perf.consumeEvent();
        if (ev != null) {
            Toast.makeText(this, ev, Toast.LENGTH_LONG).show();
            say("perf", ev.replace("/", " to ").replace("NEW BEST", "new personal best"), 3000);
        }

        double ms = tracker.getSpeedMs();
        Location l = tracker.getLastLocation();

        // distance milestones
        double u = unit.imperial() ? 1609.344 : 1000.0;
        int k = (int) (tracker.getDistanceM() / u);
        if (k < announcedK) announcedK = k;
        else if (k > announcedK) {
            announcedK = k;
            if (prefs.getVoiceKm()) {
                say("km", k + (unit.imperial() ? " miles" : " kilometres") + " travelled. Average speed "
                        + unit.format(tracker.getAvgMs()) + " " + spoken(unit), 1000);
            }
        }

        // all-time top speed
        float top = prefs.getTopMs();
        if (tracker.getMaxMs() > top + 0.3 && tracker.getMaxMs() * 3.6 >= 30) {
            prefs.setTopMs((float) tracker.getMaxMs());
            if (top > 0) say("record", "New top speed record. " + unit.format(tracker.getMaxMs()) + " " + spoken(unit), 30000);
        }

        if (l != null) {
            long now = System.currentTimeMillis();
            // hazard proximity: lead time of about 15 s at the current speed
            if (ms > 1.0) {
                for (WaypointStore.Wp w : waypoints.all()) {
                    if (w.type != 1) continue;
                    float[] r = new float[1];
                    Location.distanceBetween(l.getLatitude(), l.getLongitude(), w.lat, w.lon, r);
                    double radius = Math.max(200.0, ms * 15.0);
                    Long last = hazardAlerted.get(w.id);
                    if (r[0] < radius && (last == null || now - last > 60000)) {
                        hazardAlerted.put(w.id, now);
                        showSafety("Hazard ahead: " + w.name + " - " + unit.formatNear(r[0]), true);
                        say("hz" + w.id, "Caution. " + w.name + " ahead", 60000);
                    }
                }
            }
            // arrival at active waypoint
            WaypointStore.Wp wp = waypoints.active();
            if (wp != null) {
                float[] r = new float[1];
                Location.distanceBetween(l.getLatitude(), l.getLongitude(), wp.lat, wp.lon, r);
                if (r[0] < 30 && !arrived) {
                    arrived = true;
                    showSafety("Arrived: " + wp.name, false);
                    say("arrive", "You have arrived at " + wp.name, 30000);
                } else if (r[0] > 120) {
                    arrived = false;
                }
            }
        }

        // pace keeper haptic nudge
        int target = prefs.getPaceKmh();
        if (target > 0 && ms > 2.0 && prefs.getVibrate()) {
            double delta = Math.abs(ms * 3.6 - target);
            long now = System.currentTimeMillis();
            if (delta > 8) {
                if (paceOffSince == 0) paceOffSince = now;
                if (now - paceOffSince > 3000 && now - lastPaceNudge > 5000) {
                    lastPaceNudge = now;
                    haptics.tick();
                }
            } else {
                paceOffSince = 0;
            }
        }
        checkCrashWatch();
    }

    // =========================================================================================
    // obstacle sensors + crash detection / SOS
    // =========================================================================================

    @Override
    public void onProximity(boolean near) {
        if (near) showSafety("Object very close to the phone", true);
    }

    @Override
    public void onImpact(float g) {
        showSafety(String.format(Locale.US, "Impact detected: %.1f g", g), true);
    }

    @Override
    public void onCrashSpike(float g) {
        double pre = tracker.getRecentMaxSpeedMs(4000);
        if (pre < 8.3 || crashWatch) return;
        crashWatch = true;
        crashWatchStart = System.currentTimeMillis();
        crashPreSpeed = pre;
        showSafety(String.format(Locale.US, "Severe impact %.1f g - checking...", g), true);
    }

    private void checkCrashWatch() {
        if (!crashWatch) return;
        long dt = System.currentTimeMillis() - crashWatchStart;
        if (dt < 1500) return;
        if (tracker.getSpeedMs() < crashPreSpeed * 0.35 || !tracker.hasFix()) {
            crashWatch = false;
            startCrashCountdown();
        } else if (dt > 8000) {
            crashWatch = false;
        }
    }

    private void startCrashCountdown() {
        if (sosDialog != null && sosDialog.isShowing()) return;
        sosDialog = new AlertDialog.Builder(this)
                .setTitle("Crash detected")
                .setMessage("Sending SOS in 30 s")
                .setCancelable(false)
                .setPositiveButton("SEND NOW", (d, w) -> { cancelSosTimer(); sendSos(); })
                .setNegativeButton("I'M OK", (d, w) -> cancelSosTimer())
                .create();
        sosDialog.show();
        say("crash", "Crash detected. Sending an SOS in thirty seconds. Tap I'm OK to cancel.", 1000);
        sosTimer = new CountDownTimer(30000, 1000) {
            @Override public void onTick(long left) {
                if (sosDialog != null) sosDialog.setMessage("Sending SOS in " + (left / 1000) + " s.\nTap I'M OK to cancel.");
                haptics.alert(true, true, true);
            }
            @Override public void onFinish() {
                if (sosDialog != null && sosDialog.isShowing()) sosDialog.dismiss();
                sendSos();
            }
        }.start();
    }

    private void cancelSosTimer() {
        if (sosTimer != null) { sosTimer.cancel(); sosTimer = null; }
    }

    private void confirmSos() {
        new AlertDialog.Builder(this)
                .setTitle("Send SOS?")
                .setMessage("Opens your messaging app with your GPS location, ready to send.")
                .setPositiveButton("Send", (d, w) -> sendSos())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void sendSos() {
        Location l = tracker.getLastLocation();
        String msg = "SOS! I may need help. "
                + (l != null ? "My location: https://maps.google.com/?q=" + l.getLatitude() + "," + l.getLongitude()
                : "My GPS location is not available.") + " (sent from VeusSpeed)";
        String num = prefs.getSosNumber();
        try {
            if (!num.isEmpty()) {
                Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(num)));
                i.putExtra("sms_body", msg);
                startActivity(i);
            } else {
                ShareUtil.shareText(this, "SOS", msg);
            }
        } catch (Exception e) {
            ShareUtil.shareText(this, "SOS", msg);
        }
    }

    // =========================================================================================
    // trips + waypoints
    // =========================================================================================

    private void endTrip() {
        double dist = tracker.getDistanceM();
        if (dist >= 100) {
            TripStore.Trip t = tracker.buildTrip();
            trips.insert(t, new ArrayList<>(tracker.analytics.route()));
            prefs.addLifetimeM(t.distM);
            if (t.maxMs > prefs.getTopMs()) prefs.setTopMs(t.maxMs);
            Toast.makeText(this, "Trip saved - " + unit.formatDistance(t.distM), Toast.LENGTH_SHORT).show();
            List<Achievements.Badge> badges = Achievements.evaluate(prefs, trips.aggregate(), waypoints);
            for (String n : Achievements.newlyUnlocked(prefs, badges)) {
                Toast.makeText(this, "Achievement unlocked: " + n, Toast.LENGTH_LONG).show();
                say("ach", "Achievement unlocked. " + n, 2000);
            }
        } else {
            Toast.makeText(this, "Trip reset (under 100 m, not saved)", Toast.LENGTH_SHORT).show();
        }
        tracker.reset();
        announcedK = 0;
        breakCount = 0;
        gforce.clear();
        renderAll();
    }

    private void markHere(int type) {
        Location l = tracker.getLastLocation();
        if (l == null) {
            Toast.makeText(this, "No GPS fix yet", Toast.LENGTH_SHORT).show();
            return;
        }
        final double lat = l.getLatitude(), lon = l.getLongitude();
        final EditText e = new EditText(this);
        e.setText((type == 1 ? "Hazard " : "Point ") + (waypoints.count(type) + 1));
        e.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this)
                .setTitle(type == 1 ? "Mark hazard / speed trap" : "Mark waypoint here")
                .setView(e)
                .setPositiveButton("Save", (d, w) -> {
                    String n = e.getText().toString().trim();
                    if (n.isEmpty()) n = type == 1 ? "Hazard" : "Point";
                    WaypointStore.Wp wp = waypoints.add(n, lat, lon, type);
                    Toast.makeText(this, wp == null ? "Pin limit reached (delete some first)" : "Saved: " + n,
                            Toast.LENGTH_SHORT).show();
                    refreshTab(true);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showPoints() {
        final List<WaypointStore.Wp> all = new ArrayList<>(waypoints.all());
        if (all.isEmpty()) {
            Toast.makeText(this, "No pins yet - use MARK HERE or HAZARD", Toast.LENGTH_SHORT).show();
            return;
        }
        Location l = tracker.getLastLocation();
        WaypointStore.Wp active = waypoints.active();
        String[] items = new String[all.size()];
        for (int i = 0; i < items.length; i++) {
            WaypointStore.Wp w = all.get(i);
            String dist = "";
            if (l != null) {
                float[] r = new float[1];
                Location.distanceBetween(l.getLatitude(), l.getLongitude(), w.lat, w.lon, r);
                dist = "  (" + unit.formatNear(r[0]) + ")";
            }
            items[i] = (w.type == 1 ? "\u26A0 " : (active != null && active.id == w.id ? "\u25B6 " : "\u25C6 ")) + w.name + dist;
        }
        new AlertDialog.Builder(this)
                .setTitle("Waypoints & hazards")
                .setItems(items, (d, i) -> pointActions(all.get(i)))
                .setNegativeButton("Close", null)
                .show();
    }

    private void pointActions(final WaypointStore.Wp w) {
        final boolean nav = w.type == 0;
        String[] a = nav ? new String[]{"Navigate here", "Delete"} : new String[]{"Delete"};
        new AlertDialog.Builder(this)
                .setTitle(w.name)
                .setItems(a, (d, i) -> {
                    if (nav && i == 0) {
                        waypoints.setActive(w.id);
                        arrived = false;
                    } else {
                        waypoints.remove(w.id);
                    }
                    refreshTab(true);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
