# VeusSpeed 2.0 - Futuristic GPS Speedometer

100% offline (no Play Services, no accounts, no network). Java + XML, minSdk 24, same package `com.veus.speedpro`.
Build exactly as before: `setup.bat` / `clean_build.bat`, or open in Android Studio.
No new Gradle dependencies were added.

## What's new - 55 features

### Futuristic look & feel
1. Warp-speed starfield + synthwave floor grid that accelerates with your real speed
2. Neon-glow gradient sweep gauge
3. New "Reactor ring" segmented LED gauge (default)
4. Spring-physics needle with a touch of overshoot
5. Peak-speed ghost marker on the gauge
6. Speed-reactive heat colour (accent -> amber -> red)
7. Pulsing red edge vignette while over the limit
8. Holographic scanline overlay
9. Glass-neon cards with glowing edges
10. Condensed digital typography with glowing numerals
11. Cinematic "SYSTEM ONLINE" boot sequence (tap to skip)
12. Redesigned neon launcher icon
13. Five new palettes (Aurora, Cyberpunk, Ice, Plasma, Gold) = 13 + custom hue
14. Stealth OLED pure-black theme
15. Night-vision red-only HUD (manual or automatic via ambient light sensor)
16. Cockpit immersive mode (long-press the gauge)
17. Tap the gauge to cycle Reactor / Analog / Digital / HUD
18. Picture-in-picture floating speedometer when you leave the app
19. Dedicated landscape cockpit layout

### Instruments
20. Scrolling compass ribbon (heading + cardinal)
21. Altitude + vertical speed
22. Live G-force ball (longitudinal + lateral, derived from GPS)
23. Peak acceleration / braking / cornering g records
24. Live 2-minute speed graph
25. GNSS panel: satellites in fix / visible + per-satellite signal bars
26. Battery level with low-battery warning
27. Offline sunrise / sunset times with countdown
28. Moving vs stopped time + stop counter
29. Time spent over the speed limit
30. Total ascent / descent

### Performance lab
31. 0-60 km/h, 0-100 km/h, 0-60 mph timers (auto-arm at standstill)
32. 100 m and 1/4-mile sprint timers
33. 100-0 km/h braking test (time + distance)
34. Personal bests saved permanently

### Trips & data
35. Automatic trip log (SQLite) - END & SAVE TRIP
36. Trip list with summaries
37. Trip detail: speed-coloured route map (no map tiles, fully offline)
38. Trip detail: speed + elevation graphs
39. GPX export
40. Share trip summary
41. 7-day distance chart
42. Lifetime odometer + all-time top speed
43. Eco / smooth-driving score + harsh accel / brake / corner counters
44. Fuel, cost and CO2 estimator (set L/100 km and price in Settings)
45. 11 achievements / badges
46. CSV export of all trips

### Navigation
47. Waypoints: "Mark here" (up to 40 pins)
48. Pathfinder: distance, bearing, ETA to the active waypoint + marker on the compass ribbon
49. Hazard / speed-trap pins with proximity alerts (about 15 s lead time at your speed)

### Safety & alerts
50. Tiered alerts: amber warning at 90% of the limit, red at the limit
51. Offline voice announcements (limit, km milestones, records, hazards, arrival, perf runs)
52. Break reminder every N hours of driving
53. Crash detection with 30 s SOS countdown -> pre-filled SMS with GPS link
54. One-tap SOS button (share location)
55. Pace keeper: target speed with delta bar and gentle haptic nudges

### Also added
GPS update rate (1/2/4 Hz), smoothing levels, speed calibration (+/-10%), battery saver, orientation lock.

## Honest notes / limitations
- Written without an Android SDK available, so it has been syntax-checked and its resource IDs cross-checked, but
  **not compiled or run on a device**. Do a `clean_build.bat` and expect to fix a few small compile errors if any appear.
- Tracking stops when the app is fully backgrounded (as in v1). Picture-in-picture keeps it alive while floating.
  A foreground-service "background trip recording" mode would be the natural next step.
- Crash SOS opens a pre-filled SMS; Android requires you (or the countdown, only while the app is on screen) to launch it.
  Android 10+ blocks launching it from the background. Treat it as an aid, not a certified safety device.
- G-force, performance timers and eco score are GPS-derived: good, but roughly +/-0.1-0.2 s / +/-0.05 g.
- Camera obstacle mode is unchanged: a warning aid, not distance measurement.
