package com.veus.speedpro;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

/**
 * Edge-to-edge helper. Android 15+ forces apps that target API 35+ to draw behind the status bar,
 * navigation bar and display cutout (and ignores setStatusBarColor / setNavigationBarColor).
 * Backgrounds (starfield, themes) now bleed under the bars; content is padded so nothing is covered.
 */
public final class Edge {
    private Edge() {}

    /** Call before setContentView. Safe on every API level. */
    @SuppressWarnings("deprecation")
    public static void enable(Activity a) {
        Window w = a.getWindow();
        WindowCompat.setDecorFitsSystemWindows(w, false);
        if (Build.VERSION.SDK_INT < 35) {
            w.setStatusBarColor(Color.TRANSPARENT);
            w.setNavigationBarColor(Color.TRANSPARENT);
        }
        if (Build.VERSION.SDK_INT >= 29) w.setNavigationBarContrastEnforced(false);
    }

    /** Dark icons on light themes, light icons on dark themes. */
    public static void bars(Activity a, boolean darkTheme) {
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(a.getWindow(), a.getWindow().getDecorView());
        c.setAppearanceLightStatusBars(!darkTheme);
        c.setAppearanceLightNavigationBars(!darkTheme);
    }

    /** Adds system-bar, cutout and keyboard insets to the view's own padding (keeps the XML padding). */
    public static void pad(View v) {
        final int l = v.getPaddingLeft(), t = v.getPaddingTop(), r = v.getPaddingRight(), b = v.getPaddingBottom();
        if (v instanceof ViewGroup) ((ViewGroup) v).setClipToPadding(false);
        ViewCompat.setOnApplyWindowInsetsListener(v, (view, insets) -> {
            Insets i = insets.getInsets(WindowInsetsCompat.Type.systemBars()
                    | WindowInsetsCompat.Type.displayCutout() | WindowInsetsCompat.Type.ime());
            view.setPadding(l + i.left, t + i.top, r + i.right, b + i.bottom);
            return WindowInsetsCompat.CONSUMED;
        });
        ViewCompat.requestApplyInsets(v);
    }
}
