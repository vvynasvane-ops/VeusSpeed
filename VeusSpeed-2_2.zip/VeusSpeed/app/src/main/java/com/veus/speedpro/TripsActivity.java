package com.veus.speedpro;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Trip log: lifetime stats, 7-day chart, achievements and the list of saved trips. */
public class TripsActivity extends AppCompatActivity {

    private Prefs prefs;
    private TripStore trips;
    private WaypointStore waypoints;
    private View root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        SpeedApp app = (SpeedApp) getApplication();
        trips = app.getTrips();
        waypoints = app.getWaypoints();
        Edge.enable(this);
        setContentView(R.layout.activity_trips);
        root = findViewById(R.id.root);
        Edge.pad(root);
        findViewById(R.id.btnDone).setOnClickListener(v -> finish());
    }

    @Override
    protected void onResume() {
        super.onResume();
        populate();
    }

    private void populate() {
        Units unit = prefs.getUnit();
        ThemeHelper.Colors colors = ThemeHelper.resolve(this, prefs, false);
        Edge.bars(this, colors.dark);
        TripStore.Aggregate a = trips.aggregate();

        // lifetime
        LinearLayout life = findViewById(R.id.cardLife);
        life.removeAllViews();
        TextView t = UiKit.label(this, life, "LIFETIME", "accent", 13);
        t.setLetterSpacing(0.15f);
        t.setTypeface(android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD));
        TextView[] r1 = UiKit.statRow(this, life, "ODOMETER", "TRIPS", "TOP SPEED");
        double life_m = prefs.getLifetimeM();
        r1[0].setText(unit.formatDistance(life_m));
        r1[1].setText(String.valueOf(a.count));
        r1[2].setText(unit.format(Math.max(prefs.getTopMs(), a.maxSpeed)) + " " + unit.label);

        // week chart
        BarChartView chart = findViewById(R.id.weekChart);
        double[] vals = new double[7];
        String[] labels = new String[7];
        SimpleDateFormat df = new SimpleDateFormat("EEE", Locale.getDefault());
        double div = unit.imperial() ? 1609.344 : 1000.0;
        for (int i = 0; i < 7; i++) {
            vals[i] = a.week[i] / div;
            String d = df.format(new Date(a.weekDayStart[i]));
            labels[i] = d.length() > 3 ? d.substring(0, 3) : d;
        }
        chart.setData(vals, labels, unit.imperial() ? "mi" : "km");
        chart.setPalette(colors.accent, colors.track, colors.text, colors.sub, colors.danger);

        // badges
        LinearLayout badges = findViewById(R.id.cardBadges);
        badges.removeAllViews();
        List<Achievements.Badge> list = Achievements.evaluate(prefs, a, waypoints);
        Achievements.newlyUnlocked(prefs, list);
        int got = 0;
        for (Achievements.Badge b : list) if (b.unlocked) got++;
        TextView bt = UiKit.label(this, badges, "ACHIEVEMENTS  " + got + "/" + list.size(), "accent", 13);
        bt.setLetterSpacing(0.15f);
        bt.setTypeface(android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD));
        for (Achievements.Badge b : list) {
            TextView row = UiKit.label(this, badges, (b.unlocked ? "\u25CF  " : "\u25CB  ") + b.name + "  -  " + b.desc,
                    b.unlocked ? "title" : "sub", 13);
            row.setAlpha(b.unlocked ? 1f : 0.7f);
        }

        // trips
        LinearLayout box = findViewById(R.id.cardTrips);
        box.removeAllViews();
        TextView tt = UiKit.label(this, box, "SAVED TRIPS", "accent", 13);
        tt.setLetterSpacing(0.15f);
        tt.setTypeface(android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD));
        List<TripStore.Trip> all = trips.list(200);
        if (all.isEmpty()) {
            UiKit.label(this, box, "No trips yet. Drive, then press END & SAVE TRIP on the main screen.", "sub", 13);
        }
        SimpleDateFormat f = new SimpleDateFormat("EEE d MMM, HH:mm", Locale.getDefault());
        for (final TripStore.Trip trip : all) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(0, UiKit.dp(this, 10), 0, UiKit.dp(this, 10));
            row.setClickable(true);
            row.setOnClickListener(v -> {
                Intent i = new Intent(this, TripDetailActivity.class);
                i.putExtra("id", trip.id);
                startActivity(i);
            });
            box.addView(row);
            TextView l1 = new TextView(this);
            l1.setTag("title");
            l1.setTextSize(15);
            l1.setTypeface(android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD));
            l1.setText(f.format(new Date(trip.startMs)) + "   " + unit.formatDistance(trip.distM));
            row.addView(l1);
            TextView l2 = new TextView(this);
            l2.setTag("sub");
            l2.setTextSize(12);
            long s = trip.durMs / 1000;
            l2.setText(String.format(Locale.US, "%d:%02d:%02d  |  top %s %s  |  avg %s%s", s / 3600, (s % 3600) / 60, s % 60,
                    unit.format(trip.maxMs), unit.label, unit.format(trip.avgMs),
                    trip.eco >= 0 ? "  |  eco " + trip.eco : ""));
            row.addView(l2);
        }

        LinearLayout actions = findViewById(R.id.cardActions);
        actions.removeAllViews();
        UiKit.button(this, actions, "EXPORT ALL TRIPS (CSV)", "ghost", () -> {
            try {
                java.io.File file = ShareUtil.writeCsv(this, "veusspeed_trips.csv", trips.csvAll());
                ShareUtil.shareFile(this, file, "text/csv", "VeusSpeed trips");
            } catch (Exception e) {
                Toast.makeText(this, "Export failed", Toast.LENGTH_SHORT).show();
            }
        });

        ThemeHelper.apply(root, colors);
    }
}
