package com.veus.speedpro;

import android.content.Context;
import android.content.SharedPreferences;

/** Thin wrapper over SharedPreferences. All settings persist offline. */
public final class Prefs {
    private final SharedPreferences sp;

    public Prefs(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("veusspeed_prefs", Context.MODE_PRIVATE);
    }

    // ---- generic accessors ------------------------------------------------------------------
    public boolean bool(String k, boolean d) { return sp.getBoolean(k, d); }
    public void setBool(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }
    public int num(String k, int d) { return sp.getInt(k, d); }
    public void setNum(String k, int v) { sp.edit().putInt(k, v).apply(); }
    public float flt(String k, float d) { return sp.getFloat(k, d); }
    public void setFlt(String k, float v) { sp.edit().putFloat(k, v).apply(); }
    public String str(String k, String d) { return sp.getString(k, d); }
    public void setStr(String k, String v) { sp.edit().putString(k, v).apply(); }
    public void remove(String k) { sp.edit().remove(k).apply(); }

    // ---- core (v1) --------------------------------------------------------------------------
    public Units getUnit() { return Units.fromName(sp.getString("unit", "KMH"), Units.KMH); }
    public void setUnit(Units u) { sp.edit().putString("unit", u.name()).apply(); }

    /** 0 = system, 1 = light, 2 = dark */
    public int getThemeMode() { return num("theme_mode", 0); }
    public void setThemeMode(int v) { setNum("theme_mode", v); }

    /** index into ThemeHelper.PALETTES; index == PALETTES.length means custom hue */
    public int getPalette() { return num("palette", 0); }
    public void setPalette(int v) { setNum("palette", v); }

    /** One-time palette list migration ("Material You" was inserted before the custom-hue slot). */
    public void migratePalette() {
        if (num("palette_ver", 1) >= 2) return;
        if (getPalette() == ThemeHelper.PALETTES.length - 1) setPalette(ThemeHelper.PALETTES.length);
        setNum("palette_ver", 2);
    }

    public int getCustomHue() { return num("custom_hue", 200); }
    public void setCustomHue(int v) { setNum("custom_hue", v); }

    /** 0 = digital, 1 = analog gauge, 2 = HUD (mirrored digital), 3 = reactor ring */
    public int getGaugeStyle() { return num("gauge_style", 3); }
    public void setGaugeStyle(int v) { setNum("gauge_style", v); }

    public boolean getKeepScreenOn() { return bool("keep_on", true); }
    public void setKeepScreenOn(boolean v) { setBool("keep_on", v); }

    /** Speed limit in km/h; 0 = off */
    public int getSpeedLimitKmh() { return num("limit_kmh", 0); }
    public void setSpeedLimitKmh(int v) { setNum("limit_kmh", v); }

    public boolean getVibrate() { return bool("vibrate", true); }
    public boolean getSound() { return bool("sound", true); }
    public boolean getProximity() { return bool("proximity", true); }
    public boolean getImpact() { return bool("impact", true); }
    /** 0 = low, 1 = medium, 2 = high */
    public int getImpactSens() { return num("impact_sens", 1); }
    public boolean getCameraMode() { return bool("camera_mode", false); }
    public void setCameraMode(boolean v) { setBool("camera_mode", v); }

    // ---- v2 ---------------------------------------------------------------------------------
    public boolean getStealth() { return bool("stealth", false); }
    public boolean getFxSpace() { return bool("fx_space", true) && !getBatterySaver(); }
    public boolean getFxScan() { return bool("fx_scan", true) && !getBatterySaver(); }
    public boolean getHeat() { return bool("fx_heat", true); }
    public boolean getBoot() { return bool("boot_anim", true); }
    /** 0 = off, 1 = auto (ambient light), 2 = always on */
    public int getNightMode() { return num("night_mode", 1); }
    /** 0 = auto, 1 = portrait, 2 = landscape */
    public int getOrientation() { return num("orient", 0); }
    public boolean getWarn90() { return bool("warn90", true); }
    public boolean getVoice() { return bool("voice", false); }
    public boolean getVoiceKm() { return bool("voice_km", true); }
    public int getBreakHours() { return num("break_h", 0); }
    public int getPaceKmh() { return num("pace_kmh", 0); }
    /** 0 = raw, 1 = balanced, 2 = smooth */
    public int getSmoothing() { return num("smooth", 1); }
    /** 0 = fast 250 ms, 1 = normal 500 ms, 2 = eco 1000 ms */
    public int getGpsRate() { return num("gps_rate", 1); }
    public int getCalibPct() { return num("calib_pct", 0); }
    public boolean getBatterySaver() { return bool("battery_saver", false); }
    public float getFuelL100() { return flt("fuel_l100", 0f); }
    public float getFuelPrice() { return flt("fuel_price", 0f); }
    public String getCurrency() { return str("currency", "$"); }
    public boolean getCrash() { return bool("crash", true); }
    public String getSosNumber() { return str("sos_number", ""); }
    /** Pit Crew: live trip notification + milestone alerts while the app is in the background. */
    public boolean getBgNotif() { return bool("bg_notif", true); }
    public boolean getPip() { return bool("pip", true); }
    public int getTab() { return num("tab", 0); }
    public void setTab(int v) { setNum("tab", v); }

    // ---- lifetime stats -----------------------------------------------------------------------
    public double getLifetimeM() {
        try { return Double.parseDouble(str("life_m", "0")); } catch (NumberFormatException e) { return 0; }
    }
    public void addLifetimeM(double m) { setStr("life_m", String.valueOf(getLifetimeM() + m)); }
    public float getTopMs() { return flt("top_ms", 0f); }
    public void setTopMs(float v) { setFlt("top_ms", v); }
}
