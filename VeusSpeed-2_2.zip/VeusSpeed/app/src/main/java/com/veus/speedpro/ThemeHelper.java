package com.veus.speedpro;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.graphics.ColorUtils;

/**
 * Central theme engine. Views opt in through android:tag:
 * bg, card, title, sub, accent, btn, ghost, danger, icon, input.
 */
public final class ThemeHelper {

    public static final class Palette {
        public final String name;
        public final int color;
        Palette(String name, int color) { this.name = name; this.color = color; }
    }

    public static final Palette[] PALETTES = new Palette[]{
            new Palette("Neon Cyan", 0xFF00E5FF),
            new Palette("Sport Red", 0xFFFF3D3D),
            new Palette("Classic Amber", 0xFFFFB300),
            new Palette("Matrix Green", 0xFF00E676),
            new Palette("Royal Violet", 0xFFB388FF),
            new Palette("Sunset Orange", 0xFFFF7A1A),
            new Palette("Hot Pink", 0xFFFF4081),
            new Palette("Ocean Blue", 0xFF4D8DFF),
            new Palette("Aurora", 0xFF1DE9B6),
            new Palette("Cyberpunk", 0xFFFF2BD6),
            new Palette("Ice", 0xFFB9F2FF),
            new Palette("Plasma", 0xFF7C4DFF),
            new Palette("Gold", 0xFFFFD740),
            new Palette("Material You", 0xFFB388FF)   // wallpaper-derived on Android 12+
    };

    public static final int AMBER = 0xFFFFB300;

    public static final class Colors {
        public int bg, card, text, sub, track, accent, accentText, onAccent, danger, edge;
        public boolean dark, night;
    }

    private ThemeHelper() {}

    public static void applyNightMode(int mode) {
        switch (mode) {
            case 1: AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO); break;
            case 2: AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES); break;
            default: AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
        }
    }

    /** Swatch / accent colour for palette i. "Material You" follows the wallpaper accent on Android 12+. */
    public static int paletteColor(Context ctx, int i, boolean dark) {
        if (Build.VERSION.SDK_INT >= 31 && "Material You".equals(PALETTES[i].name)) {
            try { return ctx.getColor(dark ? android.R.color.system_accent1_300 : android.R.color.system_accent1_600); }
            catch (RuntimeException ignored) { }
        }
        return PALETTES[i].color;
    }

    public static int customColor(int hue) {
        return Color.HSVToColor(new float[]{hue % 360, 0.85f, 1f});
    }

    /** accent -> amber -> red as the needle climbs (frac 0..1). */
    public static int heat(int accent, float frac) {
        if (frac <= 0.6f) return accent;
        if (frac <= 0.85f) return ColorUtils.blendARGB(accent, AMBER, (frac - 0.6f) / 0.25f);
        return ColorUtils.blendARGB(AMBER, 0xFFFF1744, Math.min(1f, (frac - 0.85f) / 0.15f));
    }

    public static Colors resolve(Context ctx, Prefs prefs, boolean nightVision) {
        Colors c = new Colors();
        int ui = ctx.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        c.dark = ui == Configuration.UI_MODE_NIGHT_YES;
        c.night = nightVision;
        c.danger = 0xFFFF3B47;
        if (nightVision) {
            c.dark = true;
            c.bg = 0xFF000000; c.card = 0xFF130505; c.text = 0xFFFF5A5A;
            c.sub = 0xFF9A3030; c.track = 0xFF2B0A0A;
            c.accent = 0xFFFF2A2A; c.accentText = 0xFFFF4D4D; c.onAccent = 0xFF000000;
            c.edge = alpha(c.accent, 0x55);
            return c;
        }
        if (c.dark) {
            if (prefs.getStealth()) {
                c.bg = 0xFF000000; c.card = 0xFF0A0C10; c.track = 0xFF1A2029;
            } else {
                c.bg = 0xFF05070D; c.card = 0xFF0B111C; c.track = 0xFF1B2636;
            }
            c.text = 0xFFEAF4FF; c.sub = 0xFF7F93AB;
        } else {
            c.bg = 0xFFEAF2FA; c.card = 0xFFFFFFFF; c.text = 0xFF0E151D;
            c.sub = 0xFF566879; c.track = 0xFFD2DDE8;
        }
        int idx = prefs.getPalette();
        c.accent = (idx >= 0 && idx < PALETTES.length) ? paletteColor(ctx, idx, c.dark) : customColor(prefs.getCustomHue());
        if (c.dark) {
            c.accentText = c.accent;
        } else {
            float[] hsv = new float[3];
            Color.colorToHSV(c.accent, hsv);
            hsv[2] = hsv[2] * 0.70f;
            c.accentText = Color.HSVToColor(hsv);
        }
        double lum = (0.299 * Color.red(c.accent) + 0.587 * Color.green(c.accent) + 0.114 * Color.blue(c.accent)) / 255.0;
        c.onAccent = lum > 0.55 ? 0xFF000000 : 0xFFFFFFFF;
        c.edge = alpha(c.accent, c.dark ? 0x55 : 0x66);
        return c;
    }

    public static int dp(View v, float dp) {
        return Math.round(dp * v.getResources().getDisplayMetrics().density);
    }

    public static GradientDrawable rounded(int fill, float radiusPx) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.RECTANGLE);
        d.setColor(fill);
        d.setCornerRadius(radiusPx);
        return d;
    }

    public static GradientDrawable rounded(int fill, float radiusPx, int strokeColor, int strokePx) {
        GradientDrawable d = rounded(fill, radiusPx);
        d.setStroke(strokePx, strokeColor);
        return d;
    }

    /** Glass-neon panel: faint diagonal gradient plus a glowing hairline edge. */
    public static GradientDrawable glass(Colors c, float radiusPx, int strokePx) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{ColorUtils.blendARGB(c.card, c.accent, c.dark ? 0.10f : 0.05f), alpha(c.card, 0xEE)});
        d.setCornerRadius(radiusPx);
        d.setStroke(strokePx, c.edge);
        return d;
    }

    public static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | (a << 24);
    }

    /** Recursively paint a view tree according to android:tag markers. */
    public static void apply(View v, Colors c) {
        Object tag = v.getTag();
        if (tag instanceof String) {
            String t = (String) tag;
            switch (t) {
                case "bg":
                    v.setBackgroundColor(c.bg);
                    break;
                case "card":
                    v.setBackground(glass(c, dp(v, 18), Math.max(1, dp(v, 1))));
                    break;
                case "title":
                    if (v instanceof TextView) ((TextView) v).setTextColor(c.text);
                    break;
                case "sub":
                    if (v instanceof TextView) ((TextView) v).setTextColor(c.sub);
                    break;
                case "accent":
                    if (v instanceof TextView) ((TextView) v).setTextColor(c.accentText);
                    break;
                case "btn":
                    v.setBackground(rounded(c.accent, dp(v, 14)));
                    if (v instanceof TextView) ((TextView) v).setTextColor(c.onAccent);
                    break;
                case "ghost":
                    v.setBackground(rounded(alpha(c.accent, 0x18), dp(v, 14), c.accent, Math.max(1, dp(v, 1))));
                    if (v instanceof TextView) ((TextView) v).setTextColor(c.accentText);
                    break;
                case "danger":
                    v.setBackground(rounded(c.danger, dp(v, 14)));
                    if (v instanceof TextView) ((TextView) v).setTextColor(0xFFFFFFFF);
                    break;
                case "icon":
                    if (v instanceof ImageView) ((ImageView) v).setColorFilter(c.text);
                    break;
                case "input":
                    v.setBackground(rounded(c.track, dp(v, 10)));
                    if (v instanceof EditText) {
                        ((EditText) v).setTextColor(c.text);
                        ((EditText) v).setHintTextColor(c.sub);
                    }
                    break;
                default:
                    break;
            }
        }

        ColorStateList checked = new ColorStateList(
                new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{c.accent, c.sub});
        if (v instanceof SwitchCompat) {
            SwitchCompat s = (SwitchCompat) v;
            s.setThumbTintList(checked);
            s.setTrackTintList(new ColorStateList(
                    new int[][]{{android.R.attr.state_checked}, {}},
                    new int[]{alpha(c.accent, 0x80), alpha(c.sub, 0x60)}));
        } else if (v instanceof RadioButton) {
            ((RadioButton) v).setButtonTintList(checked);
        } else if (v instanceof SeekBar) {
            SeekBar sb = (SeekBar) v;
            sb.setThumbTintList(ColorStateList.valueOf(c.accent));
            sb.setProgressTintList(ColorStateList.valueOf(c.accent));
            sb.setProgressBackgroundTintList(ColorStateList.valueOf(c.track));
        }

        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) apply(g.getChildAt(i), c);
        }
    }
}
