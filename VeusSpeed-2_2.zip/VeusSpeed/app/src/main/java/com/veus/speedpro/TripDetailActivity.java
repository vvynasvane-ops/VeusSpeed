package com.veus.speedpro;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** One saved trip: speed-coloured route, stats, speed + elevation graphs, GPX export and sharing. */
public class TripDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Edge.enable(this);
        setContentView(R.layout.activity_trip_detail);
        Edge.pad(findViewById(R.id.root));
        final Prefs prefs = new Prefs(this);
        final TripStore store = ((SpeedApp) getApplication()).getTrips();
        final Units unit = prefs.getUnit();
        final long id = getIntent().getLongExtra("id", -1);
        final TripStore.Trip t = store.get(id);
        findViewById(R.id.btnDone).setOnClickListener(v -> finish());
        if (t == null) {
            Toast.makeText(this, "Trip not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        final List<DriveAnalytics.Pt> pts = store.loadRoute(id);
        ThemeHelper.Colors c = ThemeHelper.resolve(this, prefs, false);
        Edge.bars(this, c.dark);

        ((TextView) findViewById(R.id.txtTitle)).setText(
                new SimpleDateFormat("EEE d MMM yyyy, HH:mm", Locale.getDefault()).format(new Date(t.startMs)));

        RouteView route = findViewById(R.id.route);
        route.setPalette(c.accent, c.track, c.text, c.sub, c.danger);
        route.setHeightDp(280);
        route.setRoute(pts, null, false);

        LinearLayout stats = findViewById(R.id.cardStats);
        long s = t.durMs / 1000, m = t.movMs / 1000;
        TextView[] a = UiKit.statRow(this, stats, "DISTANCE", "TIME", "MOVING");
        a[0].setText(unit.formatDistance(t.distM));
        a[1].setText(String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60));
        a[2].setText(String.format(Locale.US, "%d:%02d:%02d", m / 3600, (m % 3600) / 60, m % 60));
        TextView[] b = UiKit.statRow(this, stats, "TOP \u00B7 " + unit.label, "AVG \u00B7 " + unit.label, "ECO SCORE");
        b[0].setText(unit.format(t.maxMs));
        b[1].setText(unit.format(t.avgMs));
        b[2].setText(t.eco >= 0 ? t.eco + "/100" : "--");
        TextView[] d = UiKit.statRow(this, stats, "HARSH ACC", "HARSH BRK", "HARSH TURN");
        d[0].setText(String.valueOf(t.hAccel));
        d[1].setText(String.valueOf(t.hBrake));
        d[2].setText(String.valueOf(t.hCorner));
        TextView[] e = UiKit.statRow(this, stats, "ASCENT", "DESCENT", "OVER LIMIT");
        e[0].setText(unit.formatAlt(t.ascent));
        e[1].setText(unit.formatAlt(t.descent));
        e[2].setText(String.format(Locale.US, "%d:%02d", (t.overMs / 1000) / 60, (t.overMs / 1000) % 60));
        float l100 = prefs.getFuelL100();
        if (l100 > 0) {
            double fuel = t.distM / 1000.0 * l100 / 100.0;
            String cost = prefs.getFuelPrice() > 0
                    ? String.format(Locale.US, "  |  %s%.2f", prefs.getCurrency(), fuel * prefs.getFuelPrice()) : "";
            UiKit.label(this, stats, String.format(Locale.US, "Fuel \u2248 %.2f L%s  |  CO\u2082 \u2248 %.2f kg", fuel, cost, fuel * 2.31),
                    "sub", 12);
        }

        GraphView gs = findViewById(R.id.graphSpeed);
        GraphView ga = findViewById(R.id.graphAlt);
        float[] sp = new float[pts.size()], al = new float[pts.size()];
        for (int i = 0; i < sp.length; i++) {
            sp[i] = (float) unit.fromMs(pts.get(i).spd);
            al[i] = unit.imperial() ? pts.get(i).alt * 3.28084f : pts.get(i).alt;
        }
        gs.setPalette(c.accent, c.track, c.text, c.sub, c.danger);
        ga.setPalette(c.accent, c.track, c.text, c.sub, c.danger);
        gs.setData(sp, 0f, 0f, "SPEED \u00B7 " + unit.label);
        ga.setLineColor(0xFFB388FF);
        ga.setData(al, 0f, 0f, "ELEVATION \u00B7 " + (unit.imperial() ? "ft" : "m"));

        LinearLayout actions = findViewById(R.id.cardActions);
        UiKit.button(this, actions, "EXPORT GPX", "btn", () -> {
            try {
                ShareUtil.shareFile(this, ShareUtil.writeGpx(this, t, pts), "application/gpx+xml", "VeusSpeed trip");
            } catch (Exception ex) {
                Toast.makeText(this, "Export failed", Toast.LENGTH_SHORT).show();
            }
        });
        UiKit.button(this, actions, "SHARE SUMMARY", "ghost", () ->
                ShareUtil.shareText(this, "VeusSpeed trip", ShareUtil.tripSummary(t, unit)));
        UiKit.button(this, actions, "DELETE TRIP", "danger", () -> new AlertDialog.Builder(this)
                .setTitle("Delete this trip?")
                .setPositiveButton("Delete", (dlg, w) -> { store.delete(id); finish(); })
                .setNegativeButton("Cancel", null)
                .show());

        ThemeHelper.apply(findViewById(R.id.root), c);
    }
}
