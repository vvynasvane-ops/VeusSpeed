package com.veus.speedpro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;

import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;
import androidx.core.content.ContextCompat;

import java.util.Locale;

/**
 * "Pit Crew" - keeps the trip alive while VeusSpeed is in the background and talks to you through
 * notifications:
 *
 *  - a live, silent trip card: reactor-ring speed icon, status line (Holding orbit / Cruising / Warp
 *    speed ...), a speed bar, trip stats, and an "End trip" button. It turns red when you are over
 *    your speed limit.
 *  - heads-up milestone alerts: every "Orbit" (km or mile), a new top-speed record, and over-limit
 *    warnings.
 *  - auto-park: after 10 minutes standing still the trip is saved, GPS is released and a trip
 *    summary notification is posted.
 *
 * The service does not track anything itself: it reads the app-wide SpeedTracker, so there is no
 * second GPS listener and the numbers always match the main screen.
 */
public class PitCrewService extends Service {

    public static final String ACTION_END = "com.veus.speedpro.action.END_TRIP";

    private static final String CH_LIVE = "veus_pitcrew_live";
    private static final String CH_ALERT = "veus_pitcrew_alerts";
    private static final int ID_LIVE = 4201, ID_ORBIT = 4202, ID_SUMMARY = 4203, ID_RECORD = 4204, ID_OVER = 4205;

    private static final long IDLE_PARK_MS = 10 * 60 * 1000L;
    private static final long OVER_COOLDOWN_MS = 60 * 1000L;

    private static volatile boolean active;

    /** True from the moment start() is called until the service is destroyed. */
    public static boolean isActive() { return active; }

    /** Must only be called while the app is visible (Android 12+ forbids starting FGS from background). */
    public static void start(Context c) {
        if (active) return;
        active = true;
        try {
            ContextCompat.startForegroundService(c, new Intent(c, PitCrewService.class));
        } catch (RuntimeException e) {
            active = false;
        }
    }

    public static void stop(Context c) {
        c.stopService(new Intent(c, PitCrewService.class));
    }

    // ------------------------------------------------------------------------------------------

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SpeedApp app;
    private SpeedTracker tracker;
    private Prefs prefs;
    private NotificationManager nm;

    private int lastOrbit;
    private boolean recordAnnounced;
    private long lastOverAlert;
    private long idleSince = -1;

    @Override
    public void onCreate() {
        super.onCreate();
        active = true;
        app = (SpeedApp) getApplication();
        tracker = app.getTracker();
        prefs = new Prefs(this);
        nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        createChannels();
        lastOrbit = orbits();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_END.equals(intent.getAction())) {
            endTrip();
            return START_NOT_STICKY;
        }
        try {
            ServiceCompat.startForeground(this, ID_LIVE, buildLive(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        } catch (RuntimeException e) {
            // Android 12+ (start not allowed) / Android 14+ (location permission missing): never crash, just stand down.
            active = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        handler.removeCallbacks(loop);
        handler.post(loop);
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        active = false;
        // If nobody is looking at the app, release the GPS too. (MainActivity restarts it in onStart.)
        if (!SpeedApp.uiVisible) tracker.stop();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    // ------------------------------------------------------------------------------------------
    // 1 Hz brain
    // ------------------------------------------------------------------------------------------

    private final Runnable loop = new Runnable() {
        @Override public void run() {
            tracker.tick();
            if (!tracker.isStarted()) {          // permission revoked / GPS released elsewhere
                shutdown();
                return;
            }
            checkMilestones();
            if (checkIdle()) return;
            nm.notify(ID_LIVE, buildLive());
            handler.postDelayed(this, 1000);
        }
    };

    private int orbits() {
        double u = prefs.getUnit().imperial() ? 1609.344 : 1000.0;
        return (int) (tracker.getDistanceM() / u);
    }

    private void checkMilestones() {
        Units unit = prefs.getUnit();
        int accent = accentColor();

        // Orbit = every km / mile
        int k = orbits();
        if (k < lastOrbit) lastOrbit = k;
        else if (k > lastOrbit) {
            lastOrbit = k;
            alert(ID_ORBIT, "Orbit " + k + " complete",
                    unit.formatDistance(tracker.getDistanceM()) + " logged  \u00B7  avg "
                            + unit.format(tracker.getAvgMs()) + " " + unit.label
                            + "  \u00B7  top " + unit.format(tracker.getMaxMs()) + " " + unit.label, accent);
        }

        // New personal record (only meaningful once a record exists)
        float record = prefs.getTopMs();
        if (!recordAnnounced && record > 0 && tracker.getMaxMs() > record + 0.5) {
            recordAnnounced = true;
            alert(ID_RECORD, "New top speed!",
                    unit.format(tracker.getMaxMs()) + " " + unit.label + " - the old record was "
                            + unit.format(record) + " " + unit.label, 0xFFFFD740);
        }

        // Over the speed limit
        int limit = prefs.getSpeedLimitKmh();
        double kmh = tracker.getSpeedMs() * 3.6;
        long now = SystemClock.elapsedRealtime();
        if (limit > 0 && kmh > limit + 0.5 && now - lastOverAlert > OVER_COOLDOWN_MS) {
            lastOverAlert = now;
            alert(ID_OVER, "Over the limit",
                    String.format(Locale.US, "%.0f km/h in a %d km/h zone - ease off.", kmh, limit), 0xFFFF1744);
        }
    }

    /** @return true if the trip was parked and the service is shutting down. */
    private boolean checkIdle() {
        if (tracker.getSpeedMs() >= 0.5) {
            idleSince = -1;
            return false;
        }
        long now = SystemClock.elapsedRealtime();
        if (idleSince < 0) idleSince = now;
        if (now - idleSince >= IDLE_PARK_MS) {
            parkAndSummarize("Parked");
            return true;
        }
        return false;
    }

    private void endTrip() { parkAndSummarize("Trip ended"); }

    private void parkAndSummarize(String headline) {
        Units unit = prefs.getUnit();
        double dist = tracker.getDistanceM();
        double top = tracker.getMaxMs();
        double avg = tracker.getAvgMs();
        long dur = tracker.getTotalMs();
        TripStore.Trip saved = app.finishTrip();

        String text = saved != null
                ? unit.formatDistance(dist) + "  \u00B7  " + clock(dur) + "  \u00B7  avg " + unit.format(avg)
                        + " / top " + unit.format(top) + " " + unit.label + ". Saved to your trip log."
                : "Under 100 m - nothing to save. Ready for the next orbit.";
        alert(ID_SUMMARY, headline + " - welcome back to dock", text, accentColor());
        shutdown();
    }

    private void shutdown() {
        handler.removeCallbacksAndMessages(null);
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    // ------------------------------------------------------------------------------------------
    // notifications
    // ------------------------------------------------------------------------------------------

    private void createChannels() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationChannel live = new NotificationChannel(CH_LIVE, "Live trip (Pit Crew)",
                NotificationManager.IMPORTANCE_LOW);
        live.setDescription("Silent live speed card while a trip runs in the background");
        live.setShowBadge(false);
        NotificationChannel alerts = new NotificationChannel(CH_ALERT, "Trip milestones & alerts",
                NotificationManager.IMPORTANCE_HIGH);
        alerts.setDescription("Orbit milestones, speed records, speed-limit warnings and trip summaries");
        nm.createNotificationChannel(live);
        nm.createNotificationChannel(alerts);
    }

    private PendingIntent openApp() {
        Intent i = new Intent(this, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private PendingIntent endTripIntent() {
        Intent i = new Intent(this, PitCrewService.class).setAction(ACTION_END);
        return PendingIntent.getService(this, 1, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification buildLive() {
        Units unit = prefs.getUnit();
        boolean fix = tracker.hasFix();
        double v = tracker.getSpeedMs();
        double kmh = v * 3.6;
        int limit = prefs.getSpeedLimitKmh();
        boolean over = limit > 0 && kmh > limit + 0.5;
        int accent = accentColor();

        double scale = limit > 0 ? limit * 1.25 : 200.0;
        float frac = (float) Math.max(0, Math.min(1, kmh / scale));
        String speed = unit.format(v);

        String title = fix ? speed + " " + unit.label + "  \u00B7  " + statusLabel(kmh, over)
                : "Locking onto satellites\u2026";
        String line = "Top " + unit.format(tracker.getMaxMs()) + "  \u00B7  " + unit.formatDistance(tracker.getDistanceM())
                + "  \u00B7  " + clock(tracker.getTotalMs());
        String big = line
                + "\nAvg " + unit.format(tracker.getAvgMs()) + " " + unit.label + "  \u00B7  moving " + clock(tracker.getMovingMs())
                + "\nSatellites " + tracker.satsUsed + "/" + tracker.satsVisible
                + (tracker.getAccuracy() > 0 ? String.format(Locale.US, "  \u00B7  \u00B1%.0f m", tracker.getAccuracy()) : "")
                + (limit > 0 ? "\nLimit " + limit + " km/h" : "");

        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CH_LIVE)
                .setSmallIcon(R.drawable.ic_notif_speed)
                .setLargeIcon(ring(fix ? speed : "--", fix ? frac : 0f, over ? 0xFFFF1744 : accent))
                .setContentTitle(title)
                .setContentText(line)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(big).setBigContentTitle(title))
                .setColor(over ? 0xFFFF1744 : accent)
                .setColorized(over)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
                .setContentIntent(openApp())
                .addAction(0, "End trip", endTripIntent());
        if (fix) b.setProgress(100, Math.round(frac * 100), false);
        else b.setProgress(0, 0, true);
        return b.build();
    }

    private void alert(int id, String title, String text, int color) {
        Notification n = new NotificationCompat.Builder(this, CH_ALERT)
                .setSmallIcon(R.drawable.ic_notif_speed)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setColor(color)
                .setAutoCancel(true)
                .setCategory(NotificationCompat.CATEGORY_STATUS)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(prefs.getVibrate() ? NotificationCompat.DEFAULT_VIBRATE : 0)
                .setContentIntent(openApp())
                .build();
        nm.notify(id, n);   // silently ignored if the user denied notifications
    }

    // ------------------------------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------------------------------

    private static String statusLabel(double kmh, boolean over) {
        if (over) return "Over the limit";
        if (kmh < 2) return "Holding orbit";
        if (kmh < 40) return "Drifting";
        if (kmh < 90) return "Cruising";
        if (kmh < 130) return "Burning";
        return "Warp speed";
    }

    private static String clock(long ms) {
        long s = Math.max(0, ms / 1000);
        return String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
    }

    private int accentColor() {
        int i = prefs.getPalette();
        if (i >= 0 && i < ThemeHelper.PALETTES.length) return ThemeHelper.PALETTES[i].color;
        return Color.HSVToColor(new float[]{prefs.getCustomHue(), 0.85f, 1f});
    }

    /** Mini "reactor ring" gauge drawn on the fly for the notification's large icon. */
    private static Bitmap ring(String num, float frac, int color) {
        final int s = 160;
        Bitmap bm = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF0B0F1A);
        c.drawCircle(s / 2f, s / 2f, s / 2f, p);

        float stroke = 12f, inset = stroke + 6f;
        RectF r = new RectF(inset, inset, s - inset, s - inset);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(stroke);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor((color & 0x00FFFFFF) | 0x44000000);
        c.drawArc(r, 135, 270, false, p);
        if (frac > 0.01f) {
            p.setColor(color);
            c.drawArc(r, 135, 270 * frac, false, p);
        }

        Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
        t.setColor(Color.WHITE);
        t.setTextAlign(Paint.Align.CENTER);
        t.setFakeBoldText(true);
        t.setTextSize(num.length() <= 2 ? 66f : (num.length() == 3 ? 54f : 36f));
        float y = s / 2f - (t.descent() + t.ascent()) / 2f;
        c.drawText(num, s / 2f, y, t);
        return bm;
    }
}
