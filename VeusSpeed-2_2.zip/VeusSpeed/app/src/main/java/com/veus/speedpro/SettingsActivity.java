package com.veus.speedpro;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.util.Locale;

public class SettingsActivity extends AppCompatActivity {

    private Prefs prefs;
    private LinearLayout content, swatchHost;
    private View root;
    private GaugeView preview;
    private ThemeHelper.Colors colors;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        Edge.enable(this);
        setContentView(R.layout.activity_settings);
        root = findViewById(R.id.root);
        Edge.pad(root);
        content = findViewById(R.id.content);
        preview = findViewById(R.id.previewGauge);
        findViewById(R.id.btnDone).setOnClickListener(v -> finish());
        build();
        applyTheme();
        preview.setUnit(prefs.getUnit());
        preview.setSpeed((float) (prefs.getUnit().gaugeMax * 0.42));
        preview.setPeak((float) (prefs.getUnit().gaugeMax * 0.62));
    }

    private void applyTheme() {
        colors = ThemeHelper.resolve(this, prefs, false);
        ThemeHelper.apply(root, colors);
        preview.setPalette(colors.accent, colors.track, colors.text, colors.sub, colors.danger);
        preview.setHeat(prefs.getHeat());
        preview.setStyle(prefs.getGaugeStyle() == 1 ? GaugeView.STYLE_ANALOG : GaugeView.STYLE_REACTOR);
        Edge.bars(this, colors.dark);
        buildSwatches();
    }

    private int intOr(String s, int d) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return d; }
    }

    private float fltOr(String s, float d) {
        try { return Float.parseFloat(s.trim().replace(',', '.')); } catch (Exception e) { return d; }
    }

    private void build() {
        LinearLayout c;
        final int num = InputType.TYPE_CLASS_NUMBER;
        final int dec = InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL;

        // ---- appearance ---------------------------------------------------------------------
        c = UiKit.card(this, content, "Appearance");
        UiKit.label(this, c, "Theme", "sub", 12);
        UiKit.radios(this, c, new String[]{"Follow system", "Light", "Dark"}, prefs.getThemeMode(), v -> {
            prefs.setThemeMode(v);
            ThemeHelper.applyNightMode(v);
        });
        UiKit.label(this, c, "Gauge style (tap the gauge on the main screen to cycle)", "sub", 12);
        UiKit.radios(this, c, new String[]{"Digital", "Analog neon", "HUD (mirrored, for windscreen reflection)", "Reactor ring"},
                styleToIndex(prefs.getGaugeStyle()), v -> {
                    prefs.setGaugeStyle(v);
                    applyTheme();
                });
        UiKit.label(this, c, "Accent colour", "sub", 12);
        swatchHost = new LinearLayout(this);
        swatchHost.setOrientation(LinearLayout.VERTICAL);
        c.addView(swatchHost);
        UiKit.toggle(this, c, "Stealth OLED black", prefs.getStealth(), v -> { prefs.setBool("stealth", v); applyTheme(); });
        UiKit.toggle(this, c, "Warp starfield + grid background", prefs.bool("fx_space", true), v -> prefs.setBool("fx_space", v));
        UiKit.toggle(this, c, "Holographic scanlines", prefs.bool("fx_scan", true), v -> prefs.setBool("fx_scan", v));
        UiKit.toggle(this, c, "Heat colour (accent > amber > red as speed climbs)", prefs.getHeat(), v -> { prefs.setBool("fx_heat", v); applyTheme(); });
        UiKit.toggle(this, c, "Boot animation on launch", prefs.getBoot(), v -> prefs.setBool("boot_anim", v));
        UiKit.toggle(this, c, "Keep screen on", prefs.getKeepScreenOn(), prefs::setKeepScreenOn);
        UiKit.label(this, c, "Night vision (red-only HUD)", "sub", 12);
        UiKit.radios(this, c, new String[]{"Off", "Auto (ambient light sensor)", "Always on"}, prefs.getNightMode(), v -> prefs.setNum("night_mode", v));
        UiKit.label(this, c, "Orientation", "sub", 12);
        UiKit.radios(this, c, new String[]{"Auto-rotate", "Portrait", "Landscape cockpit"}, prefs.getOrientation(), v -> prefs.setNum("orient", v));
        UiKit.toggle(this, c, "Floating mini speedometer when leaving the app (picture-in-picture)", prefs.getPip(), v -> prefs.setBool("pip", v));
        UiKit.toggle(this, c, "Pit Crew: live trip notification + milestone alerts while the app is in the background", prefs.getBgNotif(), v -> { prefs.setBool("bg_notif", v); if (!v) PitCrewService.stop(this); });

        // ---- units --------------------------------------------------------------------------
        c = UiKit.card(this, content, "Speed unit");
        final Units[] us = Units.values();
        String[] names = new String[us.length];
        int sel = 0;
        for (int i = 0; i < us.length; i++) {
            names[i] = us[i].label;
            if (us[i] == prefs.getUnit()) sel = i;
        }
        UiKit.radios(this, c, names, sel, v -> { prefs.setUnit(us[v]); preview.setUnit(us[v]); });

        // ---- alerts -------------------------------------------------------------------------
        c = UiKit.card(this, content, "Alerts");
        UiKit.label(this, c, "Speed limit in km/h (0 = off)", "sub", 12);
        UiKit.input(this, c, "e.g. 80", String.valueOf(prefs.getSpeedLimitKmh()), num, 3, s -> prefs.setSpeedLimitKmh(intOr(s, 0)));
        UiKit.toggle(this, c, "Early warning at 90% of the limit (amber)", prefs.getWarn90(), v -> prefs.setBool("warn90", v));
        UiKit.toggle(this, c, "Vibrate", prefs.getVibrate(), v -> prefs.setBool("vibrate", v));
        UiKit.toggle(this, c, "Beep", prefs.getSound(), v -> prefs.setBool("sound", v));
        UiKit.toggle(this, c, "Voice announcements (offline text-to-speech)", prefs.getVoice(), v -> prefs.setBool("voice", v));
        UiKit.toggle(this, c, "Announce every km / mile", prefs.getVoiceKm(), v -> prefs.setBool("voice_km", v));
        UiKit.label(this, c, "Break reminder every N hours of driving (0 = off)", "sub", 12);
        UiKit.input(this, c, "e.g. 2", String.valueOf(prefs.getBreakHours()), num, 2, s -> prefs.setNum("break_h", intOr(s, 0)));
        UiKit.label(this, c, "Pace keeper target in km/h (0 = off)", "sub", 12);
        UiKit.input(this, c, "e.g. 90", String.valueOf(prefs.getPaceKmh()), num, 3, s -> prefs.setNum("pace_kmh", intOr(s, 0)));

        // ---- safety -------------------------------------------------------------------------
        c = UiKit.card(this, content, "Safety");
        UiKit.toggle(this, c, "Crash detection + 30 s SOS countdown", prefs.getCrash(), v -> prefs.setBool("crash", v));
        UiKit.label(this, c, "Emergency contact number (SOS opens a pre-filled SMS; you press send)", "sub", 12);
        UiKit.input(this, c, "+254...", prefs.getSosNumber(), InputType.TYPE_CLASS_PHONE, 20, s -> prefs.setStr("sos_number", s));
        UiKit.toggle(this, c, "Proximity sensor warning", prefs.getProximity(), v -> prefs.setBool("proximity", v));
        UiKit.toggle(this, c, "Impact / jolt warning", prefs.getImpact(), v -> prefs.setBool("impact", v));
        UiKit.label(this, c, "Impact sensitivity", "sub", 12);
        UiKit.radios(this, c, new String[]{"Low (3.5 g)", "Medium (2.5 g)", "High (1.8 g)"}, prefs.getImpactSens(), v -> prefs.setNum("impact_sens", v));

        // ---- tuning -------------------------------------------------------------------------
        c = UiKit.card(this, content, "GPS tuning");
        UiKit.label(this, c, "Needle smoothing", "sub", 12);
        UiKit.radios(this, c, new String[]{"Raw (instant)", "Balanced", "Smooth"}, prefs.getSmoothing(), v -> prefs.setNum("smooth", v));
        UiKit.label(this, c, "GPS update rate", "sub", 12);
        UiKit.radios(this, c, new String[]{"Fast (4 Hz, best for performance runs)", "Normal (2 Hz)", "Eco (1 Hz)"}, prefs.getGpsRate(), v -> prefs.setNum("gps_rate", v));
        final TextView calLabel = UiKit.label(this, c, calText(prefs.getCalibPct()), "title", 14);
        UiKit.seek(this, c, 20, prefs.getCalibPct() + 10, p -> {
            prefs.setNum("calib_pct", p - 10);
            calLabel.setText(calText(p - 10));
        });
        UiKit.toggle(this, c, "Battery saver (1 Hz GPS, effects off)", prefs.getBatterySaver(), v -> prefs.setBool("battery_saver", v));
        UiKit.label(this, c, "GPS rate, smoothing, calibration and battery saver apply next time the main screen opens.", "sub", 11);

        // ---- vehicle ------------------------------------------------------------------------
        c = UiKit.card(this, content, "Vehicle & costs");
        UiKit.label(this, c, "Fuel use in L per 100 km (0 = off)", "sub", 12);
        UiKit.input(this, c, "e.g. 7.5", prefs.getFuelL100() > 0 ? String.valueOf(prefs.getFuelL100()) : "", dec, 6, s -> prefs.setFlt("fuel_l100", fltOr(s, 0f)));
        UiKit.label(this, c, "Fuel price per litre", "sub", 12);
        UiKit.input(this, c, "e.g. 1.9", prefs.getFuelPrice() > 0 ? String.valueOf(prefs.getFuelPrice()) : "", dec, 7, s -> prefs.setFlt("fuel_price", fltOr(s, 0f)));
        UiKit.label(this, c, "Currency symbol", "sub", 12);
        UiKit.input(this, c, "$", prefs.getCurrency(), InputType.TYPE_CLASS_TEXT, 5, s -> prefs.setStr("currency", s.isEmpty() ? "$" : s));

        // ---- data ---------------------------------------------------------------------------
        c = UiKit.card(this, content, "Data");
        UiKit.button(this, c, "EXPORT ALL TRIPS (CSV)", "ghost", () -> {
            try {
                TripStore ts = ((SpeedApp) getApplication()).getTrips();
                File f = ShareUtil.writeCsv(this, "veusspeed_trips.csv", ts.csvAll());
                ShareUtil.shareFile(this, f, "text/csv", "VeusSpeed trips");
            } catch (Exception e) {
                Toast.makeText(this, "Export failed", Toast.LENGTH_SHORT).show();
            }
        });
        UiKit.button(this, c, "RESET PERFORMANCE BESTS", "ghost", () -> {
            ((SpeedApp) getApplication()).getTracker().perf.clearBests();
            Toast.makeText(this, "Bests cleared", Toast.LENGTH_SHORT).show();
        });
        UiKit.button(this, c, "DELETE ALL TRIPS", "danger", () -> new AlertDialog.Builder(this)
                .setTitle("Delete all trips?")
                .setMessage("This removes the whole trip log and routes. It cannot be undone.")
                .setPositiveButton("Delete", (d, w) -> {
                    ((SpeedApp) getApplication()).getTrips().deleteAll();
                    prefs.setStr("life_m", "0");
                    Toast.makeText(this, "Trip log cleared", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show());

        TextView about = UiKit.label(this, content, "VeusSpeed 2.0  -  100% offline GPS speedometer. No accounts, no ads, no network.", "sub", 12);
        about.setGravity(android.view.Gravity.CENTER);
        about.setPadding(0, UiKit.dp(this, 16), 0, UiKit.dp(this, 24));
    }

    private static int styleToIndex(int style) {
        return Math.max(0, Math.min(3, style));
    }

    private static String calText(int pct) {
        return String.format(Locale.US, "Speed calibration: %+d%%", pct);
    }

    private void buildSwatches() {
        if (swatchHost == null) return;
        swatchHost.removeAllViews();
        final int per = 5;
        LinearLayout row = null;
        int total = ThemeHelper.PALETTES.length;
        for (int i = 0; i < total; i++) {
            if (i % per == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                swatchHost.addView(row);
            }
            final int idx = i;
            row.addView(swatch(ThemeHelper.paletteColor(this, i, true), prefs.getPalette() == i, () -> pick(idx)));
        }
        if (row != null && total % per == 0) {
            row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            swatchHost.addView(row);
        }
        row.addView(swatch(ThemeHelper.customColor(prefs.getCustomHue()), prefs.getPalette() == total, () -> pick(total)));
        final TextView hueLabel = new TextView(this);
        hueLabel.setTag("sub");
        hueLabel.setTextSize(12);
        hueLabel.setText("Custom hue (last swatch)");
        hueLabel.setPadding(0, UiKit.dp(this, 8), 0, 0);
        swatchHost.addView(hueLabel);
        android.widget.SeekBar sb = new android.widget.SeekBar(this);
        sb.setMax(359);
        sb.setProgress(prefs.getCustomHue());
        sb.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar s, int p, boolean user) {
                if (!user) return;
                prefs.setCustomHue(p);
                prefs.setPalette(total);
            }
            @Override public void onStartTrackingTouch(android.widget.SeekBar s) { }
            @Override public void onStopTrackingTouch(android.widget.SeekBar s) { applyTheme(); }
        });
        swatchHost.addView(sb);
        ThemeHelper.apply(swatchHost, colors);
    }

    private void pick(int idx) {
        prefs.setPalette(idx);
        applyTheme();
    }

    private View swatch(int color, boolean selected, Runnable onClick) {
        View v = new View(this);
        int size = UiKit.dp(this, 44);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
        lp.setMargins(UiKit.dp(this, 4), UiKit.dp(this, 4), UiKit.dp(this, 4), UiKit.dp(this, 4));
        v.setLayoutParams(lp);
        v.setBackground(ThemeHelper.rounded(color, size / 2f, selected ? colors.text : 0x00000000, UiKit.dp(this, 3)));
        v.setOnClickListener(x -> onClick.run());
        return v;
    }
}
